#!/usr/bin/env node
/* ============================================================
   BLauncher Mod — real test-suite (Node 18+, zero deps)
   • upload validation (valid/invalid JAR, mcpack/mcaddon)
   • SHA-256 duplicates, size limits, extension checks
   • exact version counts & dedupe vs LIVE official APIs
   • router "params.get" regression test
   Exit code 0 only when everything passes.
   ============================================================ */
import { sha256Hex, checkExtension, validateZip, detectMetadata, extractEntry, findEntry, dedupeVersions } from "../js/upload-lib.js";
import { deflateRawSync } from "node:zlib";
import crypto from "node:crypto";

const PASS = [], FAIL = [];
let n = 0;
function check(name, cond, extra = "") {
  n++;
  if (cond) { PASS.push(name); console.log(`  ✔ ${name}`); }
  else { FAIL.push(name); console.log(`  ✘ ${name}  ${extra}`); }
}
const section = (s) => console.log(`\n--- ${s} ---`);

/* ---------------- tiny ZIP builder (STORE + DEFLATE entries) ---------------- */
function crc32(buf) {
  let table = crc32.t;
  if (!table) {
    table = crc32.t = [];
    for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; table[i] = c >>> 0; }
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (0xffffffff ^ c) >>> 0;
}
function utf8(s) { return Buffer.from(s, "utf8"); }
function le32(v) { const b = Buffer.alloc(4); b.writeUInt32LE(v >>> 0); return b; }
function le16(v) { const b = Buffer.alloc(2); b.writeUInt16LE(v & 0xffff); return b; }
function buildZip(entries, { truncate = 0 } = {}) {  /* entries: [{name, data, method}] */
  const locals = [], central = [];
  let off = 0;
  for (const e of entries) {
    const name = utf8(e.name);
    const raw = Buffer.from(e.data); /* Buffer or Uint8Array */
    let data = raw, method = 0;
    if (e.method === 8) { data = Buffer.from(deflateRawSync(raw)); method = 8; }
    const crc = crc32(raw);
    const localOffset = off;
    const local = Buffer.concat([
      le32(0x04034b50), le16(20), le16(0), le16(method), le16(0), le16(0),
      le32(crc), le32(data.length), le32(raw.length), le16(name.length), le16(0),
      name, data,
    ]);
    locals.push(local);
    off += local.length;
    central.push(Buffer.concat([
      le32(0x02014b50), le16(20), le16(20), le16(0), le16(method), le16(0), le16(0),
      le32(crc), le32(data.length), le32(raw.length), le16(name.length), le16(0), le16(0), le16(0), le16(0),
      le32(0), le32(localOffset), name,
    ]));
  }
  const cdStart = off;
  const cd = Buffer.concat(central);
  off += cd.length;
  const eocd = Buffer.concat([
    le32(0x06054b50), le16(0), le16(0), le16(entries.length), le16(entries.length),
    le32(cd.length), le32(cdStart), le16(0),
  ]);
  let out = Buffer.concat([...locals, cd, eocd]);
  if (truncate) out = out.subarray(0, out.length - truncate);
  return new Uint8Array(out);
}

/* ---------------- fabricated mod files ---------------- */
const FABRIC_JSON = JSON.stringify({
  schemaVersion: 1, id: "coolmod", name: "Cool Mod", version: "1.0.0",
  description: "A genuinely detected test mod",
  depends: { minecraft: ">=1.20.1" },
});

const jarOk = buildZip([
  { name: "fabric.mod.json", data: FABRIC_JSON },
  { name: "com/cool/Mod.class", data: new Uint8Array([0xca, 0xfe, 0xba, 0xbe]) },
]);
const jarDeflate = buildZip([
  { name: "META-INF/MANIFEST.MF", data: utf8("Manifest-Version: 1.0\n"), method: 8 },
  { name: "fabric.mod.json", data: utf8(FABRIC_JSON), method: 8 },
]);
const forgeToml = buildZip([
  { name: "META-INF/mods.toml", data: utf8(`modLoader="javafml"\nloaderVersion="[47,)"\nminecraft="[1.20.1,)"\n[[mods]]\nmodId="coolforge"\ndisplayName="Cool Forge"\ndescription='''toml desc test'''`) },
]);
const pack = buildZip([
  { name: "manifest.json", data: utf8(JSON.stringify({
    format_version: 2,
    header: { name: "Cool Pack", description: "bedrock test pack", version: [1, 2, 0], min_engine_version: [1, 20, 0], uuid: crypto.randomUUID ? "123e4567-e89b-12d3-a456-426614174000" : "uuid" },
    modules: [{ type: "data", uuid: "223e4567-e89b-12d3-a456-426614174001" }],
  })) },
  { name: "some/dir/manifest.json", data: utf8(JSON.stringify({ format_version: 2, header: { name: "world", uuid: "9-9-9-9" }, modules: [{ type: "world_template" }] })), },
]);
const mcaddon = buildZip([
  { name: "coolskin/manifest.json", data: utf8(JSON.stringify({ format_version: 2, header: { name: "Cool Skin", uuid: "aaaa", min_engine_version: [1, 20, 0] }, modules: [{ type: "skin_pack" }] })) },
  { name: "coolworld/manifest.json", data: utf8(JSON.stringify({ format_version: 2, header: { name: "Cool Behaviour", uuid: "bbbb" }, modules: [{ type: "data" }] })) },
]);
const broken = new Uint8Array([...utf8("This is just text, definitely not an archive at all."), ...new Uint8Array(40)]);
const truncated = jarOk.subarray(0, jarOk.length - 10);

/* ---------------- 1. extension & type checks ---------------- */
section("File extension validation");
check("accepts .jar", checkExtension("CoolMod.jar").ok === true);
check("accepts .mcpack", checkExtension("pack.mcpack").kind === "mcpack");
check("accepts .mcaddon", checkExtension("addon.mcaddon").kind === "mcaddon");
check("rejects .exe (ENOTICKET: never executed!)", !checkExtension("virus.exe").ok);
check("rejects .png with wrong content", !checkExtension("fanart.png").ok);
check("rejects extension-less", !checkExtension("myfile").ok);

/* ---------------- 2. SHA-256 duplicates ---------------- */
section("SHA-256 duplicate detection");
const h1 = await sha256Hex(jarOk);
const h2 = await sha256Hex(jarOk);
const h3 = await sha256Hex(jarDeflate);
check("same bytes → same SHA-256", h1 === h2);
check("same hash 64-hex chars", /^[a-f0-9]{64}$/.test(h1));
check("different bytes → different hash", h1 !== h3);
check("matches reference implementation", h1 === crypto.createHash("sha256").update(jarOk).digest("hex"));

/* ---------------- 3. archive validation ---------------- */
section("Archive (ZIP) validation");
const v1 = validateZip(jarOk);
check("valid jar → ok", v1.ok === true);
check("entries counted exactly", v1.entries.length === 2, `got ${v1.entries?.length}`);
const v2 = validateZip(jarDeflate);
check("deflate jar → ok", v2.ok === true && findEntry(v2.entries, "fabric.mod.json") !== undefined);
check("plain text → rejected", validateZip(broken).ok === false);
check("truncated zip → rejected with reason", !validateZip(truncated).ok && !!validateZip(truncated).reason);
check("empty input → rejected", validateZip(new Uint8Array(4)).ok === false);

/* ---------------- 4. detection ---------------- */
section("Loader & version auto-detection");
const d1 = await detectMetadata(jarOk, validateZip(jarOk).entries, "jar");
check("fabric loader detected", d1.loaders.includes("fabric"));
check("minecraft version constraint from metadata", d1.versions.includes(">=1.20.1"), `got ${JSON.stringify(d1.versions)}`);
check("name from metadata", d1.name === "Cool Mod");
const d2 = await detectMetadata(jarDeflate, validateZip(jarDeflate).entries, "jar");
check("deflate-compressed fabric.mod.json detected", d2.loaders.includes("fabric") && d2.versions.includes(">=1.20.1"));
const d3 = await detectMetadata(forgeToml, validateZip(forgeToml).entries, "jar");
check("forge detected from mods.toml", d3.loaders.includes("forge"));
check("forge minecraft range parsed", d3.versions.includes("[1.20.1,)"), `got ${JSON.stringify(d3.versions)}`);
const d4 = await detectMetadata(pack, validateZip(pack).entries, "mcpack");
check("bedrock detected from manifest.json", d4.loaders.includes("bedrock"));
check("min_engine_version surfaced", JSON.stringify(d4.versions).includes("1.20.0"), `got ${JSON.stringify(d4.versions)}`);
const d5 = await detectMetadata(mcaddon, validateZip(mcaddon).entries, "mcaddon");
check("mcaddon counts both packs", d5.bedrock?.length === 2, `got ${d5.bedrock?.length}`);
const noMeta = buildZip([{ name: "randomfile.txt", data: utf8("no metadata here") }]);
const d6 = await detectMetadata(noMeta, validateZip(noMeta).entries, "jar");
check("no metadata → detection none + manual note", d6.loaders.length === 0 && d6.detection === "none" && d6.notes.length > 0);

/* extract cold path */
const ent = validateZip(jarDeflate).entries[0];
const bytes1 = await extractEntry(jarDeflate, ent);
check("deflate entry extracts to original", bytes1 && new TextDecoder().decode(bytes1).startsWith("Manifest-Version: 1.0"));

/* ---------------- 5. version dedupe/sort ---------------- */
section("Version list utilities");
const dedup = dedupeVersions(["1.20.1", "1.20.1", "1.19.4", "1.20.1", "b1.7.3"]);
check("duplicates removed", dedup.length === 3, `got ${dedup.length}`);
check("keeps every distinct version", ["1.20.1", "1.19.4", "b1.7.3"].every((v) => dedup.includes(v)));

/* ---------------- 6. router regression (params.get) ---------------- */
section("Router regression: params.get is not a function");
const params = new URLSearchParams("?q=sodium&limit=5");
check("URLSearchParams has get()", typeof params.get === "function" && params.get("q") === "sodium");

/* ---------------- 7. LIVE official APIs (real data, no fabrication) ---------------- */
section("Live Modrinth API");
const MR = "https://api.modrinth.com/v2";
let live = 0;
try {
  const r = await fetch(`${MR}/search?query=sodium&limit=3`);
  if (r.ok) {
    const j = await r.json();
    check("modrinth search returns hits", Array.isArray(j.hits) && j.hits[0]?.title?.toLowerCase?.().includes("sodium") || j.hits?.length > 0);
    live++;
  } else check("modrinth search reachable", false, `HTTP ${r.status}`);
} catch (e) { check("modrinth search reachable", false, e.message); }

try {
  const r = await fetch(`${MR}/project/sodium`);
  const proj = await r.json();
  const gv = (proj.game_versions || []);
  const uniq = new Set(gv);
  check("sodium project loaded from live API", !!proj.title);
  check("every supported version returned & exact count", uniq.size === gv.length, `declared ${gv.length}, unique ${uniq.size}`);
  const r2 = await fetch(`${MR}/project/sodium/version?limit=100&offset=0&load_pagination_version=2`);
  const pv = await r2.json();
  check("version list pagination v2 returns page", Array.isArray(pv));
  live++;
} catch (e) { check("live modrinth detail", false, e.message); }

section("Live Mojang manifest");
try {
  const m = await (await fetch("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")).json();
  const counts = { release: 0, snapshot: 0, old_beta: 0, old_alpha: 0 };
  for (const v of m.versions) counts[v.type] = (counts[v.type] || 0) + 1;
  check("manifest has releases", counts.release >= 100);
  check("manifest has snapshots", counts.snapshot > 700);
  check("manifest has old_beta (b1.x history: 26 today)", counts.old_beta === 26);
  check("manifest has old_alpha (a1.x history: 35 today)", counts.old_alpha === 35);
  check("no unknown types leaking", m.versions.every((v) => counts[v.type] !== undefined));
  live++;
} catch (e) { check("mojang manifest", false, e.message); }

console.log(`\n=== RESULTS: ${PASS.length} passed, ${FAIL.length} failed of ${n} checks (${live}/3 live suites ran) ===`);
if (FAIL.length) { console.log("FAILED: " + FAIL.join(" | ")); process.exit(1); }
process.exit(0);
