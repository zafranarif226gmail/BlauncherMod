/* ============================================================
   BLauncher Mod — Search results page
   ============================================================ */
import { $, esc, fmtNum, route, page, section, skelCards, errorBlock, store, observeReveals, ICON, navigate } from "./core.js";
import { mrSearch, versionList, LOADERS, CATEGORIES, gvBadge } from "./data.js";
import { modCard, bindCards } from "./cards.js";

const SORTS = [
  { id: "relevance", label: "Best relevance" },
  { id: "downloads", label: "Most downloads" },
  { id: "follows", label: "Most followers (popularity)" },
  { id: "newest", label: "Newest creations" },
  { id: "updated", label: "Recently updated" },
];

function facetsFor({ cat = "", loader = "", ver = "", type = "" }) {
  const f = [];
  if (cat) {
    const c = CATEGORIES.find((x) => x.name === cat);
    if (c) { if (c.facet) f.push(...c.facet); }
    else f.push([`categories:${cat}`]);
  }
  if (loader) f.push([`categories:${loader}`]);
  if (ver) f.push([`versions:${ver}`]);
  if (type && type !== "all") f.push([`project_type:${type}`]);
  return f;
}

route("/search", async function searchView({ params }) {
  const q = params.get("q") || "";
  const cat = params.get("cat") || "";
  const loader = params.get("loader") || store.get("selLoader", "");
  const ver = params.get("ver") || store.get("selVersion", "");
  const sort = params.get("sort") || "relevance";
  const type = params.get("type") || "all";

  const view = $("#view");
  view.innerHTML = page(`
  <div class="cat-head reveal">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo">${ICON.search}</span> Search</h1>
    ${q ? `<span class="badge green" style="font-size:.9rem;padding:6px 12px">“${esc(q)}”</span>` : ""}
  </div>

  <div class="cat-tools">
    <div class="tools-row">
      <div class="search-inline">${ICON.search}
        <input id="qInline" placeholder="Search mods, authors, descriptions…" value="${esc(q)}" aria-label="Search query"/>
        <button class="btn btn-primary btn-sm" id="qGo">Search</button>
      </div>
      <select class="select" id="sortSel" aria-label="Sort results">
        ${SORTS.map((s) => `<option value="${s.id}" ${sort === s.id ? "selected" : ""}>${s.label}</option>`).join("")}
      </select>
    </div>

    <div class="filter-fold">
      <div class="fold-title" id="foldBtn">Filters <span class="clear-filters" id="clearFilters">× reset</span></div>
      <div class="filter-body" id="filterBody">
        <div class="chips" id="loaderChips">
          <span class="chip ${!loader ? "on" : ""}" data-lc="">Any loader</span>
          ${LOADERS.map((l) => `<span class="chip ${loader === l.id ? "on" : ""}" data-lc="${l.id}">${esc(l.name)}</span>`).join("")}
        </div>
        <div class="chips" id="typeChips" style="margin-top:8px">
          ${[["all", "Everything"], ["mod", "Mods"], ["shader", "Shaders"], ["resourcepack", "Resource packs"], ["modpack", "Modpacks"], ["datapack", "Data packs"]]
            .map(([v, l]) => `<span class="chip ${type === v ? "on" : ""}" data-tp="${v}">${l}</span>`).join("")}
        </div>
        <div style="margin-top:10px">
          <select class="select" id="verInline" aria-label="Minecraft version"></select>
        </div>
      </div>
    </div>
    <div class="result-meta" id="resMeta"></div>
  </div>

  <div class="section"><div id="results">${skelCards(8)}</div>
    <div class="load-more-wrap" id="moreWrap" hidden><button class="btn" id="moreBtn">Load more results</button></div>
  </div>`);

  /* go-back preserves history (router) */
  $("[data-goback]").addEventListener("click", () => history.back());

  const update = (patch, { reset = true } = {}) => {
    const p = new URLSearchParams(location.hash.split("?")[1] || "");
    const cur = Object.fromEntries(p.entries());
    const next = reset ? { ...cur, t: Date.now().toString(36) } : cur;
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined || v === null || v === "" || (k === "type" && v === "all")) next[k] = "";
      else next[k] = v;
    }
    for (const k of Object.keys(next)) if (next[k] === "" && ["cat", "loader", "ver", "q", "t"].includes(k)) delete next[k];
    if (next.loader !== undefined && next.loader === "") next.loader = "";
    if (next.ver === "") next.ver = "";
    navigate("/search?" + new URLSearchParams(next).toString(), { replace: false });
  };

  let qDeb;
  $("#qInline").addEventListener("input", () => {
    clearTimeout(qDeb);
    qDeb = setTimeout(() => update({ q: $("#qInline").value }), 500);
  });
  $("#qGo").addEventListener("click", () => update({ q: $("#qInline").value }));
  $("#sortSel").addEventListener("change", () => update({ sort: $("#sortSel").value }));
  document.querySelectorAll("[data-lc]").forEach((c) => c.addEventListener("click", () => {
    store.set("selLoader", c.dataset.lc);
    update({ loader: c.dataset.lc, cat });
  }));
  document.querySelectorAll("[data-tp]").forEach((c) => c.addEventListener("click", () => update({ type: c.dataset.tp })));
  $("#foldBtn")?.addEventListener("click", (e) => {
    if (e.target.id === "clearFilters") return;
    $("#filterBody").classList.toggle("collapsed");
  });
  $("#clearFilters").addEventListener("click", () => {
    store.set("selVersion", ""); store.set("selLoader", "");
    navigate("/search?reload=" + Date.now().toString(36));
  });

  /* version select (release versions) */
  const verSel = $("#verInline");
  verSel.innerHTML = `<option value="">All versions</option>`;
  try {
    const rel = await versionList("release");
    verSel.innerHTML += rel.slice(0, 60).map((v) =>
      `<option value="${esc(v.id)}" ${ver === v.id ? "selected" : ""}>${esc(v.id)}${ver === v.id ? " — selected" : ""}</option>`).join("");
    if (ver && ![...verSel.options].some((o) => o.value === ver)) {
      verSel.innerHTML += `<option value="${esc(ver)}" selected>${esc(ver)}</option>`;
    }
  } catch { verSel.disabled = true; }
  verSel.addEventListener("change", () => { store.set("selVersion", verSel.value); update({ ver: verSel.value }); });

  /* fetch + render results */
  const LIMIT = 20;
  let offset = 0;
  const effCat = cat || "";
  const buildFacets = () => facetsFor({ cat: effCat, loader, ver, type });

  async function load(append = false) {
    const box = $("#results");
    const meta = $("#resMeta");
    if (!append) box.innerHTML = skelCards(8);
    if (type && type !== "all") { /* project-type filter present */ }
    try {
      const facets = buildFacets();
      const res = await mrSearch({ q, index: sort, limit: LIMIT, offset, facets });
      if (append) {
        $("#moreWrap").hidden = false;
        box.insertAdjacentHTML("beforeend", (res.hits || []).map((h) => modCard(h)).join(""));
      } else {
        const hits = res.hits || [];
        const countTxt = res.total_hits !== undefined
          ? `<b>${fmtNum(res.total_hits)}</b> result${res.total_hits === 1 ? "" : "s"} total`
          : "";
        const chips = [];
        if (loader) chips.push(`<span class="active-filter" data-rm="loader">loader: ${esc(loader)} ×</span>`);
        if (ver) chips.push(`<span class="active-filter" data-rm="ver">MC ${esc(ver)} ×</span>`);
        if (cat) chips.push(`<span class="active-filter" data-rm="cat">${esc(cat)} ×</span>`);
        if (type && type !== "all") chips.push(`<span class="active-filter" data-rm="type">${esc(type)} ×</span>`);
        meta.innerHTML = `${countTxt}${chips.length ? " · " : ""}${chips.join(" ")}`;
        box.innerHTML = hits.length
          ? `<div class="card-grid">${hits.map((h) => modCard(h)).join("")}</div>`
          : `${section("", "")}<div class="state-block"><div class="s-emoji">🔍</div><h3>No results found</h3>
             <p>Nothing matches <b>${esc(q || "these filters")}</b>. Try a shorter keyword or remove some filters.</p>
             <button class="btn btn-primary" id="emptyReset">Reset all filters</button></div>`;
        $("#emptyReset")?.addEventListener("click", () => $("#clearFilters").click());
        document.querySelectorAll("[data-rm]").forEach((c) => c.addEventListener("click", () => {
          if (c.dataset.rm === "loader") { store.set("selLoader", ""); update({ loader: "" }); }
          else if (c.dataset.rm === "ver") { store.set("selVersion", ""); update({ ver: "" }); }
          else if (c.dataset.rm === "cat") update({ cat: "" });
          else update({ type: "" });
        }));
      }
      offset = res.hits ? offset + res.hits.length : offset;
      $("#moreWrap").hidden = (res.hits?.length || 0) < LIMIT;
      bindCards(); observeReveals();
    } catch (e) {
      box.innerHTML = errorBlock("Modrinth search failed: " + (e?.message || "unknown error"));
      $("#moreWrap").hidden = true;
    }
  }

  $("#moreBtn").addEventListener("click", () => load(true));
  await load();
});
