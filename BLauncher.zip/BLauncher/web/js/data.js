/* ============================================================
   BLauncher Mod — data layer (official public APIs only)
   ============================================================ */
import { api, store } from "./core.js";

/* ---------------- Modrinth (official public API) ---------------- */
const MR = "https://api.modrinth.com/v2";
const UA_HEADERS = { "Accept": "application/json" };

export async function mrSearch({ q = "", index = "relevance", facets = [], query = "", limit = 20, offset = 0 }) {
  const url = new URL(`${MR}/search`);
  url.searchParams.set("limit", String(limit));
  url.searchParams.set("offset", String(offset));
  url.searchParams.set("index", index);
  if (q) url.searchParams.set("query", q);
  if (query) url.searchParams.set("query", query);
  if (facets.length) url.searchParams.set("facets", JSON.stringify(facets));
  return api(url.href, { headers: UA_HEADERS, ttl: 4 * 60_000 });
}

export const mrProjectsBySlugs = (slugs) =>
  api(`${MR}/search?limit=${slugs.length + 4}&facets=${encodeURIComponent(JSON.stringify([slugs.map(s => "slug:" + s)]))}`,
    { headers: UA_HEADERS, ttl: 6 * 60_000 });

export const mrProject = (idOrSlug) =>
  api(`${MR}/project/${encodeURIComponent(idOrSlug)}`, { headers: UA_HEADERS, ttl: 10 * 60_000 });

export const mrVersions = (idOrSlug) =>
  api(`${MR}/project/${encodeURIComponent(idOrSlug)}/version`, { headers: UA_HEADERS, ttl: 8 * 60_000 });

/* paginated version fetch — Modrinth caps at 100 per page when pagination v2 is enabled.
   Follows offset pages until fewer than `limit` come back, so the exact total is shown. */
export async function mrVersionsPaged(idOrSlug, limit = 100, signalFn = null) {
  const base = `${MR}/project/${encodeURIComponent(idOrSlug)}/version`;
  const all = [];
  let offset = 0;
  /* first page may be cached; keep it at this URL for shared cache hits */
  for (;;) {
    const u = new URL(base);
    u.searchParams.set("limit", String(limit));
    u.searchParams.set("offset", String(offset));
    u.searchParams.set("load_pagination_version", "2");
    const part = await api(u.href, { headers: UA_HEADERS, ttl: offset === 0 ? 8 * 60_000 : 5 * 60_000 });
    const arr = Array.isArray(part) ? part : [];
    all.push(...arr);
    if (arr.length < limit) break;
    offset += limit;
    if (offset > 5000) break; /* hard safety cap, no infinite loops */
    if (signalFn && signalFn()) return null;
  }
  return all;
}

/* ---------------- version-tag dedupe (shared; lives in upload-lib for testability) ---------------- */
import { dedupeVersions as dedupeVersionsImpl } from "./upload-lib.js";
export const dedupeVersions = dedupeVersionsImpl;

export const mrLoaders = () =>
  api(`${MR}/tag/loader`, { headers: UA_HEADERS, ttl: 60 * 60_000 });

/* ---------------- CurseForge (official, key-gated) ----------------
   Browsers cannot call api.curseforge.com directly (key-gated AND CORS-restricted),
   so real access happens through the Cloudflare Functions proxy at /api/cf/*
   with the key kept server-side. A local user key is only used as an honest,
   best-effort fallback that may be blocked by CORS. Never faked. */
const CF = "https://api.curseforge.com/v1";
export const cfKey = () => store.get("cfKey", "");
export function cfHeaders() { const k = cfKey(); return k ? { "x-api-key": k, "Accept": "application/json" } : null; }
export class APIStatus extends Error { constructor(code) { super(code); this.code = code; } }

let cfMode = null; /* cached: "proxy" | "local" | null */

export async function cfProbeMode(serverCfg = null, force = false) {
  if (cfMode && !force) return cfMode;
  let cfg = serverCfg;
  if (!cfg) {
    try { cfg = await api("/api/config", { ttl: 60_000 }); cfMode = cfg?.cfProxy ? "proxy" : null; return cfMode; }
    catch { cfg = null; }
  } else if (cfg.cfProxy) { cfMode = "proxy"; return cfMode; }
  cfMode = cfKey() ? "local" : null;
  return cfMode;
}

export async function cfRequest(path) {
  const mode = await cfProbeMode();
  if (mode === "proxy") {
    try {
      return await api("/api/cf" + path, { ttl: 5 * 60_000, headers: { Accept: "application/json" } });
    } catch (e) {
      /* fall through to local key so a down proxy never leaves the user stuck */
      if (!cfKey()) throw new APIStatus("PROXY_DOWN:" + (e?.status || e?.message || ""));
    }
  }
  const headers = cfHeaders();
  if (!headers) throw new APIStatus("MISSING_KEY");
  try {
    return await api(CF + path, { headers, ttl: 5 * 60_000 });
  } catch (e) {
    const blocked = /Failed to fetch|NetworkError|CORS/i.test(e?.message || "");
    if (blocked) throw new APIStatus("CORS_BLOCKED");
    throw e;
  }
}

/* official CurseForge categories for the Mods class (real data only) */
export const cfCategories = async () => {
  const res = await cfRequest("/categories?gameId=432&classId=6");
  return res?.data || [];
};

/* ---------------- Minecraft version metadata (Mojang official) ---------------- */
let MAN = null; // { byId, lists: {release,snapshot,old_beta,old_alpha,all}, time }

export async function loadVersions(force = false) {
  if (MAN && !force) return MAN;
  const data = await api("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json",
    { ttl: force ? 0 : 60 * 60_000 });
  const lists = { release: [], snapshot: [], old_beta: [], old_alpha: [], all: [] };
  const byId = new Map();
  for (const v of [...data.versions].sort((a, b) => (b.releaseTime - a.releaseTime))) {
    const rec = { id: v.id, type: v.type, time: v.releaseTime, url: v.url };
    lists.all.push(rec);
    (lists[v.type] || lists.snapshot).push(rec);
    byId.set(v.id, rec);
  }
  MAN = { lists, byId, fetched: Date.now(), latest: data.latest };
  return MAN;
}
export const versionList = async (type) => (await loadVersions()).lists[type] || [];
export const versionMeta = async (id) => (await loadVersions()).byId.get(id) || null;

/* badge for a game-version string without manifest hit */
export function gvBadge(id, manifest = null) {
  const meta = manifest?.byId?.get(id);
  const t = meta ? meta.type : null;
  const txt = String(id).toLowerCase();
  let cls = "release", label = "Release";
  if (t === "old_beta" || (!t && /^b(1\.\d)/.test(txt))) { cls = "beta"; label = "Beta"; }
  else if (t === "old_alpha" || (!t && /^a(1\.\d)/.test(txt))) { cls = "alpha"; label = "Alpha"; }
  else if (t === "snapshot" || (!t && /w\d+[a-z]\d+/.test(txt)) || /(-pre|-rc)(\d+)?$/.test(txt)) { cls = "snapshot"; label = "Snapshot"; }
  return { cls, label };
}

/* ---------------- loader metas (official meta servers) ---------------- */
export const fabricGameVersions = () =>
  api("https://meta.fabricmc.net/v2/versions/game", { ttl: 30 * 60_000 });
export const quiltGameVersions = () =>
  api("https://meta.quiltmc.org/v3/versions/game", { ttl: 30 * 60_000 });
export const legacyFabricGameVersions = () =>
  api("https://meta.legacyfabric.net/v2/versions/game", { ttl: 30 * 60_000 });

/* ================= site categories (spec list) =================
   Every entry maps to real Modrinth query parameters — no invented data. */
export const CATEGORIES = [
  { name: "Performance",     icon: "⚡", facet: [["categories:optimization"]] },
  { name: "Optimization",    icon: "🚀", facet: [["categories:optimization"]] },
  { name: "Shaders",         icon: "✨", facet: [["project_type:shader"]] },
  { name: "Graphics",        icon: "🎨", query: "graphics" },
  { name: "Technology",      icon: "⚙️", facet: [["categories:technology"]] },
  { name: "Magic",           icon: "🔮", facet: [["categories:magic"]] },
  { name: "Adventure",       icon: "🗡️", facet: [["categories:adventure"]] },
  { name: "Exploration",     icon: "🧭", query: "exploration" },
  { name: "Decoration",      icon: "🪴", facet: [["categories:decoration"]] },
  { name: "World Gen",       icon: "🌍", facet: [["categories:worldgen"]] },
  { name: "Utility",         icon: "🧰", facet: [["categories:utility"]] },
  { name: "Multiplayer",     icon: "👥", facet: [["categories:social"]] },
  { name: "Maps",            icon: "🗺️", query: "maps" },
  { name: "Resource Packs",  icon: "🖌️", facet: [["project_type:resourcepack"]] },
  { name: "Modpacks",        icon: "📦", facet: [["project_type:modpack"]] },
];

/* category thumbnails come from each category's top live project icon (paneled at runtime) */

/* referenced real projects for the Featured rail */
export const FEATURED_SLUGS = [
  "sodium", "iris", "fabric-api", "lithium", "jei", "modmenu",
  "appleskin", "ferrite-core", "entityculling", "lambdynamiclights",
  "c2me-fabric", "immediatelyfast", "sodium-extra", "reeses-sodium-options",
  "dynamic-fps", "distanthorizons",
];

/* curated hero artwork — official Modrinth gallery/hero images (with CSS fallback) */
export const HERO_IMGS = [
  { url: "https://cdn.modrinth.com/data/AANobbMI/images/852537a5c98b2ff4b10216eb9035fdc9b4dc1937_350x200.webp", label: "Sodium" },
  { url: "https://cdn.modrinth.com/data/Ox5vAd5m/images/OR9uRWY.png", label: "Iris" },
];

/* descriptions for each loader (factual) */
export const LOADERS = [
  { id: "fabric",        name: "Fabric",       desc: "Lightweight, modern modding toolchain for recent Minecraft versions. Official metadata: FabricMC meta API.", icon: "F" },
  { id: "forge",         name: "Forge",        desc: "The long-standing mod loader for Minecraft Java. Compatibility data below is derived from live Modrinth project tags.", icon: "Fo" },
  { id: "neoforge",      name: "NeoForge",     desc: "Modern continuation of Forge 1.20+. Compatibility data below is derived from live Modrinth project tags.", icon: "NF" },
  { id: "quilt",         name: "Quilt",        desc: "Community-driven loader, compatible with most Fabric mods. Official metadata: QuiltMC meta API.", icon: "Q" },
  { id: "legacy-fabric", name: "Legacy Fabric",desc: "Fabric backported to older versions such as 1.8-1.12. Official metadata: Legacy Fabric meta API.", icon: "LF" },
  { id: "liteloader",    name: "LiteLoader",   desc: "Historical loader for old versions (used e.g. for 1.7-1.12 mods). No public game-version meta API — see official site.", icon: "LL" },
  { id: "rift",          name: "Rift",         desc: "Short-lived 1.13 snapshot loader. No public game-version meta API — see official archives.", icon: "R" },
];

export const LOADER_TARGETS = {
  fabric: "https://fabricmc.net/", quilt: "https://quiltmc.org/", liteloader: "http://www.liteloader.com/",
  rift: "https://github.com/Chocohead/Rift", "legacy-fabric": "https://legacyfabric.net/",
};
