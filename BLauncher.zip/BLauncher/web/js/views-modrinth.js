/* ============================================================
   BLauncher Mod — Modrinth catalogue & project details
   ============================================================ */
import { $, $$, esc, fmtNum, fmtDate, route, page, skelCards, errorBlock, stateBlock, store, toast, openModal, observeReveals, syncFavCount, ICON } from "./core.js";
import { mrSearch, mrProject, mrVersionsPaged, versionList, gvBadge, LOADERS, CATEGORIES, HERO_IMGS, dedupeVersions, loadVersions } from "./data.js";
import { modCard, bindCards, imgBlock, favBtn, netFacets } from "./cards.js";

route("/modrinth", async function modrinthCatalogue({ params, signal }) {
  const q = params.get("q") || "";
  const loader = params.get("loader") || store.get("selLoader", "");
  const ver = params.get("ver") || store.get("selVersion", "");
  const cat = params.get("cat") || "";
  const ptype = params.get("type") || "all";
  const sort = params.get("sort") || "relevance";
  const view = $("#view");

  view.innerHTML = page(`
  <div class="cat-head">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo" style="color:#57e6b8"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 16V8l9-5 9 5v8l-9 5-9-5z"/><path d="M12 8 3 8m9 0 9 0M12 8v13"/></svg></span> Modrinth Catalogue</h1>
    <span class="cat-sub">Live data from the official Modrinth v2 API — projects, versions, authors & downloads.</span>
  </div>

  <div class="cat-tools">
    <div class="tools-row">
      <div class="search-inline">${ICON.search}
        <input id="mrQ" placeholder="Search Modrinth projects…" value="${esc(q)}"/>
        <button class="btn btn-primary btn-sm" id="mrGo">Search</button>
      </div>
      <select class="select" id="mrSort" aria-label="Sort">
        ${[["relevance", "Relevance"], ["downloads", "Most downloads"], ["follows", "Most follows"], ["newest", "Newest"], ["updated", "Recently updated"]]
          .map(([v, l]) => `<option value="${v}" ${sort === v ? "selected" : ""}>${l}</option>`).join("")}
      </select>
      <select class="select" id="mrType" aria-label="Project type">
        ${[["all", "All projects"], ["mod", "Mods"], ["modpack", "Modpacks"], ["shader", "Shaders"], ["resourcepack", "Resource packs"], ["datapack", "Data packs"]]
          .map(([v, l]) => `<option value="${v}" ${ptype === v ? "selected" : ""}>${l}</option>`).join("")}
      </select>
    </div>

    <div class="filter-fold">
      <div class="fold-title" id="mrFold">Loaders <span id="mrCount"></span></div>
      <div class="filter-body" id="mrLoaderChips">
        <span class="chip ${!loader ? "on" : ""}" data-ld="">Any loader</span>
        ${LOADERS.map((l) => `<span class="chip ${loader === l.id ? "on" : ""}" data-ld="${l.id}">${esc(l.name)}</span>`).join("")}
      </div>
      <div class="fold-title" style="margin-top:10px" id="mrCatFold">Categories</div>
      <div class="filter-body" id="mrCatChips">
        <span class="chip ${!cat ? "on" : ""}" data-ct="">Any category</span>
        ${CATEGORIES.map((c) => `<span class="chip ${cat === c.name ? "on" : ""}" data-ct="${esc(c.name)}">${c.icon} ${esc(c.name)}</span>`).join("")}
      </div>
      <div class="fold-title" style="margin-top:10px">Minecraft version</div>
      <div><select class="select" id="mrVer" aria-label="Minecraft version"><option value="">All versions</option></select></div>
    </div>

    <div class="result-meta" id="mrMeta"></div>
  </div>

  <div class="section">
    <div id="mrResults">${skelCards(8)}</div>
    <div class="load-more-wrap" id="mrMoreWrap" hidden><button class="btn" id="mrMore">Load more projects</button></div>
  </div>`);

  $("[data-goback]").addEventListener("click", () => history.back());

  const upd = (patch) => {
    const p = new URLSearchParams(location.hash.split("?")[1] || "");
    for (const [k, v] of Object.entries(patch)) { if (v === "" || v === undefined || v === null) p.delete(k); else p.set(k, v); }
    if (!p.has("t")) p.set("t", Date.now().toString(36));
    location.hash = "/modrinth?" + p.toString();
  };

  $("#mrGo").addEventListener("click", () => upd({ q: $("#mrQ").value }));
  let qT; $("#mrQ").addEventListener("input", () => { clearTimeout(qT); qT = setTimeout(() => upd({ q: $("#mrQ").value }), 550); });
  $("#mrSort").addEventListener("change", () => upd({ sort: $("#mrSort").value }));
  $("#mrType").addEventListener("change", () => upd({ type: $("#mrType").value }));
  $("#mrFold").addEventListener("click", (e) => $("#mrLoaderChips").classList.toggle("collapsed"));
  $("#mrCatFold").addEventListener("click", () => $("#mrCatChips").classList.toggle("collapsed"));
  document.querySelectorAll("[data-ld]").forEach((c) => c.addEventListener("click", () => {
    const nl = c.dataset.ld;
    store.set("selLoader", nl);
    upd({ loader: nl });
  }));
  document.querySelectorAll("[data-ct]").forEach((c) => c.addEventListener("click", () => upd({ cat: c.dataset.ct })));

  const verSel = $("#mrVer");
  try {
    const rel = await versionList("release");
    verSel.innerHTML = `<option value="">All versions (release)</option>` + rel.slice(0, 60)
      .map((v) => `<option value="${esc(v.id)}" ${ver === v.id ? "selected" : ""}>${esc(v.id)}</option>`).join("");
    if (ver && ![...verSel.options].some((o) => o.value === ver)) verSel.innerHTML += `<option value="${esc(ver)}" selected>${esc(ver)}</option>`;
  } catch { verSel.disabled = true; }
  verSel.addEventListener("change", () => { store.set("selVersion", verSel.value); upd({ ver: verSel.value }); });

  const LIMIT = 20; let offset = 0;
  async function load(append = false) {
    const box = $("#mrResults");
    if (!append) box.innerHTML = skelCards(8);
    try {
      const facets = [
        ...(cat ? (CATEGORIES.find((x) => x.name === cat)?.facet || [["categories:" + cat]]) : []),
        ...netFacets(loader || null, ver || null),
        ...(ptype !== "all" ? [[`project_type:${ptype}`]] : []),
      ];
      const res = await mrSearch({ q, index: sort, limit: LIMIT, offset, facets });
      if (signal()) return;
      if (append) {
        box.insertAdjacentHTML("beforeend", (res.hits || []).map((h) => modCard(h)).join(""));
      } else {
        const chips = [];
        if (loader) chips.push(`<span class="active-filter" data-rm="loader">${esc(loader)} ×</span>`);
        if (ver) chips.push(`<span class="active-filter" data-rm="ver">MC ${esc(ver)} ×</span>`);
        if (cat) chips.push(`<span class="active-filter" data-rm="cat">${esc(cat)} ×</span>`);
        if (ptype !== "all") chips.push(`<span class="active-filter" data-rm="type">${esc(ptype)} ×</span>`);
        $("#mrMeta").innerHTML = `<b>${fmtNum(res.total_hits ?? (res.hits || []).length)}</b> projects${chips.length ? " · " : ""}${chips.join(" ")}`;
        const hits = res.hits || [];
        box.innerHTML = hits.length
          ? `<div class="card-grid">${hits.map((h) => modCard(h)).join("")}</div>`
          : stateBlock("🫥", "No projects found", "Nothing matches this combination of filters on Modrinth. Try loosening a filter.");
        document.querySelectorAll("[data-rm]").forEach((c) => c.addEventListener("click", () => {
          if (c.dataset.rm === "loader") { store.set("selLoader", ""); upd({ loader: "" }); }
          else if (c.dataset.rm === "ver") { store.set("selVersion", ""); upd({ ver: "" }); }
          else if (c.dataset.rm === "cat") upd({ cat: "" });
          else upd({ type: "" });
        }));
      }
      offset += (res.hits || []).length;
      $("#mrMoreWrap").hidden = !(res.hits || []).length || (res.hits || []).length < LIMIT;
      bindCards(); observeReveals();
    } catch (e) {
      box.innerHTML = errorBlock("Modrinth API unreachable: " + (e?.message || "network error"));
      $("#mrMoreWrap").hidden = true;
    }
  }
  $("#mrMore").addEventListener("click", () => load(true));
  await load();
});

/* ---------------- helpers ---------------- */
function sanitize(html) {
  return String(html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<(iframe|object|embed|style)[\s\S]*?<\/\1>/gi, "")
    .replace(/^<(iframe|object|embed|style)[^>]*>$/gi, "")
    .replace(/\son\w+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son\w+\s*=\s*'[^']*'/gi, "")
    .replace(/javascript:/gi, "")
    .replace(/<a /g, '<a target="_blank" rel="noopener noreferrer" ');
}

/* ---------------- detail ---------------- */
route("/modrinth/mod/:id", async function modrinthDetail({ routeParams, signal }) {
  const id = routeParams.id;
  const view = $("#view");
  view.innerHTML = page(`<div class="skip"><div class="detail-banner"></div>
    <div class="detail-body"><div class="skel skel-card"></div></div></div>`);
  let proj, vers, authorName = "", slugHits = [];
  try {
    [proj, vers, { hits: slugHits }] = await Promise.all([
      mrProject(id),
      mrVersionsPaged(id, 100, signal).then((arr) => { if (arr === null) throw new Error("__stale__"); return arr || []; })
        .catch((e) => { if (e?.message === "__stale__") throw e; return mrVersionsPaged(id, 100); }),
      mrSearch({ limit: 1, facets: [[`slug:${id}`]] }).catch(() => ({ hits: [] })),
    ]);
  } catch (e) {
    view.innerHTML = page(errorBlock("Could not load this project from Modrinth: " + (e?.message || "network error")));
    return;
  }
  if (signal()) return;
  authorName = slugHits?.[0]?.author || "";

  /* exact, deduped list of every genuinely supported Minecraft version */
  const MAN = await loadVersions().catch(() => null);
  const supported = dedupeVersions([
    ...(proj.game_versions || []),
    ...((vers || []).flatMap((v) => v.game_versions || [])),
  ], MAN?.byId);

  store.addRecent({ id: proj.id, source: "modrinth", slug: proj.slug, title: proj.title, icon: proj.icon_url, author: authorName || "—", downloads: proj.downloads, versions: (proj.game_versions || []).slice(-2), loaders: proj.loaders || [] });

  const g = proj.gallery || [];
  const banner = g[0]?.url || "";
  const loaders = proj.loaders || [];
  const cVis = (proj.categories || []).filter((c) => !loaders.includes(c));
  const latest = vers?.[0];
  const latestFile = latest?.files?.find((f) => f.primary) || latest?.files?.[0];
  const favItem = { id: proj.id, source: "modrinth", slug: proj.slug, title: proj.title, icon: proj.icon_url, author: authorName, desc: proj.description, versions: (proj.game_versions || []).slice(-2), loaders };
  const isFav = store.isFav(favItem.id);

  view.innerHTML = page(`
  <div class="detail-banner">${banner ? `<img src="${esc(banner)}" alt="${esc(proj.title)} gallery image" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.remove()"/>` : ""}</div>
  <div class="detail-body">
    <div class="cat-head" style="padding-top:14px">
      <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
      <span class="src-badge modrinth">Modrinth project</span>
    </div>
    <div class="detail-top">
      ${imgBlock(proj.icon_url, proj.title + " icon", "detail-icon", (proj.title || "?")[0]?.toUpperCase() || "?")}
      <div class="detail-titles">
        <h1 class="detail-title">${esc(proj.title)}</h1>
        <div class="detail-meta">
          <span>${ICON.user} ${esc(authorName || proj.author?.name || "Community author")}</span>
          <span class="stat">${ICON.down} ${(+proj.downloads || 0).toLocaleString()} downloads</span>
          <span>♥ ${fmtNum(proj.followers || 0)} followers</span>
          <span>${ICON.clock} updated ${fmtDate(proj.updated)}</span>
        </div>
      </div>
      <div class="detail-actions">
        <button class="fav-heart big ${isFav ? "on" : ""}" data-fav-detail='${esc(JSON.stringify(favItem))}' style="position:static;width:44px;height:44px" aria-label="Toggle favorite">${isFav ? ICON.heart : ICON.heartReg}</button>
        ${latestFile?.url ? `<a class="btn btn-primary" href="${esc(latestFile.url)}" target="_blank" rel="noopener noreferrer">${ICON.down} Download latest${latest?.version_number ? " · " + esc(latest.version_number) : ""}</a>` : ""}
        <a class="btn" href="https://modrinth.com/${esc(proj.project_type || "mod")}/${esc(proj.slug)}" target="_blank" rel="noopener noreferrer">Official Modrinth page ↗</a>
      </div>
    </div>

    <div class="detail-cols">
      <div class="detail-main">
        <h2 style="margin-top:0">About this ${esc(proj.project_type || "project")}</h2>
        <p class="md-body" style="color:var(--text)">${esc(proj.description || "")}</p>
        <div class="md-body">${sanitize(proj.body)}</div>

        ${g.length ? `<h2>Screenshots</h2><div class="shots-grid">
          ${g.map((s) => `<figure class="shot" data-zoom="${esc(s.url)}" title="Open image">
            <img src="${esc(s.thumbnail_url || s.url)}" alt="${esc(s.title || "Screenshot")}" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.parentElement.style.display='none'"/>
            ${s.title ? `<figcaption class="shot-title">${esc(s.title)}</figcaption>` : ""}
          </figure>`).join("")}
        </div>` : ""}

        <h2>Supported Minecraft versions <span class="badge release">${supported.length}</span></h2>
        <p class="md-body dim">
          Every version this project genuinely supports, pulled from the project's declared tags and all
          ${vers.length} release entries — duplicates removed, sorted newest first.
          ${supported.length === 1 ? "This project supports exactly 1 version." : `This project supports exactly ${supported.length} versions.`}
        </p>
        <div class="ver-chips" id="gvGridFull">
          ${supported.slice(0, 36).map((vID) => { const b = gvBadge(vID, MAN); return `<span class="badge ${b.cls}" title="${esc(b.label)}">${esc(vID)}</span>`; }).join("") || `<span class="badge old">no compatibility data published</span>`}
        </div>
        ${supported.length > 36 ? `<button class="btn btn-sm" id="gvShowAll" style="margin:10px 0 18px">Show all ${supported.length} supported versions</button>` : ""}

        <h2>Version history &amp; changelogs <span class="badge release">${vers.length}</span></h2>
        <div class="ver-list">
          ${(vers || []).slice(0, 30).map((v) => {
            const f = v.files?.find((x) => x.primary) || v.files?.[0];
            const lg = (v.changelog || "").trim();
            return `<div class="ver-item">
              <div class="vi-row">
                <span class="vi-name">${esc(v.version_number || v.name || v.id)}</span>
                <span class="vi-date">${fmtDate(v.date_published)}</span>
                <span class="badge ${v.version_type === "release" ? "release" : v.version_type === "beta" ? "beta" : "alpha"}">${esc(v.version_type || "release")}</span>
              </div>
              <div class="vi-tags">
                ${(v.loaders || []).map((l) => `<span class="badge green">${esc(l)}</span>`).join("")}
                ${(v.game_versions || []).slice(0, 3).map((gv) => { const b = gvBadge(gv); return `<span class="badge ${b.cls}">MC ${esc(gv)}</span>`; }).join("")}
                ${(v.game_versions || []).length > 3 ? `<span class="badge old">+${v.game_versions.length - 3} more</span>` : ""}
              </div>
              <div class="vi-foot">
                ${f?.url ? `<a class="btn btn-sm" href="${esc(f.url)}" target="_blank" rel="noopener noreferrer" download>${ICON.down} ${esc(f.filename || "Download")}</a>` : ""}
                ${lg ? `<button class="btn btn-sm btn-ghost" data-cl="${esc(v.id)}">Changelog</button>` : ""}
              </div>
              ${lg ? `<div class="changelog" data-cl-body="${esc(v.id)}">${sanitize(lg)}</div>` : ""}
            </div>`;
          }).join("")}
          ${(vers || []).length > 30 ? `<div class="ver-item" style="justify-content:center;text-align:center"><span class="md-body">+ ${(vers || []).length - 30} older releases hidden — ${vers.length} releases total</span></div>` : ""}
          ${(vers || []).length ? "" : "<p class='md-body'>No published versions.</p>"}
        </div>
      </div>

      <aside class="detail-side side-panel">
        <h3 style="margin-top:0">Project info</h3>
        <div class="side-stat"><span class="k">Source</span><span class="v">Modrinth</span></div>
        <div class="side-stat"><span class="k">Type</span><span class="v">${esc(proj.project_type || "mod")}</span></div>
        <div class="side-stat"><span class="k">ID</span><span class="v">${esc(proj.id)}</span></div>
        <div class="side-stat"><span class="k">Created</span><span class="v">${fmtDate(proj.published)}</span></div>
        <div class="side-stat"><span class="k">Updated</span><span class="v">${fmtDate(proj.updated)}</span></div>
        <div class="side-stat"><span class="k">Versions</span><span class="v">${supported.length} MC</span></div>
        ${proj.license ? `<div class="side-stat"><span class="k">License</span><span class="v"><a href="${esc(proj.license.url || "#")}" target="_blank" rel="noopener noreferrer">${esc(proj.license.name || proj.license.id || "—")}</a></span></div>` : ""}
        <h3>Loaders</h3>
        <div class="chips">${loaders.map((l) => `<span class="badge green">${esc(l)}</span>`).join("") || "<span class='badge old'>not loader-specific</span>"}</div>
        <h3>Categories</h3>
        <div class="chips">${cVis.map((c) => `<span class="badge">${esc(c.replace(/-/g, " "))}</span>`).join("") || "—"}</div>
        <h3>Links</h3>
        <div class="chips">
          ${(Object.entries(proj.links || {})).filter(([, v]) => v).map(([k, v]) => `<a class="badge" href="${esc(v)}" target="_blank" rel="noopener noreferrer">${esc(k)}</a>`).join("")}
          <a class="badge green" href="https://modrinth.com/${esc(proj.project_type || "mod")}/${esc(proj.slug)}" target="_blank" rel="noopener noreferrer">modrinth.com ↗</a>
        </div>
      </aside>
    </div>
  </div>`);

  $("[data-goback]").addEventListener("click", () => history.back());
  $("#gvShowAll")?.addEventListener("click", () => {
    const g2 = $("#gvGridFull");
    g2.innerHTML = supported.map((vID) => { const b = gvBadge(vID, MAN); return `<span class="badge ${b.cls}" title="${esc(b.label)}">${esc(vID)}</span>`; }).join("");
    $("#gvShowAll").remove();
  });
  $$("[data-cl]").forEach((b) => b.addEventListener("click", () => {
    const body = $(`[data-cl-body="${b.dataset.cl}"]`);
    if (body) { const open = body.classList.toggle("open"); b.textContent = open ? "Hide changelog" : "Changelog"; }
  }));
  $$("[data-zoom]").forEach((fig) => fig.addEventListener("click", () => {
    openModal(`<img class="modal-img" src="${esc(fig.dataset.zoom)}" alt="Screenshot" loading="lazy"/>`);
  }));
  const favBtnEl = $("[data-fav-detail]");
  favBtnEl.addEventListener("click", () => {
    const item = JSON.parse(favBtnEl.dataset.favDetail);
    const on = store.toggleFav(item);
    favBtnEl.classList.toggle("on", on);
    favBtnEl.innerHTML = on ? ICON.heart : ICON.heartReg;
    syncFavCount();
    toast(on ? "Added to favorites" : "Removed from favorites");
  });
});
