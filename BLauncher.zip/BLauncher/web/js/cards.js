/* ============================================================
   BLauncher Mod — shared UI: mod cards, image block, search box
   ============================================================ */
import { $, $$, esc, ICON, store, syncFavCount, toast } from "./core.js";
import { mrSearch, gvBadge, versionList, CATEGORIES } from "./data.js";

/* ---------- image with fallback ---------- */
export function imgBlock(src, alt, cls = "", fallbackLetter = "B") {
  if (!src) return `<div class="${cls} mod-icon-fallback">${esc(fallbackLetter)}</div>`;
  return `<img src="${esc(src)}" alt="${esc(alt)}" class="${cls}" loading="lazy" decoding="async" referrerpolicy="no-referrer"
    onerror="this.outerHTML='<div class=&quot;${cls} mod-icon-fallback&quot;>${esc(fallbackLetter)}</div>'" />`;
}

/* favorite toggle wired per-render */
export function favBtn(item) {
  const on = store.isFav(item.id);
  const itemLight = { id: item.id, source: item.source || "modrinth", slug: item.slug, title: item.title, icon: item.icon, author: item.author, desc: item.description || item.desc, versions: item.versions, loaders: item.loaders };
  return `<button class="fav-heart ${on ? "on" : ""}" data-fav="${esc(JSON.stringify(itemLight))}" aria-label="${on ? "Remove from" : "Add to"} favorites" title="${on ? "Remove from favorites" : "Add to favorites"}">${ICON.heart}</button>`;
}

export const loaderBadge = (l) => `<span class="badge green">${esc(l)}</span>`;

export function modCard(item, { source = "modrinth", routeBase = "/modrinth/mod" } = {}) {
  const slug = item.slug || item.id;
  const icon = item.icon_url || item.icon || "";
  const letter = (item.title || "?").trim().charAt(0).toUpperCase();
  const cats = (item.display_categories || item.categories || []).filter((c) =>
    !["fabric", "forge", "quilt", "neoforge", "liteloader", "rift", "legacy-fabric"].includes(c)).slice(0, 2);
  const loaders = (item.categories || item.loaders || []).filter((c) =>
    ["fabric", "forge", "quilt", "neoforge", "liteloader", "rift", "legacy-fabric"].includes(c)).slice(0, 3);
  const vList = item.versions || [];
  const show = vList.slice(0, 4);
  const rest = vList.length - show.length;
  const fullList = vList.join(", ");
  return `
  <article class="mod-card reveal" data-href="#${routeBase}/${encodeURIComponent(slug)}" tabindex="0" role="link" aria-label="${esc(item.title || "")}">
    ${favBtn({ ...item, source })}
    <div class="mod-head">
      ${imgBlock(icon, `${item.title || ""} icon`, "mod-icon", letter)}
      <div class="mod-titles">
        <div class="mod-name">${esc(item.title)}</div>
        <div class="mod-author">${ICON.user} <span>${esc(item.author || "Unknown author")}</span></div>
      </div>
    </div>
    <p class="mod-desc">${esc((item.description || item.summary || "")).slice(0, 180)}</p>
    <div class="mod-meta">
      <span class="stat">${ICON.down} ${(+item.downloads || 0).toLocaleString()}</span>
      ${vList.length ? `<span class="badge old" title="Supports exactly ${vList.length} Minecraft version${vList.length === 1 ? "" : "s"}: ${esc(fullList)}">${vList.length} MC</span>` : ""}
      <span class="badge green">${esc(item.project_type || "mod")}</span>
    </div>
    <div class="chips" title="${esc(fullList)}">
      ${show.map((v) => `<span class="badge ${gvBadge(v).cls}">MC ${esc(v)}</span>`).join("")}
      ${rest > 0 ? `<span class="badge old" title="Plus ${rest} more: ${esc(vList.slice(4).join(", "))}">+${rest} more</span>` : ""}
      ${vList.length === 0 ? `<span class="badge old" title="No version tags published">versions not published</span>` : ""}
      ${loaders.map(loaderBadge).join("")}
      ${cats.map((c) => `<span class="badge">${esc(c.replace(/-/g, " "))}</span>`).join("")}
      <span class="src-badge ${esc(source)}">${source === "curseforge" ? "CurseForge" : "Modrinth"}</span>
    </div>
  </article>`;
}

/* wire all cards + fav buttons inside a root */
export function bindCards(root = $("#view")) {
  $$(".mod-card[data-href]", root).forEach((card) => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".fav-heart")) return;
      location.hash = card.dataset.href;
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.target.closest(".fav-heart")) location.hash = card.dataset.href;
    });
  });
  $$("[data-fav]", root).forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const item = JSON.parse(btn.dataset.fav);
      const on = store.toggleFav(item);
      btn.classList.toggle("on", on);
      btn.innerHTML = on ? ICON.heart : ICON.heartReg;
      syncFavCount();
      toast(on ? `${item.title} added to favorites` : `${item.title} removed from favorites`);
    });
  });
}

/* ---------- global net (facets) built from selected version + loader ---------- */
export function netFacets(loader = null, version = null) {
  const f = [];
  if (loader) f.push([`categories:${loader}`]);
  if (version) f.push([`versions:${version}`]);
  return f;
}

/* ---------- search box with suggestions + history ---------- */
export function searchBoxHTML({ id = "heroSearch", value = "", btnLabel = "Search" } = {}) {
  return `
  <form class="search-wrap s-outer" id="${id}Form" autocomplete="off" role="search">
    <div class="search-bar">
      <span class="s-icon">${ICON.search}</span>
      <input id="${id}" type="text" placeholder="Search mods, authors, categories… (e.g. performance, Iris, magic)" value="${esc(value)}" aria-label="Search mods" />
      <button class="s-btn" type="submit">${btnLabel}</button>
    </div>
    <div class="s-panel" id="${id}Panel" role="listbox" aria-label="Search suggestions"></div>
  </form>`;
}

let sugToken = 0;
let lastDocClick = null;
export function wireSearchBox(inputId, { onSearch = null, hashTemplate = "/search?q={q}&t={t}" } = {}) {
  const input = $(`#${inputId}`);
  const panel = $(`#${inputId}Panel`);
  const form = $(`#${inputId}Form`);
  if (!input || !panel) return;

  const go = () => {
    const q = input.value.trim();
    if (onSearch) onSearch(q);
    else location.hash = hashTemplate.replace("{q}", encodeURIComponent(q)).replace("{t}", Date.now().toString(36));
    if (q) store.pushHistory(q);
    close();
  };

  const close = () => { panel.classList.remove("open"); panel.innerHTML = ""; };
  const open = async () => {
    const q = input.value.trim();
    const token = ++sugToken;
    const hist = store.history().filter((h) => !q || h.toLowerCase().includes(q.toLowerCase())).slice(0, 5);
    const catMatches = q ? CATEGORIES.filter((c) => c.name.toLowerCase().includes(q.toLowerCase())).slice(0, 3) : [];
    let mods = [];
    if (q.length >= 2) {
      try {
        const res = await mrSearch({ q, limit: 5 });
        if (token === sugToken) mods = res.hits || [];
      } catch { /* suggestions fail silently */ }
    }
    if (token !== sugToken) return; // stale
    const rows = [];
    const esc2 = esc;
    for (const m of mods) {
      rows.push(`<div class="s-row" data-q="${esc2(m.title || "")}" data-kind="mod">
        ${imgBlock(m.icon_url, "", "thumb", (m.title || "?")[0]?.toUpperCase() || "?")}
        <div class="txt"><div class="t">${esc2(m.title)}</div><div class="d">${esc2((m.description || "").slice(0, 60))}</div></div>
        <span class="badge green">Modrinth</span></div>`);
    }
    for (const c of catMatches) {
      rows.push(`<div class="s-row" data-q="${esc2(c.name)}" data-kind="cat">
        <span class="cc-icon" style="width:34px;text-align:center;font-size:1.05rem">${c.icon}</span>
        <div class="txt"><div class="t">${esc2(c.name)}</div><div class="d">Category</div></div>
        <span class="badge">category</span></div>`);
    }
    for (const h of hist) {
      rows.push(`<div class="s-row" data-q="${esc2(h)}" data-kind="hist">
        <span style="width:34px;text-align:center;color:var(--text-faint)">${ICON.clock}</span>
        <div class="txt"><div class="t">${esc2(h)}</div><div class="d">Recent search</div></div>
        <button class="badge" data-hist-del="${esc2(h)}" title="Remove">×</button></div>`);
    }
    if (!rows.length) {
      panel.innerHTML = `<div class="s-empty">${q ? "No matching mods found — try a different keyword." : "Type to search mods & categories. Your searches are saved on this device."}</div>`;
    } else {
      const clearBtn = hist.length && !q ? `<button class="s-clear" data-clear-hist>Clear search history</button>` : "";
      panel.innerHTML = rows.join("") + clearBtn;
    }
    panel.classList.add("open");
  };
  const debounced = (() => { let t; return () => { clearTimeout(t); t = setTimeout(open, 220); }; })();

  input.addEventListener("input", debounced);
  input.addEventListener("focus", open);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); go(); } });
  if (lastDocClick) document.removeEventListener("click", lastDocClick);
  const docClick = (e) => { if (!panel.contains(e.target) && e.target !== input && e.target !== input.parentElement) close(); };
  document.addEventListener("click", docClick);
  lastDocClick = docClick;
  panel.addEventListener("click", (e) => {
    const del = e.target.closest("[data-hist-del]");
    if (del) {
      e.stopPropagation();
      const cur = store.history().filter((h) => h !== del.dataset.histDel);
      store.set("searchHistory", cur);
      open();
      return;
    }
    if (e.target.closest("[data-clear-hist]")) {
      store.clearHistory(); open(); toast("Search history cleared");
      return;
    }
    const row = e.target.closest(".s-row");
    if (row) { input.value = row.dataset.q; go(); }
  });
  form.addEventListener("submit", (e) => { e.preventDefault(); go(); });
}

/* count-up number animation (lightweight) */
export function countUp(el, to) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { el.textContent = to.toLocaleString(); return; }
  const dur = 900, start = performance.now();
  const step = (t) => {
    const p = Math.min(1, (t - start) / dur);
    el.textContent = Math.floor(to * (1 - Math.pow(1 - p, 3))).toLocaleString();
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
