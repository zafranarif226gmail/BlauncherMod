/* ============================================================
   BLauncher Mod — app bootstrap
   ============================================================ */
import { $, $$, render, store, syncFavCount, observeReveals, toast } from "./core.js";

/* route modules register themselves on import */
import "./views-home.js";
import "./views-search.js";
import "./views-versions.js";
import "./views-modrinth.js";
import "./views-cf.js";
import "./views-misc.js";
import "./views-upload.js";
import "./views-publish.js";
import { renderAccountArea } from "./auth.js";

window.BLauncherMod = { version: "1.2.0" };

/* ---------- theme ---------- */
function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  $("meta[name='theme-color']")?.setAttribute("content", t === "light" ? "#eef5ef" : "#07130b");
}
applyTheme(store.get("theme", "dark"));
$("#themeToggle")?.addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
  store.set("theme", next);
  applyTheme(next);
});

/* ---------- performance mode (very fast on Android 11 / 6 GB) ---------- */
function daysPerf() {
  /* auto-enable on weak CPUs or reduced-motion, unless the user chose explicitly */
  const auto = (navigator.hardwareConcurrency || 8) <= 4 ||
    window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
  if (auto && localStorage.getItem("blauncherMod.v1.perfChosen") !== "1") store.set("perfMode", true);
  const low = !!store.get("perfMode", false);
  document.documentElement.dataset.perf = low ? "low" : "normal";
  const btn = $("#perfToggle");
  if (btn) {
    btn.setAttribute("aria-pressed", String(low));
    btn.classList.toggle("on", low);
    btn.title = low ? "Performance mode ON — animations reduced" : "Performance mode — full animations";
  }
}
function perfChosen() { localStorage.setItem("blauncherMod.v1.perfChosen", "1"); }
daysPerf();
$("#perfToggle")?.addEventListener("click", () => {
  perfChosen();
  store.set("perfMode", !store.get("perfMode", false));
  daysPerf();
  toast(store.get("perfMode", false) ? "Performance mode ON — reduced animations, faster scrolling" : "Performance mode OFF — full animations", { ms: 1800 });
});

/* ---------- mobile nav ---------- */
$("#navToggle")?.addEventListener("click", () => {
  const nav = $("#mainNav");
  const open = nav.classList.toggle("open");
  $("#navToggle").setAttribute("aria-expanded", open ? "true" : "false");
});
$$("#mainNav .nav-link").forEach((a) => a.addEventListener("click", () => $("#mainNav")?.classList.remove("open")));

/* ---------- back to top ---------- */
const backTop = $("#backTop");
let st = null;
window.addEventListener("scroll", () => {
  if (st) return;
  st = requestAnimationFrame(() => {
    backTop.hidden = window.scrollY < 640;
    st = null;
  });
}, { passive: true });
backTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

/* ---------- global nav links (data-nav) ---------- */
document.addEventListener("click", (e) => {
  const a = e.target.closest("a[data-nav]");
  if (!a) return;
  const href = a.getAttribute("href");
  if (href?.startsWith("#")) {
    e.preventDefault();
    if (location.hash === href) render();
    else location.hash = href;
  }
});

/* ---------- boot ---------- */
let booted = false;
function boot() {
  if (booted) return;
  booted = true;
  syncFavCount();
  daysPerf();
  renderAccountArea();
  render();
}
window.addEventListener("hashchange", () => { render(); });
document.addEventListener("DOMContentLoaded", boot);
if (document.readyState !== "loading") boot();
