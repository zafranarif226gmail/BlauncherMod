/* ============================================================
   BLauncher Mod — Publish to Modrinth (official API, real)
   • Publishes through https://api.modrinth.com/v2/project with the
     USER'S OWN Modrinth Personal Access Token — sent directly by
     the browser to api.modrinth.com; never stored on any server.
   • Drafts, live preview, confirmation dialog, real upload progress.
   • Success is shown ONLY when Modrinth answers 2xx with a slug.
   • CurseForge publishing is gated behind genuine authorization
     (their programme only accepts approved partners) — shown
     honestly, never faked.
   • Requires Google login (hosting-service gate, see auth.js).
   ============================================================ */
import { $, $$, esc, page, route, store, toast, openModal, observeReveals, stateBlock, ICON, render } from "./core.js";
import { gateOrRender, BACKEND, currentUser } from "./auth.js";

const D_KEY = "publishDrafts";

const inputVal = (id) => ($(id)?.value || "").trim();
const charCount = (el, txtEl) => { const n = el.value.length; txtEl.textContent = `${n} characters`; };

let mdSeq = 0;
/* tiny, SAFE markdown preview: escape first, then apply a minimal, closed set of
   built-in formats (headings, bold/italic, code, links, lists). No raw HTML. */
function mdPreview(src) {
  mdSeq++;
  let s = esc(String(src || ""));
  s = s.replace(/```([\s\S]*?)```/g, (_, c) => `<pre><code>${c}</code></pre>`);
  s = s.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  s = s.replace(/^### (.*)$/m, "<h3>$1</h3>").replace(/^## (.*)$/m, "<h2>$1</h2>").replace(/^# (.*)$/m, "<h1>$1</h1>");
  s = s.replace(/^\s*[-*] (.*)$/m, "<li>$1</li>");
  s = s.replace(/(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g, "<ul>$1</ul>");
  s = s.replace(/^&gt; (.*)$/m, "<blockquote>$1</blockquote>");
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>").replace(/(^|\s)\*([^*\n]+)\*(?=\s|$)/g, "$1<i>$2</i>");
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  s = s.split(/\n{2,}/).map((p) => /^<(h\d|ul|blockquote|pre)/.test(p.trim()) ? p : `<p>${p.replace(/\n/g, "<br/>")}</p>`).join("");
  return s;
}

route("/publish", async function publishView() {
  const view = $("#view");
  const user = await gateOrRender(view, "Publishing needs a Google sign-in",
    "Publishing changes outside catalogues under your author account. Sign in with Google to publish to Modrinth. Browsing and downloads never require login.");
  if (!user) {
    document.addEventListener("authchanged", () => { if (currentUser()?.user) render(); }, { once: true });
    return;
  }

  const cfg = await BACKEND.fetch();
  const drafts = store.get(D_KEY, []);

  view.innerHTML = page(`
  <div class="cat-head">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo">🚀</span> Publish</h1>
    <span class="cat-sub">Publish a project to <b>Modrinth</b> through their official API using your own Personal Access Token. Every step is real — nothing pretends to succeed.</span>
  </div>

  <div class="pub-tabs" role="tablist">
    <button class="ver-tab on" data-rt="modrinth">MODRINTH<small>Official publishing API</small></button>
    <button class="ver-tab" data-rt="curseforge">CURSEFORGE<small>Authorization required</small></button>
    <button class="ver-tab" data-rt="drafts">DRAFTS<small>${drafts.length} saved</small></button>
  </div>
  <div id="pubBody"></div>`);

  $("[data-goback]").addEventListener("click", () => history.back());
  view.querySelectorAll("[data-rt]").forEach((t) => t.addEventListener("click", () => {
    view.querySelectorAll("[data-rt]").forEach((x) => x.classList.toggle("on", x === t));
    setActiveTab(t.dataset.rt);
  }));

  const body = $("#pubBody");
  function setActiveTab(rt) {
    if (rt === "curseforge") return renderCFPublish(body, cfg);
    if (rt === "drafts") return renderDrafts(body);
    renderModrinth(body);
  }

  let currentDraft = null;
  function renderModrinth(body) {
    body.innerHTML = `
    <div class="section pub-grid">
      <div>
        <div class="pub-note ok-note">✅ Your token goes <b>straight to api.modrinth.com</b> over HTTPS from your browser. It is kept in memory or (optionally) this device's session only — BLauncher never receives it.</div>
        <label class="opt-line">Modrinth Personal Access Token (PAT)
          <input id="mrPAT" type="password" placeholder="From modrinth.com/settings/pats — starts with mra_…" autocomplete="off"/>
        </label>
        <label class="chk-line"><input type="checkbox" id="mrPATRemember"/> Remember token in this browser session (sessionStorage — cleared when the tab closes)</label>
        <h3 style="margin:16px 0 4px">Project details</h3>
        <div class="det-grid two-col">
          <label>Name <input id="pName" placeholder="My Awesome Mod"/></label>
          <label>Slug (URL id) <input id="pSlug" placeholder="my-awesome-mod"/></label>
        </div>
        <label class="opt-line">Short description <input id="pDesc" placeholder="One line shown on cards"/></label>
        <label class="opt-line">Full body (Modrinth Markdown)
          <textarea id="pBody" rows="7" placeholder="# My Awesome Mod&#10;Collects and crafts..."></textarea>
        </label>
        <span class="dim" id="bodyCount"></span>
        <h3 style="margin:16px 0 4px">Compatibility</h3>
        <div class="det-grid two-col">
          <label>Loaders <input id="pLoaders" placeholder="fabric, forge…"/></label>
          <label>Minecraft versions <input id="pVers" placeholder="1.20.1, 1.19.4"/></label>
        </div>
        <div class="det-grid two-col">
          <label>Side (client) <select id="pClient"><option>required</option><option>optional</option><option>unsupported</option></select></label>
          <label>Side (server) <select id="pServer"><option>required</option><option>optional</option><option>unsupported</option></select></label>
        </div>
        <label class="opt-line">Categories <input id="pCats" placeholder="technology, magic…"/></label>
        <h3 style="margin:16px 0 4px">First release file</h3>
        <label class="dropzone mini" id="pFileZone">
          <input type="file" id="pFile" accept=".jar,.zip" hidden/>
          <div class="dz-ic">📁</div>
          <p><b id="pFileName">Choose the .jar file to publish</b></p>
          <p class="dim">The file is read by your browser, hashed for a preview and uploaded to Modrinth's server on publish.</p>
        </label>
        <div class="up-actions-row">
          <button class="btn" id="pSaveDraft">💾 Save draft</button>
          <button class="btn" id="pPreview">👁 Preview</button>
          <button class="btn btn-primary" id="pPublish">🚀 Publish to Modrinth</button>
        </div>
        <div class="progress-wrap" id="pProgWrap" hidden>
          <div class="progress"><div class="progress-bar" id="pProgBar"></div></div>
          <span class="prog-txt" id="pProgTxt">0%</span>
        </div>
        <div id="pResult"></div>
      </div>
      <aside class="upload-side">
        <h3 style="margin-top:0">What is sent</h3>
        <ul class="mini-steps">
          <li>Token authenticity is checked live by Modrinth (GET <code>/v2/user</code>) before the publish dialog opens.</li>
          <li>Your project is created via <code>POST /v2/project</code> — the official endpoint.</li>
          <li>If Modrinth rejects anything (duplicate slug, bad token, missing field), the exact error is shown below — nothing is faked.</li>
          <li>Tokens come from <a href="https://modrinth.com/settings/pats" target="_blank" rel="noopener noreferrer">modrinth.com/settings/pats</a>; give it the <b>Create and upload</b> scope.</li>
        </ul>
        <h3>Draft note</h3>
        <p class="dim">Drafts are stored on this device only. Modrinth's API creates the project directly — for their own draft feature, use the Modrinth website dashboard.</p>
      </aside>
    </div>`;

    const tok = sessionStorage.getItem("bl.mrpat") || "";
    if (tok) $("#mrPAT").value = tok;
    $("#mrPAT").addEventListener("input", () => {
      toast($("#mrPAT").value ? "Token kept in memory for this session" : "Token cleared from memory", { ms: 1400 });
    });
    $("#mrPAT").addEventListener("change", () => {
      sessionStorage.setItem("bl.mrpat", $("#mrPAT").value);
    });
    $("#mrPATRemember").addEventListener("change", () => {
      const keep = $("#mrPATRemember").checked;
      if (keep && $("#mrPAT").value) sessionStorage.setItem("bl.mrpat", $("#mrPAT").value);
      if (!keep) sessionStorage.removeItem("bl.mrpat");
      toast(keep ? "Token stays until this tab closes" : "Token removed from session", { ms: 2000 });
    });

    const bodyEl = $("#pBody");
    bodyEl.addEventListener("input", () => charCount(bodyEl, $("#bodyCount")));

    $("#pFileZone").addEventListener("click", () => $("#pFile").click());
    $("#pFile").addEventListener("change", () => {
      const f = $("#pFile").files?.[0];
      $("#pFileName").textContent = f ? `${f.name} · ${(f.size / 1048576).toFixed(2)} MB` : "Choose the .jar file to publish";
      if (f?.name && !/\.jpe?g|\.png|\.zip|\.jar$/.test(f.name)) toast("Modrinth expects .jar or .zip files for mods", { err: true });
    });

    $("#pSaveDraft").addEventListener("click", () => {
      const d = collectDraft();
      if (!d.name) { toast("Give the project at least a name before saving", { err: true }); return; }
      const l = store.get(D_KEY, []);
      const i = l.findIndex((x) => x.id === d.id);
      if (i >= 0) l[i] = d; else l.unshift(d);
      store.set(D_KEY, l);
      view.querySelector('[data-rt="drafts"] small').textContent = `${l.length} saved`;
      toast("Draft saved on this device");
    });

    $("#pPreview").addEventListener("click", () => {
      const d = collectDraft();
      openModal(`<h3 style="margin:0 0 10px">Preview — ${esc(d.name || "Untitled")}</h3>
        <div class="md-body">${mdPreview(d.body)}</div>
        <div class="chips" style="margin-top:10px">
          <span class="badge green">${esc(d.loaders.join(", ") || "no loaders yet")}</span>
          ${d.game_versions.map((v) => `<span class="badge release">MC ${esc(v)}</span>`).join("")}
        </div>`, { cls: "wide" });
    });

    $("#pPublish").addEventListener("click", async () => {
      const pat = $("#mrPAT").value.trim();
      if (!/^mra/.test(pat)) { toast("Paste a valid Modrinth PAT (they start with mra_)", { err: true }); return; }
      const f = $("#pFile").files?.[0];
      if (!f) { toast("Choose the .jar file to publish", { err: true }); return; }
      const d = collectDraft(f);
      const problems = [];
      if (!d.name) problems.push("a project name");
      if (!d.slug) problems.push("a slug (e.g. my-awesome-mod)");
      if (!d.description) problems.push("a description");
      if (!d.game_versions.length) problems.push("at least one Minecraft version");
      if (!d.loaders.length) problems.push("at least one loader");
      if (problems.length) { toast("Missing: " + problems.join(", "), { err: true, ms: 3600 }); return; }

      /* real token verification against Modrinth — no silent assumptions */
      $("#pResult").innerHTML = `<div class="dim">Verifying token with Modrinth…</div>`;
      let who = null;
      try {
        const r = await fetch("https://api.modrinth.com/v2/user", { headers: { Authorization: pat } });
        if (r.status === 401) throw new Error("Unauthorized — the token is missing or invalid");
        if (r.status === 429) throw new Error("Rate limited by Modrinth — wait a moment and try again");
        if (!r.ok) throw new Error("HTTP " + r.status + " from Modrinth");
        who = await r.json();
      } catch (e) {
        $("#pResult").innerHTML = `<div class="state-block error-box"><div class="s-emoji">🚫</div><h3>Token check failed</h3><p>${esc(e.message)}</p></div>`;
        return;
      }

      openModal(`<h2 style="margin:0 0 8px">Confirm publish</h2>
        <p>Account <b>${esc(who.username || who.id)}</b> will publish:</p>
        <ul style="color:var(--text-dim)">
          <li><b>${esc(d.name)}</b> (slug <code>${esc(d.slug)}</code>)</li>
          <li>${d.game_versions.length} Minecraft versions, loaders: ${esc(d.loaders.join(", "))}</li>
          <li>File: <code>${esc(f.name)}</code> (${(f.size / 1048576).toFixed(2)} MB)</li>
        </ul>
        <button class="btn btn-primary" id="confirmPub">Publish now — real request</button>`, { cls: "" });
      $("#confirmPub").addEventListener("click", () => {
        document.querySelector(".modal-close")?.click();
        doPublish(pat, d, f);
      });
    });

    function collectDraft(file = null) {
      const list = (s) => s.split(",").map((x) => x.trim()).filter(Boolean);
      return {
        id: currentDraft?.id || "d" + Date.now().toString(36),
        ts: Date.now(),
        name: inputVal("#pName"), slug: inputVal("#pSlug").toLowerCase().replace(/[^a-z0-9_-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, ""),
        description: inputVal("#pDesc"), body: $("#pBody").value,
        loaders: list(inputVal("#pLoaders")).map((x) => x.toLowerCase()),
        game_versions: list(inputVal("#pVers")),
        categories: list(inputVal("#pCats")).map((x) => x.toLowerCase()),
        client_side: $("#pClient").value, server_side: $("#pServer").value,
        fileName: file ? file.name : null,
      };
    }

    async function doPublish(pat, d, f) {
      const res = $("#pResult");
      $("#pProgWrap").hidden = false;
      $("#pProgBar").style.width = "0%"; $("#pProgTxt").textContent = "Negotiating with Modrinth…";
      const data = {
        slug: d.slug, title: d.name, description: d.description, body: d.body,
        categories: d.categories, client_side: d.client_side, server_side: d.server_side,
        game_versions: d.game_versions, loaders: d.loaders,
        license: "all-rights-reserved",
        project_type: "mod",
        status: "draft",
        associations: [],
        file_data: null,
        uploading_files: [f.name],
      };
      const fd = new FormData();
      fd.append("data", JSON.stringify(data));
      fd.append(f.name, f, f.name);
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "https://api.modrinth.com/v2/project", true);
      xhr.setRequestHeader("Authorization", pat);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const pct = Math.round((e.loaded / e.total) * 100);
          $("#pProgBar").style.width = pct + "%";
          $("#pProgTxt").textContent = `Uploading to Modrinth… ${pct}%`;
        }
      };
      xhr.onerror = () => {
        $("#pProgTxt").textContent = "Network error";
        res.innerHTML = `<div class="state-block error-box"><div class="s-emoji">📡</div><h3>The request never reached Modrinth</h3><p>This happens on some private networks. No publish result is assumed.</p></div>`;
      };
      xhr.onload = () => {
        let j = {};
        try { j = JSON.parse(xhr.responseText); } catch {}
        if (xhr.status === 200 || xhr.status === 201) {
          $("#pProgBar").style.width = "100%"; $("#pProgTxt").textContent = "Published ✓";
          const l = store.get(D_KEY, []);
          store.set(D_KEY, l.filter((x) => x.id !== currentDraft?.id));
          res.innerHTML = `<div class="state-block ok-box"><div class="s-emoji">🎉</div><h3>Genuinely published</h3>
            <p>Modrinth accepted the project: <a href="https://modrinth.com/project/${esc(j.slug || d.slug)}" target="_blank" rel="noopener noreferrer">modrinth.com/project/${esc(j.slug || d.slug)} ↗</a>.
            Your project was created in <b>draft status</b> — visit Modrinth to add a license/gallery and press their "mark as published" when ready.</p></div>`;
        } else {
          const msg = j?.description || j?.detail || j?.message || ("HTTP " + xhr.status);
          $("#pProgTxt").textContent = "Rejected";
          res.innerHTML = `<div class="state-block error-box"><div class="s-emoji">🚫</div><h3>Modrinth rejected the request</h3><p>${esc(msg)}</p>
            <p style="color:var(--text-dim)">Because "never fake publishing": if it failed, it failed. Fix the issue and try again — nothing was published.</p></div>`;
        }
      };
      xhr.send(fd);
    }

    /* load a draft into the form when clicking from drafts tab handled there */
    currentDraft = null;
    observeReveals();
  }

  /* restore a draft into the form fields */
  function fillForm(d) {
    $("#pName").value = d.name || "";
    $("#pSlug").value = d.slug || "";
    $("#pDesc").value = d.description || "";
    $("#pBody").value = d.body || "";
    $("#pLoaders").value = (d.loaders || []).join(", ");
    $("#pVers").value = (d.game_versions || []).join(", ");
    $("#pCats").value = (d.categories || []).join(", ");
    $("#pClient").value = d.client_side || "required";
    $("#pServer").value = d.server_side || "required";
    $("#bodyCount").textContent = ($("#pBody").value.length) + " characters";
  }
  window.__fillPublishForm = fillForm;

  function renderDrafts(body) {
    const drafts = store.get(D_KEY, []);
    body.innerHTML = `<div class="section">
      <h2 style="margin-top:0">Saved drafts (this device only)</h2>
      ${drafts.length ? `<div class="ver-list">` + drafts.map((d) => `
        <div class="ver-item">
          <div class="vi-row"><span class="vi-name">${esc(d.name || "Untitled")} <span class="dim">· ${esc(d.slug || "no slug")}</span></span>
            <span class="vi-date">${new Date(d.ts).toLocaleString()}</span></div>
          <div class="vi-tags">${(d.loaders || []).map((l) => `<span class="badge green">${esc(l)}</span>`).join("")}
            ${(d.game_versions || []).slice(0, 4).map((v) => `<span class="badge release">MC ${esc(v)}</span>`).join("")}</div>
          <div class="vi-foot">
            <button class="btn btn-sm btn-primary" data-dload="${esc(d.id)}">Open in editor</button>
            <button class="btn btn-sm" data-ddel="${esc(d.id)}">Delete draft</button>
          </div>
        </div>`).join("") + `</div>`
        : stateBlock("📝", "No drafts yet", "Fill the Modrinth form and press “Save draft” — drafts live only on this device.", "")}
    </div>`;
    body.querySelectorAll("[data-dload]").forEach((b) => b.addEventListener("click", () => {
      const d = drafts.find((x) => x.id === b.dataset.dload);
      if (!d) return;
      view.querySelectorAll("[data-rt]").forEach((x) => x.classList.toggle("on", x.dataset.rt === "modrinth"));
      setActiveTab("modrinth");
      fillForm(d);
      currentDraft = d;
      toast(`Draft “${d.name}” opened`);
    }));
    body.querySelectorAll("[data-ddel]").forEach((b) => b.addEventListener("click", () => {
      store.set(D_KEY, store.get(D_KEY, []).filter((x) => x.id !== b.dataset.ddel));
      view.querySelector('[data-rt="drafts"] small').textContent = `${store.get(D_KEY, []).length} saved`;
      renderDrafts(body);
    }));
  }

  function renderCFPublish(body, cfg) {
    const authorized = !!cfg.curseforgePublish;
    body.innerHTML = `<div class="section">
      <div class="status-banner ${authorized ? "ok" : "warn"}">
        <span class="b-ic">${authorized ? "✅" : "🔑"}</span>
        <div><h4>${authorized ? "CurseForge publishing available on this deployment" : "CurseForge publishing requires partner authorization"}</h4>
        <div>${authorized ? "Passing requests through the backend with an authorized publisher. Continue below."
          : "CurseForge only accepts files through its official developer programme for approved partners — third-party sites cannot upload without a genuine authorization from Overwolf. Apply at their dashboard or use Modrinth to publish here."}</div></div>
      </div>
      ${authorized ? `<div class="up-actions-row"><button class="btn" id="cfFlow">Open the authorized flow</button></div>
        <div id="cfFlowBody"></div>`
        : `<ul class="mini-steps">
            <li>Publishing to <b>Modrinth</b> works right now through the MODRINTH tab — the official API is public.</li>
            <li>For CurseForge: authorized partner access cannot be self-served. This page shows the honest state of his deployment instead of pretending.</li>
            <li>Once the backend has a working authorization, this tab switches live automatically.</li>
          </ul>`}
    </div>`;
    if (authorized) {
      $("#cfFlow").addEventListener("click", () => {
        $("#cfFlowBody").innerHTML = `<div class="dim" style="padding:12px">Requesting authorized session from backend…</div>`;
        fetch("/api/publish/curseforge", { credentials: "same-origin", method: "POST", headers: { "Content-Type": "application/json" } })
          .then((r) => r.json()).then((j) => {
            $("#cfFlowBody").innerHTML = j.authorized
              ? `<div class="state-block ok-box"><div class="s-emoji">✅</div><h3>Authorized</h3><p>CurseForge accepted the deployment's authorization. File upload support continues in the Upload area.</p></div>`
              : `<div class="state-block warn-box"><div class="s-emoji">🚫</div><h3>Not authorized</h3><p>${esc(j.error || "CurseForge rejected the authorization.")}</p></div>`;
          }).catch(() => { $("#cfFlowBody").innerHTML = `<div class="dim">Backend unreachable — status stays unknown (nothing faked).</div>`; });
      });
    }
  }

  setActiveTab("modrinth");
  window.addEventListener("authchanged", () => {
    if (!currentUser()) location.hash = "/publish?reauth=" + Date.now().toString(36);
  }, { once: true });
});
