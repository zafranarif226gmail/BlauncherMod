/* ============================================================
   BLauncher Mod — upload library (pure, dependency-free)
   Byte-level archive validation & metadata detection ONLY.
   Files are never executed, imported or injected into the page —
   they are only parsed as bytes/text for SHA-256 and metadata.
   Testable in Node (crypto.subtle + DecompressionStream included).
   ============================================================ */

/* ---------------- SHA-256 ---------------- */
export async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/* ---------------- extension / type check ---------------- */
export function checkExtension(filename) {
  const name = String(filename || "").toLowerCase();
  if (name.endsWith(".jar")) return { ok: true, kind: "jar" };
  if (name.endsWith(".mcpack")) return { ok: true, kind: "mcpack" };
  if (name.endsWith(".mcaddon")) return { ok: true, kind: "mcaddon" };
  return { ok: false, kind: null, reason: "Only .jar, .mcpack and .mcaddon files are accepted." };
}

const U32 = (dv, off) => dv.getUint32(off, true);
const U16 = (dv, off) => dv.getUint16(off, true);

/* ---------------- ZIP validation (EOCD + central directory) ----------------
   Real structural validation: locates the End-Of-Central-Directory record,
   walks the central directory and returns every entry. Rejects truncated,
   corrupted or non-ZIP files (a .jar IS a ZIP; .mcpack/.mcaddon are ZIP too). */
export function validateZip(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 22) return { ok: false, reason: "File too small to be an archive." };
  if (U32(dv, 0) !== 0x04034b50) return { ok: false, reason: "Missing archive signature (PK..). Not a readable .jar/.mcpack/.mcaddon." };

  /* find EOCD within the last 64 KiB + 22 bytes */
  const scanFrom = Math.max(0, bytes.length - 65558);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= scanFrom; i--) {
    if (U32(dv, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) return { ok: false, reason: "Archive is truncated — End-Of-Central-Directory record not found." };

  const entriesTotal = U16(dv, eocd + 10);
  const cdSize = U32(dv, eocd + 12);
  const cdOffset = U32(dv, eocd + 16);
  if (entriesTotal === 0xffff || cdOffset === 0xffffffff)
    return { ok: false, reason: "ZIP64 archives are not supported. Please re-pack this file." };
  if (cdOffset + cdSize > bytes.length)
    return { ok: false, reason: "Archive directory is corrupt (directory beyond end of file). Re-download or re-pack the file." };

  const entries = [];
  let p = cdOffset;
  for (let i = 0; i < entriesTotal; i++) {
    if (p + 46 > bytes.length || U32(dv, p) !== 0x02014b50) break;
    const method = U16(dv, p + 10);
    const compSize = U32(dv, p + 20);
    const size = U32(dv, p + 24);
    const nameLen = U16(dv, p + 28);
    const extraLen = U16(dv, p + 30);
    const commentLen = U16(dv, p + 32);
    const localOff = U32(dv, p + 42);
    let name = "";
    try { name = new TextDecoder("utf-8", { fatal: false }).decode(bytes.subarray(p + 46, p + 46 + nameLen)); }
    catch { name = "unreadable-entry"; }
    entries.push({ name, size, compSize, method, localOff });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return { ok: true, entries, count: entries.length };
}

/* ---------------- one entry → bytes ---------------- */
export async function extractEntry(bytes, entry) {
  if (!entry || entry.localOff + 30 > bytes.length) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (U32(dv, entry.localOff) !== 0x04034b50) return null;
  const nameLen = U16(dv, entry.localOff + 26);
  const extraLen = U16(dv, entry.localOff + 28);
  const start = entry.localOff + 30 + nameLen + extraLen;
  if (start + entry.compSize > bytes.length) return null;
  const raw = bytes.subarray(start, start + entry.compSize);
  if (entry.method === 0) return new Uint8Array(raw); /* stored */
  if (entry.method !== 8) return null;               /* unsupported */
  if (typeof DecompressionStream !== "function") return null;
  try {
    const ds = new DecompressionStream("deflate-raw");
    const stream = new Blob([raw]).stream().pipeThrough(ds);
    const out = await new Response(stream).arrayBuffer();
    return new Uint8Array(out);
  } catch { return null; }
}
export const findEntry = (entries, name) =>
  entries.find((e) => e.name === name) ||
  entries.find((e) => e.name.toLowerCase() === name.toLowerCase());

/* ---------------- dedupe/sort version tags ----------------
   Modrinth/CF data can repeat tags; UI must show every DISTINCT version once.
   Sorting uses official Mojang manifest release times when available. */
export function dedupeVersions(list, manifestById = null) {
  const seen = new Set();
  const ids = [];
  for (const v of list || []) {
    const id = String(v);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    ids.push(id);
  }
  const timeOf = (id) => {
    const m = manifestById?.get ? manifestById.get(id) : null;
    return m?.time ? Date.parse(m.time) : 0;
  };
  return ids.sort((a, b) => (timeOf(b) - timeOf(a)) || b.localeCompare(a, undefined, { numeric: true }));
}

/* ---------------- text helpers ---------------- */
const txt = (b) => new TextDecoder("utf-8", { fatal: false }).decode(b || new Uint8Array());

function safeJSON(s) {
  try { return JSON.parse(s); } catch { return null; }
}

/* forge TOML mods.toml / neoforge.mods.toml — extract fields, no guessing */
function parseTomlFields(s) {
  const out = { mods: [], minecraft: null, name: null, authors: null, description: null, logo: null };
  const mine = [...s.matchAll(/(?<!\w)minecraft\s*=\s*["']([^"']+)["']/g)];
  if (mine.length) out.minecraft = mine[mine.length - 1][1];
  const blocks = s.split(/\[\[mods\]\]/).slice(1);
  for (const b of blocks) {
    const g = (re) => { const m = b.match(re); return m ? m[1] : null; };
    out.mods.push({
      modId: g(/modId\s*=\s*["']([^"']+)["']/),
      displayName: g(/(?:displayName|["']displayName["'])\s*=\s*["']([^"']+)["']/),
      version: g(/^version\s*=?\s*["']?([^"'\n]+)["']/m),
      author: g(/(?:authors|displayTest)\s*=\s*["']([^"']+)["']/),
      desc: /description\s*=\s*'''([\s\S]*?)'''/.test(b)
        ? b.match(/description\s*=\s*'''([\s\S]*?)'''/)[1].trim().slice(0, 300)
        : g(/description\s*=["']([^"']+)["']/),
    });
  }
  return out.mods.length || out.minecraft ? out : null;
}

/* ---------------- DETECTION (only from genuine metadata present in the archive) ---------------- */
export async function detectMetadata(bytes, entries, kindHint) {
  const out = {
    kind: kindHint,
    loaders: [], versions: [],          /* raw constraint strings or explicit ids */
    name: null, description: null, modId: null, notes: [],
    detection: "none",                  /* none | auto | partial */
    packFormat: null, bedrock: null,
  };

  const readOne = async (name) => {
    const ent = findEntry(entries, name);
    if (!ent) return null;
    if (ent.size > 2 * 1024 * 1024) { out.notes.push(`${name} is unexpectedly large — skipped for safety.`); return null; }
    const b = await extractEntry(bytes, ent);
    return b ? txt(b) : null;
  };

  /* 1) Fabric */
  const fb = await readOne("fabric.mod.json");
  if (fb) {
    const j = safeJSON(fb);
    if (j) {
      out.loaders = ["fabric"]; out.detection = "auto";
      out.modId = j.id || null; out.name = j.name || null; out.description = j.description || null;
      const deps = j.depends || {};
      const mv = deps.minecraft ?? j.suggests?.minecraft ?? null;
      if (mv) out.versions = Array.isArray(mv) ? mv.map(String) : [String(mv)];
      else out.notes.push("fabric.mod.json has no explicit minecraft dependency — choose versions manually.");
    } else {
      out.loaders = ["fabric"]; out.detection = "partial";
      out.notes.push("fabric.mod.json exists but could not be parsed as JSON.");
    }
    return out;
  }

  /* 2) Quilt */
  const qb = await readOne("quilt.mod.json");
  if (qb) {
    const j = safeJSON(qb);
    out.loaders = ["quilt"]; out.detection = "auto";
    const ql = j?.quilt_loader || {};
    out.modId = ql.id || null; out.name = ql.group && ql.id ? `${ql.group}.${ql.id}` : (ql.id || null);
    const dep = (ql.depends || []).find((d) => d === "minecraft" || (d && typeof d === "object" && /minecraft/.test(d.id || "")));
    if (dep && typeof dep === "object" && dep.version) out.versions = [String(dep.version)];
    else if (typeof dep === "string") out.notes.push("Quilt metadata lists minecraft but without a version constraint — choose versions manually.");
    else out.notes.push("No minecraft dependency found in quilt.mod.json — choose versions manually.");
    out.name = out.name || j?.quilt_loader?.metadata?.name || null;
    out.description = j?.quilt_loader?.metadata?.description || null;
    return out;
  }

  /* 3) NeoForge / Forge */
  for (const [fn, loader] of [["META-INF/neoforge.mods.toml", "neoforge"], ["META-INF/mods.toml", "forge"]]) {
    const b = await readOne(fn);
    if (b) {
      const t = parseTomlFields(b);
      out.loaders = [loader]; out.detection = "auto";
      if (t?.minecraft) out.versions = [t.minecraft]; else out.notes.push("No minecraft version constraint in the loader TOML — choose versions manually.");
      if (t?.mods?.[0]) {
        out.modId = t.mods[0].modId || null;
        out.name = t.mods[0].displayName || null;
        out.description = t.mods[0].desc || null;
        if (t.mods[0].author) out.notes.push(`Author line in metadata: ${t.mods[0].author}`);
      }
      return out;
    }
  }

  /* 4) Bedrock .mcpack / .mcaddon — manifest.json (top-level or nested for addons) */
  if (kindHint !== "jar") {
    const manifests = entries.filter((e) => /manifest\.json$/i.test(e.name) && !e.name.includes("world_"));
    const parses = [];
    for (const m of manifests.slice(0, 5)) {
      if (m.size > 320 * 1024) continue;
      const b = await extractEntry(bytes, m);
      if (!b) continue;
      const j = safeJSON(txt(b));
      if (j?.header?.uuid) parses.push({ path: m.name, j });
    }
    if (parses.length) {
      out.loaders = ["bedrock"]; out.detection = "auto";
      const first = parses[0].j;
      out.name = first.header.name || null;
      out.description = first.header.description || null;
      out.modId = first.uuid || first.header?.uuid || null;
      if (Array.isArray(first.header?.min_engine_version))
        out.versions = [first.header.min_engine_version.join(".") + " (min engine)"];
      out.bedrock = parses.map((p) => ({ path: p.path, type: p.j.modules?.[0]?.type || "unknown", uuid: p.j.header.uuid }));
      if (parses.length > 1) out.notes.push(`.mcaddon contains ${parses.length} packs (${parses.map((p) => p.j.modules?.[0]?.type || "pack").join(", ")}).`);
      return out;
    }
  }

  /* 5) Resource / data pack .jar-less .mcpack fallthrough + pack.mcmeta */
  const pm = await readOne("pack.mcmeta");
  if (pm) {
    const j = safeJSON(pm);
    out.packFormat = j?.pack?.pack_format ?? null;
    out.notes.push(out.packFormat != null
      ? `Contains a Java pack.mcmeta (pack_format ${out.packFormat}). Loader unknown — select manually.`
      : "Contains pack.mcmeta but it could not be parsed — select loader & versions manually.");
    out.detection = "partial";
  }

  if (out.loaders.length === 0 && out.detection === "none")
    out.notes.push("No recognised mod metadata (fabric.mod.json / quilt.mod.json / mods.toml / manifest.json) inside this archive. Automatic detection failed — pick the loader, versions and metadata manually (all optional).");
  return out;
}
