/* ============================================================
   BLauncher Mod — CurseForge catalogue (official API, key-gated)
   The browser cannot reach api.curseforge.com without an API key,
   and CurseForge may additionally block browser (CORS) calls.
   If live data cannot be shown, this page says so clearly and
   NEVER fabricates catalogue entries or download links.
   ============================================================ */
import { $, $$, esc, fmtNum, fmtDate, route, page, skelCards, errorBlock, stateBlock, store, toast, openModal, observeReveals, ICON } from "./core.js";
import { cfRequest, cfKey, cfProbeMode, cfCategories, APIStatus, gvBadge, dedupeVersions } from "./data.js";
import { modCard, bindCards, imgBlock } from "./cards.js";

const SORT_MAP = {
  popularity: 2, downloads: 6, updated: 3, name: 4,
};

route("/curseforge", async function curseforgeView({ params, signal }) {
  const q = params.get("q") || "";
  const sort = params.get("sort") || "downloads";
  const loaderId = parseInt(params.get("loader") || "0", 10);
  const ver = params.get("ver") || "";
  const catSel = params.get("cat") || "";
  const view = $("#view");
  const mode = await cfProbeMode();
  const hasAccess = mode === "proxy" || mode === "local";

  view.innerHTML = page(`
  <div class="cat-head">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo" style="color:#ffab6b"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 3c4 0 7 3 7 5-4-1-10-1-14 0 0-2 3-5 7-5z"/><path d="M5 8c-2 3-2 7 0 10 3 3 11 3 14 0 2-3 2-7 0-10"/></svg></span> CurseForge Catalogue</h1>
    <span class="cat-sub">Uses the official CurseForge API. Access is API-key gated and browser requests may be blocked — status is always shown honestly.</span>
  </div>

  <div class="section" style="padding-top:18px">
    <div id="cfStatus"></div>

    ${hasAccess ? `
    <div class="cat-tools" style="padding:0">
      <div class="tools-row">
        <div class="search-inline">${ICON.search}
          <input id="cfQ" placeholder="Search CurseForge mods…" value="${esc(q)}"/>
          <button class="btn btn-primary btn-sm" id="cfGo">Search</button>
        </div>
        <select class="select" id="cfSort" aria-label="Sort">
          ${[["downloads", "Most downloads"], ["popularity", "Most popular"], ["updated", "Recently updated"], ["name", "Name (A–Z)"]]
            .map(([v, l]) => `<option value="${v}" ${sort === v ? "selected" : ""}>${l}</option>`).join("")}
        </select>
      </div>
      <div class="tools-row">
        <select class="select" id="cfLoader" aria-label="Mod loader">
          <option value="0" ${!loaderId ? "selected" : ""}>Any loader</option>
          ${[[1, "Forge"], [4, "Fabric"], [5, "Quilt"], [6, "NeoForge"], [3, "LiteLoader"]]
            .map(([v, l]) => `<option value="${v}" ${loaderId === v ? "selected" : ""}>${l}</option>`).join("")}
        </select>
        <select class="select" id="cfCat" aria-label="Category">
          <option value="" ${!catSel ? "selected" : ""}>Any category</option>
        </select>
        <input class="select" id="cfVer" placeholder="MC version e.g. 1.20.1" value="${esc(ver)}" style="padding:11px 14px" aria-label="Minecraft version"/>
        <button class="btn btn-sm" id="cfReset">Reset filters</button>
      </div>
      <div class="result-meta" id="cfMeta"></div>
    </div>
    <div class="section" style="padding-top:8px">
      <div id="cfResults">${skelCards(8)}</div>
      <div class="load-more-wrap" id="cfMoreWrap" hidden><button class="btn" id="cfMore">Load more mods</button></div>
    </div>` : ""}
  </div>`);


  $("[data-goback]").addEventListener("click", () => history.back());

  /* ---- status banner ---- */
  const statusEl = $("#cfStatus");
  const setStatus = (cls, ic, title, html) => {
    statusEl.innerHTML = `<div class="status-banner ${cls}">
      <span class="b-ic">${ic}</span>
      <div><h4>${esc(title)}</h4><div style="color:var(--text-dim);font-size:.86rem">${html}</div></div></div>`;
  };

  if (mode === "proxy") {
    setStatus("ok", "✅", "CurseForge API status: connected via backend proxy",
      `Requests travel through this site's Cloudflare Function with the developer key held server-side — your browser never needs a key. This is genuine live data.`);
  } else if (mode === "local") {
    setStatus("ok", "✅", "CurseForge API status: using your local key",
      `No backend proxy found, so requests go straight from your browser to api.curseforge.com with your key. If the provider blocks browser (CORS) traffic, an honest error is shown — <button class="btn btn-sm" id="cfClearKey" style="margin-left:8px">Remove key</button>`);
  } else {
    setStatus("", "🔑", "CurseForge API status: not configured",
      `<p>The official CurseForge web API requires a developer key (it is <b>not</b> public) and blocks direct browser calls on most origins. BLauncher Mod will never fabricate CurseForge data, so the catalogue stays empty until a key is provided — deploy the Cloudflare Functions with <code>CURSEFORGE_API_KEY</code> set (see DEPLOYMENT.md), paste a personal key below, or browse <a href="#/modrinth" data-nav>Modrinth</a>, which needs no key.</p>
       <div class="key-row"><input id="cfKeyInput" type="password" placeholder="Paste CurseForge API key (starts with $2a$10$…)" aria-label="CurseForge API key"/>
       <button class="btn btn-primary btn-sm" id="cfKeySave">Save key locally</button>
       <a class="btn btn-sm" href="https://console.curseforge.com/" target="_blank" rel="noopener noreferrer">Get a key ↗</a></div>
       <p style="margin-top:10px">Keys are stored only in this browser (localStorage on your device) and sent only to api.curseforge.com or our function relay.</p>`);
    $("#cfKeySave").addEventListener("click", () => {
      const v = ($("#cfKeyInput").value || "").trim();
      if (!/^[$]2a[$]10[$]/.test(v)) { toast("That does not look like a CurseForge API key (they start with $2a$10$)", { err: true }); return; }
      store.set("cfKey", v);
      toast("API key saved locally");
      location.hash = "/curseforge?t=" + Date.now().toString(36);
    });
    return;
  }

  const upd = (patch) => {
    const p = new URLSearchParams(location.hash.split("?")[1] || "");
    for (const [k, v] of Object.entries(patch)) { if (v === "" || v === undefined || v === null || v === "0") p.delete(k); else p.set(k, v); }
    if (!p.has("t")) p.set("t", Date.now().toString(36));
    location.hash = "/curseforge?" + p.toString();
  };

  $("#cfGo").addEventListener("click", () => upd({ q: $("#cfQ").value }));
  let t; $("#cfQ").addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => upd({ q: $("#cfQ").value.trim() }), 550); });
  $("#cfSort").addEventListener("change", () => upd({ sort: $("#cfSort").value }));
  $("#cfLoader").addEventListener("change", () => upd({ loader: $("#cfLoader").value }));
  $("#cfCat").addEventListener("change", () => upd({ cat: $("#cfCat").value }));
  let verT; $("#cfVer").addEventListener("input", () => { clearTimeout(verT); verT = setTimeout(() => upd({ ver: $("#cfVer").value.trim() }), 600); });
  $("#cfReset").addEventListener("click", () => {
    store.set("selVersion", ""); store.set("selLoader", "");
    upd({ q: "", loader: "", ver: "", cat: "" });
  });
  $("#cfClearKey")?.addEventListener?.("click", () => {
    store.del("cfKey"); toast("API key removed from this device");
    location.hash = "/curseforge?r=" + Date.now().toString(36);
  });

  /* real category list from the official API (never invented) */
  cfCategories().then((cats) => {
    const sel = $("#cfCat");
    if (!sel || !Array.isArray(cats)) return;
    const names = cats.map((c) => c.name).filter(Boolean).sort((a, b) => a.localeCompare(b));
    sel.innerHTML = `<option value="" ${!catSel ? "selected" : ""}>Any category</option>` +
      names.map((n) => `<option value="${esc(n)}" ${catSel === n ? "selected" : ""}>${esc(n)}</option>`).join("");
  }).catch(() => { /* categories are optional; search still works */ });

  const LIMIT = 24; let index = 0;

  async function load(append = false) {
    const box = $("#cfResults");
    if (!append) box.innerHTML = skelCards(8);
    try {
      const p = new URLSearchParams({ gameId: "432", pageSize: String(LIMIT), index: String(index), sortField: SORT_MAP[sort] ?? 6, sortOrder: "desc" });
      if (q) p.set("searchFilter", q);
      if (loaderId) p.set("modLoaderType", String(loaderId));
      if (ver) p.set("gameVersions", ver);
      if (catSel) p.set("categories", JSON.stringify([catSel]));
      const res = await cfRequest("/mods/search?" + p.toString());
      if (signal()) return;
      const hits = res?.data || [];
      if (append) {
        box.insertAdjacentHTML("beforeend", hits.map((h) => modCard(itemFromCF(h), { routeBase: "/curseforge/mod" })).join(""));
      } else {
        const total = res?.pagination?.totalCount ?? hits.length;
        $("#cfMeta").innerHTML = `<b>${fmtNum(total)}</b> results${q ? ` for “${esc(q)}”` : ""}` +
          (loaderId ? ` · loader ${esc(loaderName(loaderId))}` : "") + (ver ? ` · MC ${esc(ver)}` : "");
        box.innerHTML = hits.length
          ? `<div class="card-grid">${hits.map((h) => modCard(itemFromCF(h), { routeBase: "/curseforge/mod" })).join("")}</div>`
          : stateBlock("🫥", "No CurseForge results", "The search worked but returned zero projects. Try another keyword or filter.");
      }
      index += hits.length;
      $("#cfMoreWrap").hidden = hits.length < LIMIT;
      bindCards(); observeReveals();
    } catch (e) {
      if (e instanceof APIStatus) {
        if (e.code === "MISSING_KEY") { setStatus("err", "🚫", "API status: missing key", "No key configured."); box.innerHTML = ""; return; }
        if (e.code?.startsWith?.("PROXY_DOWN")) { box.innerHTML = errorBlock("The backend CurseForge proxy is down or misconfigured (" + esc(String(e.code)) + "). No substitute data will be shown."); setStatus("err", "🚫", "API status: proxy unreachable", "Deploy fix: check CURSEFORGE_API_KEY in the Functions environment."); return; }
        if (e.code === "CORS_BLOCKED") { box.innerHTML = errorBlock("The browser could not reach api.curseforge.com (CORS-restricted or invalid key)."); setStatus("err", "🚫", "API status: blocked", "Browser-direct CurseForge calls are blocked from this origin. Deploy the Functions proxy instead — see DEPLOYMENT.md."); return; }
      }
      const blocked = /Failed to fetch|NetworkError|CORS/i.test(e?.message || "");
      box.innerHTML = errorBlock(blocked
        ? "The browser could not reach api.curseforge.com (very likely CORS-restricted from this origin, or the key is wrong/limited)."
        : "CurseForge search failed: " + (e?.message || "network error"));
      $("#cfMoreWrap").hidden = true;
      if (!append) setStatus("err", "🚫", "CurseForge API status: blocked or rejected",
        "Live data cannot be shown. Nothing was invented as a substitute — use the official site instead.");
    }
  }
  $("#cfMore").addEventListener("click", () => load(true));
  await load();
});

function loaderName(id) { return ({ 1: "Forge", 4: "Fabric", 5: "Quilt", 6: "NeoForge", 3: "LiteLoader" })[id] || String(id); }

/* one CurseForge file row — shows EVERY tagged game version (deduped), no truncation */
function fileRowHTML(f, website) {
  const rt = f.releaseType === 1 ? ["release", "Release"] : f.releaseType === 2 ? ["beta", "Beta"] : ["alpha", "Alpha"];
  const gameTags = dedupeVersions(((f.gameVersions || []).filter((v) => /(^b?1\.|d|a1|w\d)/.test(String(v)) || /^br/.test(String(v)) || /\d/.test(String(v)[0]))) || [], null);
  const lds = (f.gameVersions || []).filter((v) => ["Fabric", "Forge", "NeoForge", "Quilt", "LiteLoader"].includes(v)) || [];
  return `<div class="ver-item">
    <div class="vi-row"><span class="vi-name">${esc(f.displayName || f.fileName)}</span>
      <span class="vi-date">${fmtDate(f.fileDate)}</span>
      <span class="badge ${rt[0]}">${rt[1]}</span></div>
    <div class="vi-tags">${gameTags.map((v) => { const b = gvBadge(v); return `<span class="badge ${b.cls}">MC ${esc(v)}</span>`; }).join("")}
      ${lds.map((l) => `<span class="badge green">${esc(l)}</span>`).join("")}</div>
    <div class="vi-foot">
      ${f.downloadUrl ? `<a class="btn btn-sm" href="${esc(f.downloadUrl)}" download target="_blank" rel="noopener noreferrer">${ICON.down} ${esc(f.fileName)}</a>`
      : `<a class="btn btn-sm" href="${esc(website || "#")}" target="_blank" rel="noopener noreferrer">Official file page ↗</a>`}
    </div></div>`;
}

function itemFromCF(h) {
  /* adapt a CurseForge mod record to the shared card shape */
  const log = h.logo?.thumbnailUrl || h.logo?.url || "";
  return {
    id: String(h.id),
    slug: h.slug || String(h.id),
    title: h.name,
    description: h.summary,
    author: h.authors?.[0]?.name || "—",
    icon: log,
    downloads: h.downloadCount,
    categories: (h.categories || []).slice(0, 3).map((c) => c.name.toLowerCase().replace(/\s+/g, "-")),
    versions: dedupeVersions((h.latestFilesIndexes || []).map((i) => i.gameVersion).filter(Boolean)),
    project_type: "mod",
  };
}
/* detail page is reached via the same card click; CurseForge cards route elsewhere */
route("/curseforge/mod/:id", async function cfDetail({ routeParams, signal }) {
  const view = $("#view");
  view.innerHTML = page(`<div class="detail-banner"></div><div class="detail-body"><div class="skel skel-card"></div></div>`);
  let mod, files;
  try {
    [mod, files] = await Promise.all([
      cfRequest(`/mods/${routeParams.id}`),
      cfRequest(`/mods/${routeParams.id}/files?pageSize=24&sort=dateModified&sortOrder=desc`),
    ]);
  } catch (e) {
    view.innerHTML = page(errorBlock("CurseForge detail fetch failed — the provider blocked or rejected the request (" + (e?.message || "error") + "). No data is shown rather than fabricated data."));
    return;
  }
  if (signal()) return;
  const d = mod?.data;
  if (!d) { view.innerHTML = page(stateBlock("❓", "No data returned", "The API response did not include the mod.")); return; }

  let fList = files?.data || [];
  const filesTotal = files?.pagination?.totalCount ?? fList.length;

  /* aggregate: every MC version genuinely supported across all returned files (deduped, exact) */
  const cfSupported = dedupeVersions(fList.flatMap((f) => f.gameVersions || []), null)
    .filter((v) => !["Fabric", "Forge", "NeoForge", "Quilt", "LiteLoader", "Java", "Java Edition"].includes(v));
  const banner = d.screenshots?.[0]?.url || d.logo?.url || "";
  const fac = { id: String(d.id), source: "curseforge", slug: d.slug, title: d.name, icon: d.logo?.url, author: d.authors?.[0]?.name, desc: d.summary, downloads: d.downloadCount };

  view.innerHTML = page(`
  <div class="detail-banner">${banner ? `<img src="${esc(banner)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()"/>` : ""}</div>
  <div class="detail-body">
    <div class="cat-head" style="padding-top:14px">
      <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
      <span class="src-badge curseforge">CurseForge project</span>
    </div>
    <div class="detail-top">
      ${imgBlock(d.logo?.url || "", d.name + " icon", "detail-icon", (d.name || "?")[0]?.toUpperCase() || "?")}
      <div class="detail-titles">
        <h1 class="detail-title">${esc(d.name)}</h1>
        <div class="detail-meta">
          <span>${ICON.user} ${esc(d.authors?.[0]?.name || "Unknown")}</span>
          <span class="stat">${ICON.down} ${(+d.downloadCount || 0).toLocaleString()} downloads</span>
          <span>${ICON.clock} modified ${fmtDate(d.dateModified)}</span>
        </div>
      </div>
      <div class="detail-actions">
        <a class="btn btn-primary" href="${esc(d.links?.websiteUrl || "https://www.curseforge.com/")}" target="_blank" rel="noopener noreferrer">Official CurseForge page ↗</a>
      </div>
    </div>
    <div class="detail-cols">
      <div class="detail-main">
        <h2 style="margin-top:0">About</h2>
        <div class="md-body"><p>${esc(d.summary || "")}</p></div>
        ${d.screenshots?.length ? `<h2>Screenshots</h2><div class="shots-grid">
          ${d.screenshots.map((s) => `<figure class="shot" data-zoom="${esc(s.url)}"><img src="${esc(s.thumbnailUrl || s.url)}" alt="" loading="lazy" onerror="this.parentElement.style.display='none'" referrerpolicy="no-referrer"/></figure>`).join("")}
        </div>` : ""}
        <h2>Supported versions <span class="badge release">${cfSupported.length}</span></h2>
        <p class="md-body dim">Every distinct Minecraft version tagged across this project's files, duplicates removed.${filesTotal > fList.length ? ` (Covers the ${fList.length} loaded of ${filesTotal} files — load more to extend.)` : ""}</p>
        <div class="ver-chips" style="margin-bottom:18px">
          ${cfSupported.map((v) => { const b = gvBadge(v); return `<span class="badge ${b.cls}">MC ${esc(v)}</span>`; }).join("") || `<span class="badge old">no version tags returned</span>`}
        </div>

        <h2>Files <span class="badge release">${fList.length}</span></h2>
        <div class="ver-list" id="cfFileList">
          ${fList.map(fileRowHTML).join("") || `<p class="md-body">No file metadata returned.</p>`}
        </div>
        ${filesTotal > fList.length ? `<div class="load-more-wrap"><button class="btn" id="cfFileMore">Load more files (${fList.length} of ${filesTotal})</button></div>` : ""}
      </div>
      <aside class="detail-side side-panel">
        <h3 style="margin-top:0">Project info</h3>
        <div class="side-stat"><span class="k">Source</span><span class="v">CurseForge</span></div>
        <div class="side-stat"><span class="k">ID</span><span class="v">${esc(d.id)}</span></div>
        <div class="side-stat"><span class="k">Slug</span><span class="v">${esc(d.slug)}</span></div>
        <div class="side-stat"><span class="k">Class</span><span class="v">${esc(d.classId === 6 ? "Mod" : String(d.classId ?? "—"))}</span></div>
        <h3>Categories</h3>
        <div class="chips">${(d.categories || []).map((c) => `<span class="badge">${esc(c.name)}</span>`).join("") || "—"}</div>
        <h3>Links</h3>
        <div class="chips">
          ${d.links?.websiteUrl ? `<a class="badge" href="${esc(d.links.websiteUrl)}" target="_blank" rel="noopener noreferrer">Website ↗</a>` : ""}
          ${d.links?.issuesUrl ? `<a class="badge" href="${esc(d.links.issuesUrl)}" target="_blank" rel="noopener noreferrer">Issues ↗</a>` : ""}
          ${d.links?.wikiUrl ? `<a class="badge" href="${esc(d.links.wikiUrl)}" target="_blank" rel="noopener noreferrer">Wiki ↗</a>` : ""}
        </div>
      </aside>
    </div>
  </div>`);
  $("[data-goback]").addEventListener("click", () => history.back());
  const moreBtn = $("#cfFileMore");
  moreBtn?.addEventListener("click", async () => {
    moreBtn.disabled = true; moreBtn.textContent = "Loading…";
    try {
      const next = await cfRequest(`/mods/${d.id}/files?pageSize=24&index=${fList.length}&sort=dateModified&sortOrder=desc`);
      const add = next?.data || [];
      fList = fList.concat(add);
      $("#cfFileList").insertAdjacentHTML("beforeend", add.map((f) => fileRowHTML(f, d.links?.websiteUrl)).join(""));
      if (fList.length >= filesTotal) moreBtn.parentElement.remove();
      else { moreBtn.disabled = false; moreBtn.textContent = `Load more files (${fList.length} of ${filesTotal})`; }
    } catch (e2) {
      moreBtn.disabled = false; moreBtn.textContent = "Load more files (retry failed)";
      toast("Could not fetch more files: " + (e2?.message || "error"), { err: true });
    }
  });
  $$("[data-zoom]").forEach((fig) => fig.addEventListener("click", () => openModal(`<img class="modal-img" src="${esc(fig.dataset.zoom)}" alt="" loading="lazy"/>`)));
});
