/* ============================================================
   BLauncher Mod — platform selector
   Genuine compatibility facts only. Java Edition mods (.jar for
   Fabric/Forge/NeoForge/Quilt) run wherever Minecraft Java runs;
   Bedrock packs (.mcpack/.mcaddon) run wherever Bedrock runs.
   No platform is ever claimed to support something it cannot.
   ============================================================ */
import { $, $$, esc, store, toast } from "./core.js";

export const PLATFORMS = [
  { id: "linux",   name: "Linux",         icon: "🐧" },
  { id: "windows", name: "Windows",       icon: "🪟" },
  { id: "macos",   name: "macOS",         icon: "🍎" },
  { id: "android", name: "Android Phone", icon: "🤖" },
  { id: "ios",     name: "iPhone/iPad",   icon: "📱" },
];

export const selectedPlatforms = () => {
  const s = store.get("platforms", []);
  return Array.isArray(s) ? s : [];
};

/* genuine, per-platform compatibility notes (no invented claims) */
const FACTS = {
  java: {
    linux: "Java mods run natively — use your launcher of choice (official, Prism, MultiMC, BLauncher).",
    windows: "Java mods run natively — .jar files load through Fabric/Forge/NeoForge/Quilt in a Java launcher.",
    macos: "Java mods run natively — .jar files load through a loader in any macOS Java launcher.",
    android: "Java mods can run on Android through Java-capable launcher apps (e.g. BLauncher's Android app or PojavLauncher-based launchers). Performance depends on your phone.",
    ios: "Minecraft Java does not run on iPhone/iPad — there is no iOS Java runtime. .jar mods cannot be used here.",
  },
  bedrock: {
    linux: "Bedrock packs are not supported on desktop Linux (Bedrock exists only on Windows 10/11, mobile and consoles).",
    windows: ".mcpack/.mcaddon packs install into Minecraft Bedrock on Windows directly.",
    macos: "Bedrock is not available on macOS — packs cannot be installed here.",
    android: ".mcpack/.mcaddon packs open directly in the Minecraft Bedrock app on Android.",
    ios: ".mcpack/.mcaddon packs open in the Minecraft Bedrock app on iPhone/iPad via the iOS share sheet.",
  },
};

const PLAT_ORDER = ["linux", "windows", "macos", "android", "ios"];
export const platformHeading = (ids = selectedPlatforms()) => {
  const names = PLAT_ORDER.filter((k) => ids.includes(k)).map((k) => PLATFORMS.find((p) => p.id === k).name);
  if (!names.length) return "For your devices";
  if (names.length === 1) return `For ${names[0]}`;
  if (names.length === 2) return `For ${names[0]} and ${names[1]}`;
  return `For ${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
};

export function platformCompatibilityHTML(ids = selectedPlatforms()) {
  if (!ids.length) {
    return `<p style="color:var(--text-dim)">
      Select your platforms above. Facts used here are universal: <b>.jar</b> mods target <b>Minecraft Java</b>
      (desktop + Java-capable Android launchers) and <b>.mcpack/.mcaddon</b> packs target <b>Minecraft Bedrock</b>
      (Windows, Android, iPhone/iPad). No other claims are made.</p>`;
  }
  const rows = ids.map((k) => {
    const p = PLATFORMS.find((x) => x.id === k);
    const j = FACTS.java[k], b = FACTS.bedrock[k];
    return `<li><b>${esc(p.icon)} ${esc(p.name)}</b>
      <span class="pf-ok">${j}</span>${b ? `<span class="pf-ok" style="color:var(--text-dim)">${b}</span>` : ""}</li>`;
  }).join("");
  return `<ul class="plat-facts">${rows}</ul>`;
}

/* multi-select button row wired to store + callback */
export function platformButtonsHTML() {
  const on = selectedPlatforms();
  return `<div class="plat-row" role="group" aria-label="Your platforms">
    ${PLATFORMS.map((p) => `<button type="button" class="plat-btn ${on.includes(p.id) ? "on" : ""}" data-plat="${p.id}" aria-pressed="${on.includes(p.id)}"><span class="pb-ic">${p.icon}</span>${esc(p.name)}</button>`).join("")}
  </div>`;
}

export function wirePlatformButtons(root = $("#view"), { id = "homePlat", onChange = null } = {}) {
  const row = root.querySelector(".plat-row");
  if (!row) return;
  row.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-plat]");
    if (!btn) return;
    const idv = btn.dataset.plat;
    const cur = selectedPlatforms();
    const next = cur.includes(idv) ? cur.filter((x) => x !== idv) : [...cur, idv];
    store.set("platforms", next);
    row.querySelectorAll("[data-plat]").forEach((b) => {
      const active = next.includes(b.dataset.plat);
      b.classList.toggle("on", active);
      b.setAttribute("aria-pressed", String(active));
    });
    const head = $(`[data-plat-heading="${id}"]`);
    if (head) head.textContent = platformHeading(next);
    const facts = $(`[data-plat-facts="${id}"]`);
    if (facts) facts.innerHTML = platformCompatibilityHTML(next);
    onChange?.(next);
    toast(next.length ? `Platforms: ${next.length} selected` : "Platform selection cleared");
  });
}
