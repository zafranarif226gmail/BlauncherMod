/* ============================================================
   BLauncher Mod — Minecraft version system
   RELEASE | SNAPSHOT | BETA | ALPHA | MODDED
   Official sources: Mojang piston-meta, FabricMC/QuiltMC/LegacyFabric metas,
   Modrinth live compatibility tags (labeled as such). No invented versions.
   ============================================================ */
import { $, $$, esc, fmtDate, route, page, stateBlock, errorBlock, store, toast, notifySelPill, ICON } from "./core.js";
import { loadVersions, versionList, versionMeta, gvBadge, fabricGameVersions, quiltGameVersions, legacyFabricGameVersions, mrSearch, LOADERS, LOADER_TARGETS } from "./data.js";

const TABS = [
  { id: "release", label: "RELEASE", sub: "Official releases", mojang: "release" },
  { id: "snapshot", label: "SNAPSHOT", sub: "Development builds", mojang: "snapshot" },
  { id: "beta", label: "BETA", sub: "Historical beta", mojang: "old_beta" },
  { id: "alpha", label: "ALPHA", sub: "Historical alpha", mojang: "old_alpha" },
  { id: "modded", label: "MODDED", sub: "Loaders", mojang: null },
];
const PAGE = 60;

route("/versions", async function versionsView({ params, signal }) {
  const tab = TABS.some((t) => t.id === params.get("tab")) ? params.get("tab") : "release";
  const view = $("#view");

  view.innerHTML = page(`
  <div class="cat-head">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo">🎮</span> Minecraft Versions</h1>
    <span class="cat-sub">Every real Minecraft version — release · snapshot · beta · alpha — plus each mod loader's supported builds. Data: Mojang version manifest v2 + official loader meta APIs + live Modrinth tags. Nothing is invented.</span>
  </div>
  <div class="ver-tabs" id="verTabs">
    ${TABS.map((t) => `<button class="ver-tab ${tab === t.id ? "on" : ""}" data-tab="${t.id}" aria-label="${t.label} versions">${t.label}<small>${t.sub}</small></button>`).join("")}
  </div>
  <div id="tabBody">…</div>`);

  $("[data-goback]").addEventListener("click", () => history.back());
  document.querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => {
    location.hash = "/versions?tab=" + b.dataset.tab;
  }));

  const body = $("#tabBody");
  if (TABS.find((t) => t.id === tab)?.mojang) await renderMojang(body, TABS.find((t) => t.id === tab).mojang, tab, signal);
  else await renderModded(body, signal);
  notifySelPill();
});

/* ---------- Mojang-backed tabs ---------- */
const TAB_INFO = {
  release: { title: "Official release versions", text: "Stable Minecraft releases. Pick one to target it across all of BLauncher Mod's searches." },
  snapshot: { title: "Official snapshot versions", text: "Mojang's experimental development builds used to preview upcoming releases." },
  beta: { title: "Historical beta versions", text: "The original Beta era (b1.x) prior to release 1.0. Sourced from Mojang's official manifest metadata." },
  alpha: { title: "Historical alpha versions", text: "The very early Alpha era (a1.x) of Minecraft. Sourced from Mojang's official manifest metadata." },
};

async function renderMojang(body, listKey, tabKey, signal) {
  body.innerHTML = `
    <div class="ver-tools">
      <div class="search-inline">${ICON.search}<input id="verSearch" placeholder="Search versions… (e.g. 1.21, b1.7)" aria-label="Search versions"/></div>
      <select class="select" id="verSort" aria-label="Sort versions">
        <option value="new">Newest first</option><option value="old">Oldest first</option>
      </select>
      <span class="ver-count" id="verCount"></span>
    </div>
    <div class="meta-note">${TAB_INFO[tabKey].text}</div>
    <div class="ver-grid" id="verGrid">${spinnerCells(8)}</div>
    <div class="load-more-ver"><button class="btn" id="verMore" hidden>Show more versions</button></div>`;

  let list;
  try { list = await versionList(listKey); }
  catch (e) { body.innerHTML = errorBlock("Could not load Mojang version metadata: " + (e?.message || "network error") + ". Version data comes from piston-meta.mojang.com."); return; }
  if (signal()) return;

  $("#verCount").textContent = `${list.length} versions · official Mojang manifest v2`;
  let shown = 0;
  const search = $("#verSearch"), sortSel = $("#verSort");
  const meta = await loadVersions();
  const manifest = meta;

  const renderChunk = () => {
    const q = (search.value || "").toLowerCase();
    const filtered = list.filter((v) => !q || v.id.toLowerCase().includes(q));
    const asc = sortSel.value === "old";
    const ordered = asc ? [...filtered].reverse() : filtered;
    const slice = ordered.slice(0, shown + PAGE);
    shown = slice.length;
    $("#verCount").textContent = `${filtered.length} versions match`;
    $("#verGrid").innerHTML = slice.map(cellHTML).join("") ||
      `<div class="state-block" style="grid-column:1/-1"><div class="s-emoji">🤔</div><h3>No versions match</h3><p>Try searching for something like “1.16”.</p></div>`;
    const moreBtn = $("#verMore");
    moreBtn.hidden = slice.length >= filtered.length;
    moreBtn.textContent = moreBtn.hidden ? "" : `Show ${Math.min(PAGE, filtered.length - slice.length)} more of ${filtered.length}`;
    $("#verGrid").querySelectorAll(".ver-cell").forEach((c) => c.addEventListener("click", () => {
      const id = c.dataset.ver;
      const on = store.get("selVersion", "") === id;
      store.set("selVersion", on ? "" : id);
      document.querySelectorAll(".ver-cell").forEach((x) => x.classList.toggle("on", !on && x.dataset.ver === id));
      toast(on ? "Version filter cleared" : `Version set to ${id} — searches will now target it`);
      notifySelPill();
    }));
  };
  cellHTML = cellHTML.bind(null);
  function cellHTML(v) {
    const b = gvBadge(v.id, manifest);
    const on = store.get("selVersion", "") === v.id;
    return `<button class="ver-cell ${on ? "on" : ""}" data-ver="${esc(v.id)}" title="Use ${esc(v.id)} across searches">
      <span class="vc-name"><span class="badge ${b.cls}">${b.label}</span> ${esc(v.id)}
        <span class="vc-check">${ICON.check}</span></span>
      <span class="vc-date">Released ${fmtDate(v.time)}</span>
    </button>`;
  }
  search.addEventListener("input", () => { shown = 0; renderChunk(); });
  sortSel.addEventListener("change", () => { shown = 0; renderChunk(); });
  $("#verMore").addEventListener("click", renderChunk);
  renderChunk();
}

/* ---------- MODDED tab ---------- */
function spinnerCells(n = 8) {
  return `<div class="skel skel-card" style="grid-column:span 1"><div class="skel-line w60"></div><div class="skel-line w85"></div></div>`.repeat(n);
}

async function renderModded(body, signal) {
  const current = store.get("selLoader", "");
  body.innerHTML = `
    <div class="meta-note">Supported mod loaders below are the ones BLauncher Mod can filter by on Modrinth. Version metadata for each loader comes from <b>official meta servers</b> or is explicitly labeled as derived from live Modrinth project tags. Nothing here is invented.</div>
    <div class="loader-grid" id="loaderGrid">
      ${LOADERS.map((l) => `
        <button class="loader-card ${current === l.id ? "on" : ""}" data-loader="${l.id}">
          <div class="lc-row"><span class="lc-ic">${esc(l.icon)}</span>
            <span class="lc-name">${esc(l.name)}</span></div>
          <div class="lc-desc">${esc(l.desc)}</div>
          ${LOADER_TARGETS[l.id] ? `<div class="lc-note" data-open="${LOADER_TARGETS[l.id]}">Official site ↗</div>` : ""}
        </button>`).join("")}
    </div>
    <div id="loaderBody"></div>`;

  body.querySelectorAll("[data-open]").forEach((a) => a.addEventListener("click", (e) => {
    e.stopPropagation(); window.open(e.target.closest("[data-open]").dataset.open, "_blank", "noopener");
  }));

  const bodyEl = $("#loaderBody");
  const showLoader = async (id) => {
    if (!id) { bodyEl.innerHTML = ""; return; }
    bodyEl.innerHTML = `<div class="section"><h2 class="section-title"><span class="glyph"></span>${esc(LOADERS.find((l) => l.id === id)?.name || id)} — compatible versions</h2></div>${spinnerCells(6)}`;
    try {
      let rows = [], note = "";
      if (id === "fabric" || id === "quilt" || id === "legacy-fabric") {
        const fn = id === "fabric" ? fabricGameVersions : id === "quilt" ? quiltGameVersions : legacyFabricGameVersions;
        const gv = await fn();
        if (signal()) return;
        rows = gv.map((v) => ({ id: v.version, stable: !!v.stable }));
        note = "Source: official " + (id === "fabric" ? "FabricMC" : id === "quilt" ? "QuiltMC" : "Legacy Fabric") + " meta API (stable = officially supported by the loader).";
      } else if (id === "forge" || id === "neoforge") {
        const res = await mrSearch({ index: "downloads", limit: 100, facets: [["categories:" + id]] });
        if (signal()) return;
        const set = new Set();
        for (const h of res.hits || []) for (const v of (h.versions || h.game_versions || [])) set.add(v);
        rows = [...set].map((idv) => ({ id: idv, stable: true }));
        rows.sort((a, b) => b.id.localeCompare(a.id, undefined, { numeric: true }));
        note = "Derived from the declared game_versions of real, publicly listed " + (id === "forge" ? "Forge" : "NeoForge") + " projects on Modrinth (loader-specific meta APIs are server-side only).";
      } else {
        bodyEl.innerHTML = `<div class="section">${stateBlock("🗂️",
          LOADERS.find((l) => l.id === id)?.name || id,
          "This historical loader has no public game-version metadata API, so no automatic list can be shown without inventing data. Mods using it can still be found: search with the loader filter on the catalogue pages.",
          `<a class="btn btn-primary" href="#/search?loader=${id}&t=${Date.now().toString(36)}" data-nav>Find ${esc(id)} mods</a> ` + (LOADER_TARGETS[id] ? `<a class="btn" href="${LOADER_TARGETS[id]}" target="_blank" rel="noopener noreferrer">Official site ↗</a>` : ""))}</div>`;
        return;
      }
      if (signal()) return;
      const dates = await loadVersions();
      const onTap = (v) => {
        store.set("selVersion", v.id);
        toast(`Version set to ${v.id} with loader ${esc(id)}`);
        notifySelPill();
        bodyEl.querySelectorAll(".ver-cell").forEach((c) => c.classList.toggle("on", c.dataset.ver === v.id));
      };
      bodyEl.innerHTML = `
        <div class="ver-tools">
          <div class="search-inline">${ICON.search}<input id="gvSearch" placeholder="Filter versions…"/></div>
          <select class="select" id="gvSort"><option value="new">Newest first</option><option value="old">Oldest first</option></select>
          <span class="ver-count">${rows.length} versions · ${esc(note.split("(")[0])}</span>
        </div>
        <div class="meta-note">${esc(note)}</div>
        <div class="ver-gv-grid" id="gvGrid"></div>`;
      const grid = $("#gvGrid");
      const paint = () => {
        const q = ($("#gvSearch").value || "").toLowerCase();
        const asc = $("#gvSort").value === "old";
        let f = rows.filter((r) => !q || r.id.toLowerCase().includes(q));
        const withTime = f.map((r) => ({ ...r, t: dates.byId.get(r.id)?.time ? Date.parse(dates.byId.get(r.id).time) : 0 }));
        f = withTime.sort((a, b) => asc ? (a.t - b.t || a.id.localeCompare(b.id)) : (b.t - a.t || b.id.localeCompare(a.id)));
        grid.innerHTML = f.slice(0, 120).map((v) => {
          const b = gvBadge(v.id, dates);
          const on = store.get("selVersion", "") === v.id;
          return `<button class="ver-cell ${on ? "on" : ""}" data-ver="${esc(v.id)}">
            <span class="vc-name"><span class="badge ${b.cls}">${b.label}</span> ${esc(v.id)}<span class="vc-check">${ICON.check}</span></span>
            <span class="vc-date">${v.t ? fmtDate(dates.byId.get(v.id).time) : "from loader meta"}${v.stable ? " · stable" : ""}</span>
          </button>`;
        }).join("") || `<div class="state-block" style="grid-column:1/-1"><h3>No versions match</h3></div>`;
        grid.querySelectorAll(".ver-cell").forEach((c) => c.addEventListener("click", () => {
          const v = rows.find((r) => r.id === c.dataset.ver);
          onTap(v);
        }));
      };
      $("#gvSearch").addEventListener("input", paint);
      $("#gvSort").addEventListener("change", paint);
      paint();
    } catch (e) {
      bodyEl.innerHTML = errorBlock(`Could not load ${id} version metadata: ${e?.message || "network error"}`);
    }
  };

  body.querySelectorAll(".loader-card").forEach((card) => card.addEventListener("click", (e) => {
    if (e.target.closest("[data-open]")) return;
    const id = card.dataset.loader;
    const on = store.get("selLoader", "") === id;
    store.set("selLoader", on ? "" : id);
    body.querySelectorAll(".loader-card").forEach((c) => c.classList.toggle("on", !on && c.dataset.loader === id));
    if (on) { bodyEl.innerHTML = ""; store.set("selVersion", ""); }
    else showLoader(id);
    notifySelPill();
  }));
  if (current) showLoader(current);
}
