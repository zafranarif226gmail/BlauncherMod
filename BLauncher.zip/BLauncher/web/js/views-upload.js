/* ============================================================
   BLauncher Mod — Upload a mod (.jar / .mcpack / .mcaddon)
   • Google login required (uploads only — browsing stays open)
   • SHA-256 duplicate detection (device + backend when present)
   • Real extension + archive validation, configurable size cap
   • Metadata fully optional; auto-detects loader & MC versions
     from genuine metadata, never invents anything
   • Uploaded files are parsed as bytes only — NEVER executed
   ============================================================ */
import { $, $$, esc, page, route, store, toast, observeReveals, ICON, render } from "./core.js";
import { checkExtension, validateZip, detectMetadata, sha256Hex, extractEntry, findEntry } from "./upload-lib.js";
import { gateOrRender, BACKEND, currentUser } from "./auth.js";

const UKEY = "uploadHistory";
const myUploads = () => { try { return store.get(UKEY, []); } catch { return []; } };
const saveUpload = (rec) => {
  const l = myUploads();
  const i = l.findIndex((r) => r.hash === rec.hash);
  if (i >= 0) l.splice(i, 1);
  l.unshift(rec);
  store.set(UKEY, l.slice(0, 50));
};

const LOADER_CHOICES = [
  ["", "Loader...(choose if not detected)"], ["fabric", "Fabric"], ["forge", "Forge"],
  ["neoforge", "NeoForge"], ["quilt", "Quilt"], ["legacy-fabric", "Legacy Fabric"], ["bedrock", "Bedrock pack (.mcpack/.mcaddon)"],
];

function upd(patch) {
  const p = new URLSearchParams(location.hash.split("?")[1] || "");
  for (const [k, v] of Object.entries(patch)) { if (v) p.set(k, v); else p.delete(k); }
  p.set("t", Date.now().toString(36));
  location.hash = "/upload?" + p.toString();
}

route("/upload", async function uploadView() {
  const view = $("#view");
  const cfg = await BACKEND.fetch();
  const user = await gateOrRender(view, "Uploading needs a Google sign-in",
    "Only uploads and publishing are gated. Sign in with Google to upload .jar, .mcpack and .mcaddon files. Browsing, searching and downloading this catalogue never require an account.");
  if (!user) {
    /* upgrade the gate in-place once Google login completes */
    document.addEventListener("authchanged", () => { if (currentUser()?.user) render(); }, { once: true });
    return;
  }

  const maxMB = store.get("uploadMaxMB", 100);
  view.innerHTML = page(`
  <div class="cat-head">
    <button class="btn btn-sm back-btn" data-goback>${ICON.back} Back</button>
    <h1 class="cat-title"><span class="cat-logo">⬆️</span> Upload a mod or pack</h1>
    <span class="cat-sub">Works with <b>.jar</b>, <b>.mcpack</b> and <b>.mcaddon</b>. Metadata is entirely optional — the file is scanned for genuine loader/versions metadata when present.</span>
  </div>

  <div class="section upload-grid">
    <div class="upload-main">
      <div class="up-status" id="backendStatus"></div>

      <label class="dropzone" id="dropzone">
        <input type="file" id="upFile" accept=".jar,.mcpack,.mcaddon" hidden/>
        <div class="dz-ic">📦</div>
        <h3>Choose a file</h3>
        <p>Drag &amp; drop here, or tap to browse. <b>.jar</b> (Java mods) · <b>.mcpack</b> · <b>.mcaddon</b> (Bedrock)</p>
        <p class="dim" id="dzLimit">Size limit: ${maxMB} MB (change below). Files are never executed — validated as bytes only.</p>
        <div class="dz-file" id="dzFile" hidden></div>
      </label>

      <div class="up-opts">
        <label class="opt-line">Size limit
          <input type="number" id="maxMB" min="1" max="1024" value="${maxMB}" style="width:90px"/> MB
          <button class="btn btn-sm " id="saveLimit">Apply</button></label>
        <label class="opt-line">Name <input id="metaName" placeholder="Optional — shown to you only here"/></label>
        <label class="opt-line">Short description <input id="metaDesc" placeholder="Optional — what does it do?"/></label>
      </div>

      <div id="analysis"></div>

      <div class="up-submit-row" id="submitRow" hidden>
        <button class="btn btn-primary" id="upSubmit">⬆️ Submit file</button>
        <span class="dim" id="submitNote"></span>
      </div>
      <div class="progress-wrap" id="progWrap" hidden>
        <div class="progress"><div class="progress-bar" id="progBar"></div></div>
        <span class="prog-txt" id="progTxt">0%</span>
      </div>
    </div>

    <aside class="upload-side">
      <h3 style="margin-top:0">How validation works</h3>
      <ol class="mini-steps">
        <li>Check the real file <b>extension</b> and content type.</li>
        <li><b>SHA-256</b> fingerprint — exact duplicates are flagged (previous uploads on this device and, when connected, on the server).</li>
        <li>The archive is <b>structurally verified</b> as a real ZIP (End-Of-Central-Directory + central directory walk). No data inside it is ever executed.</li>
        <li>Genuine metadata is read (<code>fabric.mod.json</code>, <code>quilt.mod.json</code>, <code>META-INF/mods.toml</code>, <code>META-INF/neoforge.mods.toml</code>, <code>manifest.json</code>, <code>pack.mcmeta</code>) to auto-detect loader &amp; Minecraft versions.</li>
        <li>If detection finds nothing, you choose loader &amp; versions manually — nothing is invented.</li>
      </ol>
      <h3>Your uploads on this device</h3>
      <div id="myUploads">${myUploadsHTML()}</div>
    </aside>
  </div>`);

  $("[data-goback]").addEventListener("click", () => history.back());
  const status = $("#backendStatus");
  status.innerHTML = cfg.uploadEnabled
    ? `<span class="status-banner ok"><span class="b-ic">✅</span><div><h4>Upload backend connected</h4><div>Files go to the site's persistent R2 storage (Cloudflare). Progress is real.</div></div></span>`
    : `<span class="status-banner warn"><span class="b-ic">ℹ️</span><div><h4>No upload backend on this deployment</h4><div>Validation, detection and duplicate checks all work. Submission is kept in your upload history on this device only honestly labelled "device copy" — the site will not pretend the file reached a server.</div></div></span>`;

  /* size limit */
  $("#saveLimit").addEventListener("click", () => {
    const v = Math.max(1, Math.min(1024, parseInt($("#maxMB").value || "100", 10)));
    $("#maxMB").value = v;
    store.set("uploadMaxMB", v);
    $("#dzLimit").textContent = `Size limit: ${v} MB (change below). Files are never executed — validated as bytes only.`;
    toast("Upload size limit set to " + v + " MB");
  });

  /* current parse context */
  let ctx = null;

  const drop = $("#dropzone");
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("drag"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("drag"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("drag"); handleFile(e.dataTransfer.files?.[0]); });
  $("#upFile").addEventListener("change", (e) => handleFile(e.target.files?.[0]));

  async function handleFile(file) {
    const ana = $("#analysis");
    if (!file) return;
    ctx = null; $("#submitRow").hidden = true; $("#progWrap").hidden = true;
    ana.innerHTML = `<div class="skel-card"><div class="skel-line w85"></div><div class="skel-line w60"></div><div class="skel-line w85"></div></div>`;
    await new Promise((r) => setTimeout(r, 60));

    /* 1 — extension */
    const ext = checkExtension(file.name);
    if (!ext.ok) {
      ana.innerHTML = bad(`Wrong file type`, esc(ext.reason) + ` You chose <code>${esc(file.name)}</code>.`);
      return;
    }
    /* 2 — size limit */
    const limitMB = store.get("uploadMaxMB", 100);
    if (file.size > limitMB * 1024 * 1024) {
      ana.innerHTML = bad("Too large", `The file is <b>${(file.size / 1048576).toFixed(1)} MB</b> and this deployment limits uploads to <b>${limitMB} MB</b>. Adjust the limit above or press the site owner to raise it.`);
      return;
    }
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const hash = await sha256Hex(bytes);

      /* 3 — duplicate check */
      const dups = myUploads().filter((r) => r.hash === hash);
      let dupNote = dups.length ? warn(`Duplicate detected`, `This exact file was already added on <b>${esc(dups[0].name)}</b> (${new Date(dups[0].ts).toLocaleString()}). SHA-256 <code>${hash.slice(0, 16)}…</code> matches.`) : "";
      if (cfg.uploadEnabled) {
        dupNote += `<div class="updup-check" id="serDup">Checking server for existing copy…</div>`;
      }

      /* 4 — real archive validation */
      const z = validateZip(bytes);
      if (!z.ok) {
        ana.innerHTML = bad("Not a valid archive", esc(z.reason) + `<div>SHA-256: <code>${esc(hash.slice(0, 24))}…</code></div>`) + dupNote;
        if (dups.length > 0) return;
        return;
      }

      /* 5 — detection from genuine metadata */
      const det = await detectMetadata(bytes, z.entries, ext.kind);

      $("#dzFile").hidden = false;
      $("#dzFile").innerHTML = `<b>${esc(file.name)}</b> · ${(file.size / 1048576).toFixed(2)} MB · ${det.kind.toUpperCase()} · ${z.entries.length} archive entries · SHA-256 <code>${esc(hash.slice(0, 16))}…</code>`;

      ctx = { file, bytes, hash, kind: ext.kind, det, name: $("#metaName").value.trim(), desc: $("#metaDesc").value.trim() };
      renderAnalysis(det, dupNote);

      if (cfg.uploadEnabled) checkServerDup(hash);
    } catch (e) {
      ana.innerHTML = bad("Could not read the file", esc(e?.message || "Unknown error while reading the file on this device."));
    }
  }

  function bad(title, body) {
    return `<div class="state-block error-box"><div class="s-emoji">🚫</div><h3>${esc(title)}</h3><p>${body}</p></div>`;
  }
  function warn(title, body) {
    return `<div class="state-block warn-box"><div class="s-emoji">♻️</div><h3>${esc(title)}</h3><p>${body}</p></div>`;
  }

  function renderAnalysis(det, dupNote) {
    const notes = (det.notes || []).map((n) => `<li>${esc(n)}</li>`).join("");
    const detLoaders = det.loaders.map((l) => `<span class="badge green">${esc(l)}</span>`).join(" ") || `<span class="badge old">not detected</span>`;
    const detVers = det.versions.map((v) => `<span class="badge release">${esc(v)}</span>`).join(" ") || `<span class="badge old">nothing declared</span>`;
    const fullManual = det.detection === "none";
    $("#analysis").innerHTML = dupNote + `
      <div id="detRes">
      <h3 style="margin:14px 0 4px">Automatic scan result <span class="badge ${fullManual ? "old" : "green"}">${fullManual ? "no metadata found" : "detected from real metadata"}</span></h3>
      <div class="det-grid">
        <div><span class="k">Archive type</span><span class="v">${esc(det.kind)}</span></div>
        <div><span class="k">Loader</span><span class="v">${detLoaders}</span></div>
        <div><span class="k">Detected loader</span><span class="v">${detLoaders}</span></div>
        <div><span class="k">Minecraft versions</span><span class="v">${detVers}</span></div>
        ${det.name ? `<div><span class="k">Name in metadata</span><span class="v">${esc(det.name)}</span></div>` : ""}
        ${det.description ? `<div style="grid-column:1/-1"><span class="k">Description in metadata</span><span class="v">${esc(det.description).slice(0, 240)}</span></div>` : ""}
        ${det.packFormat != null ? `<div><span class="k">pack_format</span><span class="v">${det.packFormat}</span></div>` : ""}
        ${det.bedrock?.length ? `<div style="grid-column:1/-1"><span class="k">Bedrock packs inside</span><div class="chips">${det.bedrock.map((b) => `<span class="badge">${esc(b.path)} · ${esc(b.type)}</span>`).join("")}</div></div>` : ""}
      </div>
      ${notes ? `<ul class="det-notes">${notes}</ul>` : ""}
      <div class="manual-block">
        <h4 style="margin:10px 0 4px">${fullManual ? "Manual details (recommended)" : "Manual details (optional override)"}</h4>
        <div class="det-grid">
          <label class="k">Loader
            <select class="select" id="manLoader">${LOADER_CHOICES.map(([v, l]) => `<option value="${v}" ${(det.loaders[0] || "") === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>
          <label class="k">Minecraft version(s) supported
            <input id="manVers" placeholder="comma separated e.g. 1.20.1, 1.19.4"/></label>
        </div>
      </div></div>`;
    $("#submitRow").hidden = false;
    $("#submitNote").textContent = cfg.uploadEnabled
      ? "Submits to the site's storage — real upload progress below."
      : "No upload backend here — the validated file is recorded on this device only.";
    $("#manLoader").value = det.loaders[0] || "";
    $("#manVers").value = det.versions.filter((v) => !/engine/.test(v)).join(", ");
  }

  async function checkServerDup(hash) {
    const el = $("#serDup");
    try {
      const r = await fetch("/api/upload/check?sha=" + encodeURIComponent(hash), { credentials: "same-origin" });
      const j = await r.json();
      if (el && j?.exists) el.innerHTML = `♻️ The server already has this exact file ${j.count ? "(×" + j.count + ")" : ""} — you can still resubmit, but it's the same SHA-256.`;
      else if (el) el.innerHTML = `🆕 This file is new to the server.`;
    } catch {
      if (el) el.innerHTML = `<span class="dim">Server duplicate check unavailable.</span>`;
    }
  }

  $("#upSubmit").addEventListener("click", () => {
    const btn = $("#upSubmit");
    btn.disabled = true; btn.textContent = "Uploading…";
    const manL = $("#manLoader").value || ctx.det.loaders[0] || "";
    const manV = ($("#manVers").value || "").split(",").map((s) => s.trim()).filter(Boolean);
    const detV = ctx.det.versions.filter((v) => !/engine/.test(String(v)));
    const versions = [...new Set([...(manV.length ? manV : detV)])];
    const rec = {
      hash: ctx.hash, name: $("#metaName").value.trim() || ctx.det.name || ctx.file.name, size: ctx.file.size,
      kind: ctx.kind, loaders: manL ? [manL] : ctx.det.loaders, versions: versions.slice(0, 12),
      desc: $("#metaDesc").value.trim() || ctx.det.description || "",
      ts: Date.now(), status: cfg.uploadEnabled ? "server" : "device",
      notes: ctx.det.notes || [],
    };
    if (!cfg.uploadEnabled) {
      rec.serverError = "no backend on this deployment";
      saveUpload(rec);
      $("#myUploads").innerHTML = myUploadsHTML();
      toast("Validated & saved to this device's history — no server was contacted (honestly, no backend here).", { ms: 3800 });
      $("#submitRow").hidden = false; btn.disabled = false; btn.textContent = "⬆️ Submit file";
      return;
    }
    const fd = new FormData();
    fd.append("file", ctx.file, ctx.file.name);
    fd.append("meta", JSON.stringify({ name: rec.name, desc: rec.desc, loaders: rec.loaders, versions: rec.versions, sha256: rec.hash }));
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload", true);
    xhr.withCredentials = true;
    $("#progWrap").hidden = false;
    $("#progBar").style.width = "0%";
    $("#progTxt").textContent = "0%";
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 100);
        $("#progBar").style.width = pct + "%";
        $("#progTxt").textContent = pct + "% · " + (e.loaded / 1048576).toFixed(1) + "/" + (e.total / 1048576).toFixed(1) + " MB";
      }
    };
    xhr.onerror = () => {
      $("#progTxt").textContent = "Upload failed";
      rec.serverError = "network error";
      saveUpload(rec); $("#myUploads").innerHTML = myUploadsHTML();
      toast("Upload failed — the file could not reach the server.", { err: true });
      btn.disabled = false; btn.textContent = "⬆️ Submit file";
    };
    xhr.onload = () => {
      let j = {};
      try { j = JSON.parse(xhr.responseText); } catch {}
      if (xhr.status === 201 || (xhr.status === 200 && j.stored)) {
        rec.status = "server"; rec.serverId = j.objectKey || rec.hash;
        if (j.duplicate) rec.duplicateOf = j.duplicate;
        saveUpload(rec);
        $("#myUploads").innerHTML = myUploadsHTML();
        $("#progBar").style.width = "100%"; $("#progTxt").textContent = "Stored ✓";
        toast(j.duplicate ? "Already on the server (Same SHA-256) — kept your record." : "Upload complete — stored on the server.", { ms: 3400 });
      } else {
        rec.serverError = j?.error || ("HTTP " + xhr.status);
        saveUpload(rec); $("#myUploads").innerHTML = myUploadsHTML();
        $("#progTxt").textContent = "Rejected";
        toast("Upload rejected: " + (j?.error || ("HTTP " + xhr.status)), { err: true, ms: 4200 });
      }
      btn.disabled = false; btn.textContent = "⬆️ Submit file";
    };
    xhr.send(fd);
  });

  $("#myUploads").addEventListener("click", (e) => {
    const del = e.target.closest("[data-up-del]");
    if (del) {
      const l = myUploads().filter((r) => r.hash !== del.dataset.upDel);
      store.set(UKEY, l);
      $("#myUploads").innerHTML = myUploadsHTML();
      toast("Removed from this device's history");
    }
  });
  observeReveals();
});

function myUploadsHTML() {
  const l = myUploads();
  if (!l.length) return `<p class="dim">Nothing uploaded yet — your validated uploads and their SHA-256 fingerprints will be listed here (stored only on this device).</p>`;
  return `<ul class="up-list">` + l.map((r) => `
    <li class="up-item">
      <div>
        <b>${esc(r.name || "unnamed")}</b>
        <span class="dim">${esc(r.kind || "")} · ${(r.size / 1048576).toFixed(2)} MB · ${new Date(r.ts).toLocaleDateString()}</span>
        <span class="up-status-badge ${r.status === "server" ? "ok" : "warn"}">${r.status === "server" ? (r.duplicateOf ? "server · duplicate" : "on server") : (r.serverError ? "device only — " + esc(r.serverError) : "device copy")}</span>
      </div>
      <code>${esc((r.hash || "").slice(0, 16))}…</code>
      <button class="btn btn-sm" data-up-del="${esc(r.hash)}" aria-label="Remove record">✕</button>
    </li>`).join("") + `</ul>`;
}
