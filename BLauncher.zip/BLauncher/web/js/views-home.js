/* ============================================================
   BLauncher Mod — Home page + Search results page
   ============================================================ */
import { $, $$, esc, fmtNum, section, skelCards, stateBlock, errorBlock, observeReveals, route, page, store, ICON } from "./core.js";
import { mrSearch, mrProjectsBySlugs, versionList, CATEGORIES, FEATURED_SLUGS, LOADERS, gvBadge } from "./data.js";
import { modCard, bindCards, searchBoxHTML, wireSearchBox, netFacets } from "./cards.js";
import { platformButtonsHTML, wirePlatformButtons, platformHeading, platformCompatibilityHTML, selectedPlatforms } from "./platforms.js";

/* cinematic blocky landscape (inline SVG art, never breaks) */
const SCENERY = `<svg class="hero-scenery" viewBox="0 0 1200 260" preserveAspectRatio="none" aria-hidden="true">
  <defs>
    <linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="rgba(42,120,72,0.0)"/><stop offset="1" stop-color="rgba(16,64,36,0.55)"/>
    </linearGradient>
    <linearGradient id="hfar" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#0e2b1a"/><stop offset="1" stop-color="#0a2013" stop-opacity="0.0"/>
    </linearGradient>
    <linearGradient id="hnear" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#081a0f"/><stop offset="1" stop-color="#050d08"/>
    </linearGradient>
  </defs>
  <circle cx="910" cy="52" r="34" fill="rgba(125,255,180,0.14)"/>
  <circle cx="910" cy="52" r="20" fill="rgba(125,255,180,0.35)"/>
  <rect x="0" y="0" width="1200" height="260" fill="url(#hsky)"/>
  <g fill="url(#hfar)">
    <rect x="120" y="150" width="150" height="90"/><rect x="200" y="110" width="120" height="130"/>
    <rect x="640" y="140" width="180" height="100"/><rect x="760" y="96" width="140" height="150"/>
    <rect x="1010" y="130" width="130" height="110"/>
    <path d="M0 260 V190 h60 v-40 h50 v40 h60 v60z"/>
  </g>
  <g fill="url(#hnear)">
    <rect x="0" y="208" width="1200" height="70"/>
    <path d="M0 208 v-28 h44 v-26 h40 v26 h50 v28z"/>
    <path d="M330 208 v-40 h30 v-34 h34 v34 h28 v40z"/>
    <path d="M540 208 v-20 h52 v-22 h40 v22 h48 v20z"/>
    <path d="M770 208 v-44 h34 v-30 h30 v30 h30 v44z"/>
    <path d="M1050 208 v-26 h46 v-20 h38 v20 h46 v26z"/>
  </g>
  <g fill="rgba(125,255,180,0.10)">
    <rect x="52" y="150" width="12" height="46"/><rect x="362" y="118" width="12" height="52"/>
    <rect x="576" y="152" width="10" height="40"/><rect x="800" y="118" width="12" height="52"/>
    <rect x="1086" y="150" width="12" height="44"/>
  </g>
</svg>`;

function particles(n = 12) {
  let html = '<div class="hero-particles" aria-hidden="true">';
  for (let i = 0; i < n; i++) {
    const left = 2 + Math.random() * 96;
    const dx = (Math.random() * 80 - 40).toFixed(0);
    const dur = 9 + Math.random() * 9;
    const delay = (Math.random() * 14).toFixed(1);
    const o = (0.35 + Math.random() * 0.5).toFixed(2);
    const size = 6 + Math.floor(Math.random() * 8);
    html += `<span class="p-particle" style="left:${left}%;--dx:${dx}px;--o:${o};width:${size}px;height:${size}px;animation-duration:${dur}s;animation-delay:${delay}s"></span>`;
  }
  return html + "</div>";
}

const catIcon = (c) => c.icon;

/* ---------------- HOME ---------------- */
route("/", (ctx) => homeRoute(ctx));

async function homeRoute({ signal }) {
  const view = $("#view");
  const ver = store.get("selVersion", "");
  const loader = store.get("selLoader", "");

  view.innerHTML = page(`
  <section class="hero">
    ${SCENERY}${particles()}
    <div class="hero-veil"></div>
    <div class="hero-inner">
      <span class="hero-kicker"><span class="dot"></span> Independent mod discovery · no login required</span>
      <h1 class="hero-title">Discover <span class="grad">Minecraft</span> Mods</h1>
      <p class="hero-sub">Explore. Download. Transform Your World.</p>
      <div data-search></div>
      <div class="platform-cards">
        <a class="plat-card" href="#/modrinth" data-nav>
          <span class="p-ic"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 3 6.5v5C3 17 7 20.5 12 21c5-.5 9-4 9-9.5v-5L12 3z"/></svg></span>
          <span><span class="t">Browse Modrinth</span><br/><span class="d">200k+ open-source projects</span></span>
          <span class="p-risk">${ICON.arrow}</span>
        </a>
        <a class="plat-card" href="#/curseforge" data-nav>
          <span class="p-ic"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 3 6.5v5C3 17 7 20.5 12 21c5-.5 9-4 9-9.5v-5L12 3z"/></svg></span>
          <span><span class="t">Browse CurseForge</span><br/><span class="d">Legacy catalogue · API-key aware</span></span>
          <span class="p-risk">${ICON.arrow}</span>
        </a>
      </div>
    </div>
  </section>

  <div class="section reveal" style="padding-top:34px" id="platSection">
    <div class="section-head"><div><h2 class="section-title"><span class="glyph"></span>Which platforms do you use?</h2>
      <div class="section-sub" id="pfNote">Tap every device you play or test on — you can pick several and change it any time.</div></div></div>
    <h3 class="plat-heading" data-plat-heading="homePlat" style="margin:4px 0 10px;font-size:1.25rem">${esc(platformHeading())}</h3>
    ${platformButtonsHTML()}
    <div data-plat-facts="homePlat" class="plat-facts-wrap" style="margin-top:12px">
      ${platformCompatibilityHTML(selectedPlatforms())}
    </div>
  </div>

  <div class="section reveal" style="padding-top:34px">
    <div class="section-head"><div><h2 class="section-title"><span class="glyph"></span>Quick finder</h2>
      <div class="section-sub">Pick a Minecraft version and mod loader — the filters are remembered and applied everywhere.</div></div></div>
    <div class="selector-row">
      <select class="select" id="selVersion" aria-label="Minecraft version"><option value="">All versions</option></select>
      <select class="select" id="selLoader" aria-label="Mod loader"><option value="">All loaders</option></select>
      <button class="btn btn-primary" id="finderGo">Find mods ${ICON.arrow}</button>
      ${(ver || loader) ? `<button class="btn btn-sm btn-ghost" id="finderClear">Reset filters</button>` : ""}
    </div>
  </div>

  <div data-featured></div>
  <div data-trending></div>
  <div data-popular></div>
  <div data-updated></div>
  <div data-cats></div>
  `);

  /* sponsor chip */
  $$(".hero-inner").forEach((h) => {
    const chip = document.createElement("div");
    chip.className = "sponsor-chip";
    chip.innerHTML = `★ Sponsored &amp; made by <b>Arif The Gamer</b>`;
    chip.style.animation = "pageIn .8s .5s var(--ease) both";
    h.appendChild(chip);
  });

  /* search */
  $$("[data-search]").forEach((slot) => { slot.outerHTML = searchBoxHTML({ id: "heroSearch" }); });
  wireSearchBox("heroSearch"); /* wire after injection */

  /* platform selector */
  wirePlatformButtons(view);

  /* selectors */
  try {
    const rel = (await versionList("release"));
    const sel = $("#selVersion");
    rel.slice(0, 40).forEach((v) => {
      const o = document.createElement("option");
      o.value = v.id; o.textContent = v.id;
      sel.appendChild(o);
    });
    sel.value = ver;
  } catch { $("#selVersion").disabled = true; }
  const lsel = $("#selLoader");
  LOADERS.forEach((l) => {
    const o = document.createElement("option");
    o.value = l.id; o.textContent = l.name;
    lsel.appendChild(o);
  });
  lsel.value = loader;

  $("#finderGo")?.addEventListener("click", () => {
    const v = $("#selVersion").value, l = $("#selLoader").value;
    store.set("selVersion", v); store.set("selLoader", l);
    const qs = new URLSearchParams();
    if (v) qs.set("ver", v);
    if (l) qs.set("loader", l);
    qs.set("t", Date.now().toString(36));
    location.hash = "/search?" + qs.toString();
  });
  $("#finderClear")?.addEventListener("click", () => {
    store.set("selVersion", ""); store.set("selLoader", "");
    $("#selVersion").value = ""; $("#selLoader").value = "";
    toast("Version & loader filters reset");
  });

  /* featured rail first, then the other rails */
  const mount = (sel, html) => { const el = $(sel); if (el && html) { el.outerHTML = html; } };

  mount("[data-featured]", `<div data-featured-list>${section("Featured mods", skelCards(8, "compact"), { sub: "Community essentials — real projects pulled live from Modrinth." })}</div>`);
  try {
    const res = await mrProjectsBySlugs(FEATURED_SLUGS);
    if (signal()) return;
    const hits = (res.hits || []).slice(0, 8);
    const html = section("Featured mods",
      `<div class="card-grid compact">${hits.map((h) => modCard(h)).join("")}</div>`,
      { sub: "Community essentials — pulled live from the Modrinth API.", more: `<a class="link-more" href="#/modrinth" data-nav>Open Modrinth ${ICON.arrow}</a>` });
    $("[data-featured-list]").outerHTML = html;
  } catch (e) {
    $("[data-featured-list]").outerHTML = errorBlock("Could not reach api.modrinth.com while fetching featured mods. " + (e?.message || ""));
  }

  const rail = async (sel, title, sub, index) => {
    try {
      const fac = netFacets(store.get("selLoader", "") || null, store.get("selVersion", "") || null);
      const res = await mrSearch({ index, limit: 8, facets: fac });
      if (signal()) return;
      const grid = (res.hits || []).length
        ? `<div class="card-grid">${res.hits.map((h) => modCard(h)).join("")}</div>`
        : stateBlock("🫥", "No mods match these filters", "Try clearing the version or loader filter.");
      $(sel).outerHTML = section(title, grid, { sub, more: `<a class="link-more" href="#/modrinth?sort=${index}" data-nav>See all ${ICON.arrow}</a>` });
    } catch (e) {
      $(sel).outerHTML = `<div class="section reveal">${errorBlock("Modrinth API unreachable: " + (e?.message || "network error"))}</div>`;
    }
  };

  await Promise.all([
    (async () => { await rail("[data-trending]", "Trending mods", "Most followed right now (Modrinth sort: follows).", "follows"); })(),
    (async () => { await rail("[data-popular]", "Popular mods", "All-time downloads leaders (sort: downloads).", "downloads"); })(),
    (async () => { await rail("[data-updated]", "Recently updated", "Freshly maintained — sorts by latest update.", "updated"); })(),
  ]);

  /* category grid with live counts/icons */
  mount("[data-cats]", `<div data-cats-list>${section("Mod categories", skelCards(5), { sub: "Tap a category to open it filtered in the catalogue." })}</div>`);
  const catCards = await Promise.allSettled(CATEGORIES.map(async (c) => {
    const res = await mrSearch({
      query: c.query || "",
      limit: 1,
      facets: [
        ...(c.facet || []),
        ...netFacets(store.get("selLoader", "") || null, store.get("selVersion", "") || null),
      ],
    });
    return { c, hits: res.hits?.[0] || null, total: res.total_hits ?? null };
  }));
  if (signal()) return;
  const gridHTML = `<div class="cat-grid">` + catCards.map((r, i) => {
    const c = CATEGORIES[i];
    const img = r.value?.hits?.icon_url || "";
    const cnt = r.value?.total ? `Est. ${fmtNum(r.value.total)} results` : "Changed over time";
    const qs = new URLSearchParams();
    qs.set("cat", c.name);
    qs.set("t", Date.now().toString(36));
    return `<a class="cat-card" href="#/search?${qs}" data-nav>
      ${img ? `<img class="cat-img" src="${esc(img)}" alt="" loading="lazy" decoding="async" onerror="this.remove()" referrerpolicy="no-referrer"/>` : ""}
      <span class="cat-shade"></span>
      <span class="cc-name"><span class="cc-icon">${catIcon(c)}</span>${esc(c.name)}</span>
      <span class="cc-cnt">${cnt}</span>
    </a>`;
  }).join("") + `</div>`;
  $("[data-cats-list]").outerHTML = section("Mod categories", gridHTML, { sub: "Tap a category to open it filtered in the catalogue." });

  bindCards(); observeReveals();
}
