/* ============================================================
   BLauncher Mod — Favorites · Recently viewed · About · Privacy
   ============================================================ */
import { $, esc, route, page, section, stateBlock, store, syncFavCount, toast, observeReveals, ICON } from "./core.js";
import { gvBadge } from "./data.js";
import { imgBlock } from "./cards.js";

/* ---------------- favorites ---------------- */
route("/favorites", async function favoritesView() {
  const favs = Object.entries(store.favs()).sort((a, b) => (b[1].ts || 0) - (a[1].ts || 0));
  const view = $("#view");
  view.innerHTML = page(`
    <div class="cat-head">
      <h1 class="cat-title"><span class="cat-logo">❤️</span> Favorites</h1>
      <span class="cat-sub">Stored only on this device — no account needed.</span>
      ${favs.length ? `<button class="btn btn-sm" id="clearFavs">Remove all</button>` : ""}
    </div>
    <div class="section" id="favBody"></div>`);

  const body = $("#favBody");
  if (!favs.length) {
    body.innerHTML = stateBlock("❤️", "No favorites yet", "Tap the heart on any mod card or detail page to keep it here.",
      `<a class="btn btn-primary" href="#/modrinth" data-nav>Browse Modrinth</a>`);
    return;
  }
  body.innerHTML = `<div class="card-grid">` + favs.map(([id, f]) => fCard(id, f)).join("") + `</div>`;
  $("#clearFavs")?.addEventListener("click", () => {
    store.set("favorites", {}); syncFavCount(); toast("All favorites removed");
    location.hash = "/favorites?r=" + Date.now().toString(36);
  });
  bindFavCards();
});

function fCard(id, f) {
  const vs = f.versions || [];
  return `<article class="mod-card reveal" data-href="#/${f.source === "curseforge" ? "curseforge" : "modrinth"}/mod/${esc(f.slug || id)}">
    <button class="fav-heart on" data-unfav="${esc(id)}" aria-label="Remove favorite">${ICON.heart}</button>
    <div class="mod-head">
      ${imgBlock(f.icon, f.title + " icon", "mod-icon", (f.title || "?")[0]?.toUpperCase() || "?")}
      <div class="mod-titles">
        <div class="mod-name">${esc(f.title || id)}</div>
        <div class="mod-author">${ICON.user} <span>${esc(f.author || "—")}</span></div>
      </div>
    </div>
    <p class="mod-desc">${esc(f.desc || "")}</p>
    <div class="mod-meta"><span class="stat">${ICON.down} ${(+f.downloads || 0).toLocaleString()}</span></div>
    <div class="chips">
      ${vs.slice(0, 2).map((v) => { const b = gvBadge(v); return `<span class="badge ${b.cls}">MC ${esc(v)}</span>`; }).join("")}
      ${(f.loaders || []).slice(0, 3).map((l) => `<span class="badge green">${esc(l)}</span>`).join("")}
      <span class="src-badge ${esc(f.source || "modrinth")}">${(f.source || "modrinth") === "curseforge" ? "CurseForge" : "Modrinth"}</span>
    </div>
  </article>`;
}

function bindFavCards() {
  document.querySelectorAll(".mod-card[data-href]").forEach((card) => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".fav-heart")) return;
      location.hash = card.dataset.href;
    });
  });
  document.querySelectorAll("[data-unfav]").forEach((b) => b.addEventListener("click", (e) => {
    e.stopPropagation();
    const id = b.dataset.unfav;
    const f = store.favs()[id];
    store.toggleFav({ id, ...f });
    syncFavCount();
    toast(`${f.title || id} removed from favorites`);
    location.hash = "/favorites?r=" + Date.now().toString(36);
  }));
}

/* ---------------- recently viewed ---------------- */
route("/recent", async function recentView() {
  const rec = store.recent();
  document.getElementById("view").innerHTML = page(`
    <div class="cat-head">
      <h1 class="cat-title"><span class="cat-logo">🕘</span> Recently viewed</h1>
      <span class="cat-sub">The last 24 projects you opened on this device.</span>
    </div>
    <div class="section">${rec.length
      ? `<div class="card-grid">` + rec.map((f) => fCard(String(f.id), f)).join("") + `</div>`
      : stateBlock("🕘", "Nothing here yet", "Open any mod detail page and it will appear in this list.",
        `<a class="btn btn-primary" href="#/modrinth" data-nav>Start browsing</a>`)}</div>`);
  bindFavCards();
});

/* ---------------- about ---------------- */
route("/about", () => {
  document.getElementById("view").innerHTML = page(`
  <div class="doc-page reveal">
    <h1>About BLauncher Mod</h1>
    <p><b>BLauncher Mod</b> is a premium web experience for discovering Minecraft mods. Browse the Modrinth catalogue with instant search, five version tabs (RELEASE · SNAPSHOT · BETA · ALPHA · MODDED), loader filters, categories, favorites and full mod details with real download links — all with no login.</p>
    <h2>Data sources</h2>
    <ul>
      <li><a href="https://docs.modrinth.com/api/" target="_blank" rel="noopener noreferrer">Modrinth v2 API</a> (projects, search, versions, gallery)</li>
      <li><a href="https://piston-meta.mojang.com/mc/game/version_manifest_v2.json" target="_blank" rel="noopener noreferrer">Mojang version manifest v2</a> (official version metadata)</li>
      <li><a href="https://meta.fabricmc.net/" target="_blank" rel="noopener noreferrer">FabricMC</a>, <a href="https://meta.quiltmc.org/" target="_blank" rel="noopener noreferrer">QuiltMC</a> and <a href="https://legacyfabric.net/" target="_blank" rel="noopener noreferrer">Legacy Fabric</a> official meta APIs</li>
      <li><a href="https://docs.curseforge.com/" target="_blank" rel="noopener noreferrer">CurseForge API</a> (optional, API-key gated — status always disclosed)</li>
    </ul>
    <h2>Independence</h2>
    <p>BLauncher Mod is an independent fan project and is <b>not affiliated with Mojang Studios, Microsoft, Modrinth or CurseForge</b>. No version or compatibility information is invented: missing data is labeled as missing.</p>
    <h2>Made by</h2>
    <p>BLauncher Mod was made and is sponsored by <b>Arif The Gamer</b>.</p>
  </div>`);
});

/* ---------------- privacy ---------------- */
route("/privacy", () => {
  document.getElementById("view").innerHTML = page(`
  <div class="doc-page reveal">
    <h1>Privacy Policy</h1>
    <p>Browsing, searching and <b>downloading require no account and no login</b>. There are no analytics, no tracking pixels and no third-party ad scripts — ever.</p>
    <h2>What stays on your device (browser localStorage)</h2>
    <ul>
      <li>Favorites, recently viewed projects and search history</li>
      <li>Theme, selected Minecraft version, loader and platform preferences</li>
      <li>Optional CurseForge API key you explicitly paste in (sent only to api.curseforge.com or our relay)</li>
      <li>Your upload history records (file names, SHA-256 fingerprints — never the file itself unless the backend stores it)</li>
      <li>Publishing drafts</li>
    </ul>
    <h2>Google sign-in (optional, upload &amp; publish only)</h2>
    <ul>
      <li>Sign-in uses the official <b>Google Identity Services</b> flow. Google sends an ID token directly to this site's backend, where it is verified against Google's official tokeninfo endpoint.</li>
      <li>The session is kept as an <b>HttpOnly, Secure, SameSite=Lax signed cookie</b> — it cannot be read by page scripts.</li>
      <li>The backend stores only your Google avatar URL, display name and email in the session — nothing is shared with third parties.</li>
      <li>Sign out clears the cookie and ends the session immediately.</li>
    </ul>
    <h2>Requests to third parties</h2>
    <p>To show live data, your browser directly calls the public Modrinth API, Mojang's version manifest and loader meta APIs, plus CurseForge (through this site's proxy or, if you configured a key, directly). Publishing to Modrinth sends your project plus <b>your own Modrinth token, straight to api.modrinth.com</b> — it is never stored or relayed elsewhere.</p>
    <h2>Removing data</h2>
    <p>Clear your browser site data (or use the "clear history" / "remove favorites" buttons) to erase device-side data instantly. Signing out removes the session.</p>
  </div>`);
});
