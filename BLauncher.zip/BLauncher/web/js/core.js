/* ============================================================
   BLauncher Mod — core: router, store, cached API client, UI kit
   ============================================================ */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[c]));

export const debounce = (fn, ms = 250) => {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
};

export const fmtNum = (n) => {
  n = Number(n) || 0;
  if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, "") + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
};

export const fmtDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso).slice(0, 10);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
};

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/* ---------------- persistent store (no login; local only) ---------------- */
const KEY = "blauncherMod.v1";

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; }
}
let S = load();
const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* storage full/private */ } };

export const store = {
  get(k, dflt) { return S[k] !== undefined ? S[k] : dflt; },
  set(k, v) { S[k] = v; persist(); },
  del(k) { delete S[k]; persist(); },
  /* favorites: object of projectId -> {source, slug, title, icon, author, ts} */
  favs() { return S.favorites || {}; },
  isFav(id) { return !!(S.favorites && S.favorites[id]); },
  toggleFav(item) {
    const f = S.favorites || {};
    if (f[item.id]) { delete f[item.id]; } else { f[item.id] = { ...item, ts: Date.now() }; }
    S.favorites = f; persist();
    return !!(S.favorites && S.favorites[item.id]);
  },
  /* recently viewed: array, newest first, max 24 */
  recent() { return S.recent || []; },
  addRecent(item) {
    const r = (S.recent || []).filter((x) => x.id !== item.id);
    r.unshift({ ...item, ts: Date.now() });
    S.recent = r.slice(0, 24); persist();
  },
  /* search history: array of strings, max 12 */
  history() { return S.searchHistory || []; },
  pushHistory(q) {
    q = (q || "").trim();
    if (!q) return;
    let h = (S.searchHistory || []).filter((x) => x.toLowerCase() !== q.toLowerCase());
    h.unshift(q);
    S.searchHistory = h.slice(0, 12); persist();
  },
  clearHistory() { S.searchHistory = []; persist(); },
};

/* ---------------- cached API client ---------------- */
class ApiError extends Error {
  constructor(msg, status) { super(msg); this.status = status; }
}

const memCache = new Map();   // url -> {t, data}
const inflight = new Map();   // url -> Promise data

export async function api(url, { ttl = 5 * 60_000, headers, timeout = 15_000 } = {}) {
  const hit = memCache.get(url);
  if (hit && Date.now() - hit.t < ttl) return hit.data;
  if (inflight.has(url)) return inflight.get(url);

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort("timeout"), timeout);
  const p = (async () => {
    const res = await fetch(url, { headers, signal: ctrl.signal });
    if (!res.ok) { const err = new ApiError(`HTTP ${res.status} for ${url}`, res.status); err.url = url; throw err; }
    const data = await res.json();
    memCache.set(url, { t: Date.now(), data });
    /* guard cache size */
    if (memCache.size > 300) {
      const oldest = [...memCache.entries()].sort((a, b) => a[1].t - b[1].t).slice(0, 60);
      oldest.forEach(([k]) => memCache.delete(k));
    }
    return data;
  })()
    .finally(() => { clearTimeout(timer); inflight.delete(url); });
  inflight.set(url, p);
  return p;
}

/* ---------------- router (hash-based, state in URL) ---------------- */
const routes = [];
let currentRoute = null;
let renderSeq = 0;

function parseHash() {
  const h = location.hash.replace(/^#/, "") || "/";
  const [path, qs] = h.split("?");
  const params = new URLSearchParams(qs || "");
  return { path: path || "/", params };
}

export function route(pattern, handler) {
  /* pattern like "/modrinth/mod/:id" */
  const parts = pattern.split("/").filter(Boolean);
  routes.push({ parts, handler });
}

function match(path) {
  const segs = path.split("/").filter(Boolean);
  for (const r of routes) {
    if (r.parts.length !== segs.length) continue;
    const m = {};
    let ok = true;
    for (let i = 0; i < segs.length; i++) {
      const p = r.parts[i];
      if (p.startsWith(":")) m[p.slice(1)] = decodeURIComponent(segs[i]);
      else if (p !== segs[i]) { ok = false; break; }
    }
    if (ok) return { handler: r.handler, params: m };
  }
  return null;
}

export function navigate(hash, { replace = false } = {}) {
  const target = "#" + (hash.startsWith("/") ? hash : "/" + hash);
  if (location.hash === target) { render(); return; }
  if (replace) location.replace(target); else location.hash = target;
}

export async function render() {
  const seq = ++renderSeq;
  const { path, params } = parseHash();
  const m = match(path);
  const view = $("#view");
  currentRoute = { path, params };

  /* nav highlighting */
  const seg = path.split("/")[1] || "home";
  $$(".nav-link").forEach((a) => {
    const r = a.dataset.route;
    const on = r === seg || (r === "home" && seg === "");
    a.classList.toggle("active", !!on);
  });
  $("#navToggle")?.setAttribute("aria-expanded", "false");
  $("#mainNav")?.classList.remove("open");

  if (!m) {
    view.innerHTML = notFoundHTML(path);
    return;
  }
  try {
    /* `params` is the URLSearchParams of the query string (e.g. ?q=…&ver=…);
       `routeParams` carries hash-route placeholders like :id — fix for "params.get is not a function". */
    await m.handler({ params, routeParams: m.params, query: params, path, seq, signal: () => seq !== renderSeq });
  } catch (e) {
    if (seq === renderSeq) {
      view.innerHTML = `<div class="page"><div class="state-block error-box">
        <div class="s-emoji">⚠️</div><h3>Something went wrong</h3>
        <p>${esc(e?.message || "Unexpected error while loading this page.")}</p>
        <button class="btn btn-primary" onclick="location.reload()">Reload the site</button>
      </div></div>`;
    }
  }
  window.scrollTo(0, 0);
}

const notFoundHTML = (path) => `<div class="page"><div class="state-block">
  <div class="s-emoji">🧭</div><h3>Page not found</h3>
  <p>No page at <code>${esc(path)}</code>.</p>
  <a class="btn btn-primary" href="#/" data-nav>Back to Home</a>
</div></div>`;

/* ---------------- UI kit ---------------- */
export const ICON = {
  down: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v13m5-6-5 6-5-6M4 21h16"/></svg>',
  heart: '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M12 21s-7.5-4.7-10-9.3C.4 8.6 2.4 4.5 6.3 4.1c2.3-.2 4.4 1 5.7 3 1.3-2 3.4-3.2 5.7-3 3.9.4 5.9 4.5 4.3 7.6C19.5 16.3 12 21 12 21z"/></svg>',
  heartReg: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20.4s-6.9-4.3-9.2-8.5C1.2 8.8 3 5.3 6.3 5c2-.2 3.9.9 5.1 2.7.2.3.3.5.4.6h.4c.1-.1.2-.3.4-.6C13.8 5.9 15.7 4.8 17.7 5c3.3.3 5.1 3.8 3.5 6.9-2.3 4.2-9.2 8.5-9.2 8.5z"/></svg>',
  user: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg>',
  clock: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
  search: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>',
  back: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5m6 6-6-6 6-6"/></svg>',
  close: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m4 12.5 5.5 5.5L20 6.5"/></svg>',
};

export function toast(msg, { err = false, ms = 2600 } = {}) {
  const root = $("#toasts");
  const el = document.createElement("div");
  el.className = "toast" + (err ? " err" : "");
  el.innerHTML = `<span class="t-dot"></span><span>${esc(msg)}</span>`;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add("out");
    setTimeout(() => el.remove(), 280);
  }, ms);
}

export function openModal(html, { cls = "" } = {}) {
  const root = $("#modalRoot");
  root.innerHTML = `<div class="modal-back"><div class="modal ${cls}">
    <button class="modal-close" aria-label="Close">${ICON.close}</button>${html}</div></div>`;
  const back = root.firstElementChild;
  const close = () => {
    back.classList.add("closing");
    setTimeout(() => { root.innerHTML = ""; }, 210);
  };
  back.addEventListener("click", (e) => { if (e.target === back) close(); });
  root.querySelector(".modal-close").addEventListener("click", close);
  const escFn = (e) => { if (e.key === "Escape") { close(); document.removeEventListener("keydown", escFn); } };
  document.addEventListener("keydown", escFn);
  return close;
}

/* IntersectionObserver reveal-on-scroll (shared, leak-safe per page) */
let observer = null;
export function observeReveals(root = $("#view")) {
  observer?.disconnect();
  if (!("IntersectionObserver" in window)) {
    $$(".reveal", root).forEach((el) => el.classList.add("in"));
    return;
  }
  observer = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting) { en.target.classList.add("in"); observer.unobserve(en.target); }
    });
  }, { rootMargin: "0px 0px -6% 0px", threshold: 0.04 });
  $$(".reveal", root).forEach((el) => observer.observe(el));
}

/* page frame helpers */
export const page = (inner) => `<div class="page">${inner}</div>`;
export const section = (titleHTML, body, { sub = "", more = "" } = {}) => `
  <div class="section reveal">
    <div class="section-head">
      <div><h2 class="section-title"><span class="glyph"></span>${titleHTML}</h2>${sub ? `<div class="section-sub">${sub}</div>` : ""}</div>
      ${more}
    </div>${body}</div>`;

export const skelCards = (n = 8, cls = "") =>
  `<div class="card-grid ${cls}">${Array.from({ length: n }, () =>
    `<div class="skel skel-card"><div class="skel-line w85"></div><div class="skel-line w60"></div><div class="skel-line w85"></div><div class="skel-line w60"></div></div>`).join("")}</div>`;

export const stateBlock = (emoji, title, text, actions = "") =>
  `<div class="state-block"><div class="s-emoji">${emoji}</div><h3>${esc(title)}</h3><p>${text}</p>${actions}</div>`;

export const errorBlock = (msg, retryHash = "#/") =>
  `<div class="state-block error-box"><div class="s-emoji">📡</div><h3>Connection problem</h3>
   <p>${esc(msg)}</p><button class="btn btn-primary" onclick="location.reload()">Retry</button>
   <div class="retry-note">If this keeps happening, check your internet connection.</div></div>`;

/* favorites badge sync */
export function syncFavCount() {
  const el = $("#favCount");
  const n = Object.keys(store.favs()).length;
  el.hidden = n === 0;
  el.textContent = n > 99 ? "99+" : n;
}

/* floating pill showing the globally selected version (+loader) */
export function notifySelPill() {
  const old = document.getElementById("selPill");
  const v = store.get("selVersion", "");
  const l = store.get("selLoader", "");
  if (!v && !l) { old?.remove(); return; }
  if (old) {
    old.innerHTML = pillHTML(v, l);
    wirePill(old);
    return;
  }
  const el = document.createElement("div");
  el.id = "selPill";
  el.className = "sel-pill";
  el.setAttribute("role", "status");
  el.innerHTML = pillHTML(v, l);
  document.body.appendChild(el);
  wirePill(el);
}
function pillHTML(v, l) {
  return `<span class="sp-txt">Searches now target <b>${v ? "MC " + esc(v) : ""}${v && l ? " × " : ""}${l ? esc(l) + " loader" : ""}</b></span>
    <button class="btn btn-sm btn-primary" data-pill-apply>Open results</button>
    <button class="btn btn-sm btn-ghost" data-pill-clear>×</button>`;
}
function wirePill(el) {
  el.querySelector("[data-pill-clear]")?.addEventListener("click", () => {
    store.set("selVersion", ""); store.set("selLoader", "");
    el.remove();
    toast("Global version & loader filters cleared");
  });
  el.querySelector("[data-pill-apply]")?.addEventListener("click", () => {
    const p = new URLSearchParams();
    const v = store.get("selVersion", ""), l = store.get("selLoader", "");
    if (v) p.set("ver", v);
    if (l) p.set("loader", l);
    p.set("t", Date.now().toString(36));
    location.hash = "/search?" + p.toString();
  });
}
