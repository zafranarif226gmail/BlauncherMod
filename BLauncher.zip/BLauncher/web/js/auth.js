/* ============================================================
   BLauncher Mod — Google login (official Google Identity Services)
   • Browsing / downloading NEVER require login.
   • Uploading & publishing DO require a verified Google session.
   • The Google client ID is public by design; no secrets ship in
     the client. Token verification happens ONLY on the backend
     (functions/api/auth/session.js → Google tokeninfo endpoint).
   • Without a configured backend the UI says so honestly and the
     gated features stay locked — never faked.
   ============================================================ */
import { $, esc, toast } from "./core.js";

export const BACKEND = {
  config: null,
  async fetch() {
    if (this.config) return this.config;
    try {
      const r = await fetch("/api/config", { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error("HTTP " + r.status);
      this.config = { backend: true, ...(await r.json()) };
    } catch {
      this.config = { backend: false, googleClientId: null, uploadEnabled: false, cfProxy: false };
    }
    return this.config;
  },
};

let SESSION = null;
export const currentUser = () => SESSION;

/* ---------------- backend session ---------------- */
export async function loadSession() {
  if (!SESSION) {
    const cached = sessionStorage.getItem("bl.session");
    if (cached) { try { SESSION = JSON.parse(cached); } catch { SESSION = null; } }
  }
  try {
    const r = await fetch("/api/auth/me", { credentials: "same-origin" });
    if (r.status === 204) SESSION = null;
    else SESSION = r.ok ? await r.json() : null;
    if (SESSION?.user) { SESSION._live = true; sessionStorage.setItem("bl.session", JSON.stringify({ user: SESSION.user })); }
    else { SESSION = null; sessionStorage.removeItem("bl.session"); }
  } catch {
    if (SESSION && !SESSION._live) SESSION = SESSION.user ? { user: SESSION.user, stale: true } : null;
  }
  document.dispatchEvent(new CustomEvent("authchanged"));
  return SESSION;
}

export async function requireGoogleScript() {
  if (window.google?.accounts?.id) return true;
  await new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.async = true; s.defer = true;
    s.onload = res; s.onerror = () => rej(new Error("Could not load Google sign-in (accounts.google.com blocked?)"));
    document.head.appendChild(s);
  });
  return true;
}

/* ID token → backend verifies with Google tokeninfo and sets a signed, HttpOnly cookie */
export async function exchangeCredential(credential) {
  const r = await fetch("/api/auth/session", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ credential }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.user) throw new Error(j?.error || `Session rejected (HTTP ${r.status})`);
  SESSION = { user: j.user, _live: true };
  sessionStorage.setItem("bl.session", JSON.stringify({ user: j.user }));
  document.dispatchEvent(new CustomEvent("authchanged"));
  return j.user;
}

export async function signOut() {
  try { await fetch("/api/auth/session", { method: "DELETE", credentials: "same-origin" }); } catch {}
  SESSION = null;
  sessionStorage.removeItem("bl.session");
  window.google?.accounts?.id?.disableAutoSelect?.();
  document.dispatchEvent(new CustomEvent("authchanged"));
}

/* ---------------- header account area ---------------- */
export async function renderAccountArea() {
  const box = $("#accountArea");
  if (!box) return;
  const cfg = await BACKEND.fetch();
  const sess = await loadSession();

  if (sess?.user) {
    box.innerHTML = `
      <div class="acct-chip" title="Signed in with Google">
        ${sess.user.picture ? `<img src="${esc(sess.user.picture)}" alt="" width="22" height="22" loading="lazy"/>` : ""}
        <span>${esc((sess.user.name || "Google user").split(" ")[0])}</span>
        <button class="acct-out" id="acctOut" aria-label="Sign out">Sign out</button>
      </div>`;
    $("#acctOut").addEventListener("click", () =>
      signOut().then(() => toast("Signed out")).then(renderAccountArea));
    return;
  }

  if (!cfg.backend || !cfg.googleClientId) {
    box.innerHTML = `<button class="icon-btn" id="acctBtn" aria-label="Google account sign-in unavailable" disabled title="Sign-in unavailable without the backend — configure the Cloudflare Functions deployment">👤</button>`;
    return;
  }

  box.innerHTML = `<button class="acct-btn" id="acctBtn" aria-label="Sign in with Google">
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.4a5.5 5.5 0 0 1-2.4 3.6v3h3.9c2.3-2.1 3.6-5.2 3.6-8.8z"/><path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.9-3c-1.1.7-2.5 1.2-4.1 1.2a7 7 0 0 1-6.6-4.9H1.4v3.1A12 12 0 0 0 12 24z"/><path fill="#FBBC04" d="M5.4 14.4a7.2 7.2 0 0 1 0-4.6V6.7H1.4a12 12 0 0 0 0 10.8l4-3.1z"/><path fill="#EA4335" d="M12 4.8c1.8 0 3.4.6 4.6 1.8l3.5-3.5A12 12 0 0 0 1.4 6.7l4 3.1A7 7 0 0 1 12 4.8z"/></svg>
    Sign in</button>`;
  $("#acctBtn").addEventListener("click", () => promptGoogleLogin(cfg.googleClientId));
}

let loginRequested = false;
export async function promptGoogleLogin(clientId = null) {
  const cfg = clientId ? { googleClientId: clientId, backend: true } : await BACKEND.fetch();
  if (!cfg.backend || !cfg.googleClientId) {
    toast("Google sign-in is unavailable here — this needs the backend deployment with GOOGLE_CLIENT_ID set.", { err: true, ms: 4200 });
    return false;
  }
  try {
    await requireGoogleScript();
    const { openModal } = await import("./core.js");
    const modalEl = $("#modalRoot .modal");
    if (modalEl) return false; /* one at a time */
    openModal(`<h2 style="margin:0 0 6px">Sign in with Google</h2>
      <p style="color:var(--text-dim);font-size:.9rem">Required only for <b>uploading</b> and <b>publishing</b>. Browsing and downloading stay open to everyone. Google verifies the sign-in and this site never sees your password.</p>
      <div id="gisButtonHost" style="display:flex;justify-content:center;padding:14px 0"></div>`, { cls: "auth-modal" });
    window.google.accounts.id.initialize({
      client_id: cfg.googleClientId,
      callback: async (resp) => {
        try { await exchangeCredential(resp.credential); toast("Signed in as " + (SESSION?.user?.name || "Google user")); }
        catch (e) { toast(e?.message || "Google sign-in failed", { err: true }); }
        document.querySelector(".modal-close")?.click();
        renderAccountArea();
        document.dispatchEvent(new CustomEvent("authchanged"));
      },
      auto_select: false,
      ux_mode: "popup",
    });
    window.google.accounts.id.renderButton($("#gisButtonHost"), { theme: "filled_black", size: "large", text: "signin_with", logo_alignment: "left" });
    return true;
  } catch (e) {
    toast(e?.message || "Google sign-in could not start", { err: true });
    return false;
  }
}

/* convenience for gated views — returns truthy user or renders the gate */
export async function gateOrRender(container, title, blurb) {
  const cfg = await BACKEND.fetch();
  const user = await loadSession();
  if (user?.user) return user.user;
  const needLogin = !!(cfg.backend && cfg.googleClientId);
  container.innerHTML = `
    <div class="state-block gate">
      <div class="s-emoji">🔐</div>
      <h3>${esc(title)}</h3>
      <p>${esc(blurb)}</p>
      <p style="color:var(--text-dim)">Browsing, searching and downloading have always been open — no login needed for those.</p>
      ${needLogin
        ? `<button class="btn btn-primary" data-gate-login>Sign in with Google</button>`
        : `<div class="err-box-inline"><b>Google sign-in is not configured on this deployment.</b>.
            This site has been opened without the backend (Cloudflare Functions) or GOOGLE_CLIENT_ID is unset —
            so uploads stay locked rather than pretending to work.</div>`}
    </div>`;
  container.querySelector("[data-gate-login]")?.addEventListener("click", () => promptGoogleLogin());
  return null;
}
