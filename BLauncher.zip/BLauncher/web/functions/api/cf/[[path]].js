/* /api/cf/[[path]] — real CurseForge proxy.
   Forwards the exact path to https://api.curseforge.com/v1/<path> with the
   developer key kept server-side (env.CURSEFORGE_API_KEY). No data is ever
   invented here: failures surface as real HTTP status codes. */
const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });

export const onRequestGet = async ({ request, env, params }) => {
  const key = env.CURSEFORGE_API_KEY;
  if (!key) {
    return new Response(null, { status: 404 });
  }
  const path = (params.path || []).join("/");
  if (!path) return json({ error: "Missing CurseForge API path" }, 400);
  const url = new URL(request.url);
  const target = `https://api.curseforge.com/v1/${path}${url.search || ""}`;
  if (!/^https:\/\/api\.curseforge\.com\/v1\/[A-Za-z0-9/_\-?=&%.]+$/.test(target)) {
    return json({ error: "Blocked path" }, 400);
  }

  let upstream;
  try {
    upstream = await fetch(target, {
      headers: { "x-api-key": key, Accept: "application/json" },
    });
  } catch (e) {
    return json({ error: "Upstream unreachable: " + String(e?.message || e) }, 502);
  }

  const text = await upstream.text();
  return new Response(text, {
    status: upstream.status,
    headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=120" },
  });
};

export const onRequestPost = async ({ request, env, params }) => {
  const key = env.CURSEFORGE_API_KEY;
  if (!key) return new Response(null, { status: 404 });
  const path = (params.path || []).join("/");
  if (!path) return json({ error: "Missing CurseForge API path" }, 400);
  let upstream;
  try {
    upstream = await fetch(`https://api.curseforge.com/v1/${path}`, {
      method: "POST",
      headers: { "x-api-key": key, Accept: "application/json", "Content-Type": "application/json" },
      body: await request.text(),
    });
  } catch (e) {
    return json({ error: "Upstream unreachable: " + String(e?.message || e) }, 502);
  }
  const text = await upstream.text();
  return new Response(text, { status: upstream.status, headers: { "Content-Type": "application/json" } });
};
