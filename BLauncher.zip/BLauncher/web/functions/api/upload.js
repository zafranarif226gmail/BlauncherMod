/* /api/upload — real persistent file storage (Cloudflare R2).
   POST: multipart file upload → validates type/size/sha256 → dedupes by hash
   → stores under mods/<sha256>/<filename> with metadata.
   GET: /api/upload/check?sha=<hex> → duplicate check.
   Uploaded files are only ever stored as bytes — nothing is executed. */
import { readSession, json } from "../auth/_lib.js";

const jsonResp = json;
const WAIT = (ms) => new Promise((r) => setTimeout(r, ms));

export const onRequestPost = async ({ request, env }) => {
  if (!env.FILES) return jsonResp({ error: "Upload storage (R2) is not configured on this deployment." }, 503);
  if (!env.SESSION_SECRET) return jsonResp({ error: "Sessions unavailable." }, 503);
  const user = await readSession(request, env.SESSION_SECRET);
  if (!user || !user.sub) return jsonResp({ error: "Sign in with Google to upload." }, 401);

  const maxMB = Number(env.MAX_FILE_MB || 100);
  const ct = request.headers.get("content-length");
  if (ct && Number(ct) > maxMB * 1024 * 1024 + 1024)
    return jsonResp({ error: `File exceeds the configured limit of ${maxMB} MB.` }, 413);

  let form;
  try { form = await request.formData(); }
  catch { return jsonResp({ error: "Could not parse the upload." }, 400); }

  const file = form.get("file");
  let meta = {};
  try { meta = JSON.parse(form.get("meta") || "{}"); } catch {}
  if (!file || typeof file === "string") return jsonResp({ error: "Missing file." }, 400);

  const name = String(file.name || "");
  if (!/\.(jar|mcpack|mcaddon)$/i.test(name))
    return jsonResp({ error: "Only .jar, .mcpack and .mcaddon files are accepted." }, 415);
  if (file.size > maxMB * 1024 * 1024)
    return jsonResp({ error: `File exceeds the configured limit of ${maxMB} MB.` }, 413);

  /* genuine SHA-256 on the server too (client-provided values are never trusted) */
  const bytes = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const sha = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");

  /* secondary archive sanity check: ZIP magic (all three formats are ZIPs) */
  const head = new Uint8Array(bytes.slice(0, 4));
  const isZip = head[0] === 0x50 && head[1] === 0x4b;
  if (!isZip) return jsonResp({ error: "File is not a readable archive (.jar/.mcpack/.mcaddon must be ZIP)." }, 415);

  const safeName = name.replace(/[^A-Za-z0-9._ -]/g, "_").slice(0, 180);
  const key = `mods/${sha}/${safeName}`;

  /* duplicate detection — same SHA already stored? */
  const existing = await env.FILES.head(key);
  if (existing) {
    return jsonResp({
      stored: true, duplicate: true, sha256: sha, objectKey: key,
      note: "An identical file (same SHA-256) is already in storage — original timestamp kept.",
    }, 200);
  }

  const MAX_TRIES = 3;
  for (let i = 0; i < MAX_TRIES; i++) {
    try {
      await env.FILES.put(key, bytes, {
        httpMetadata: { contentType: file.type || "application/java-archive" },
        customMetadata: {
          originalName: safeName,
          sha256: sha,
          uploadedBy: user.name || "google-user",
          uploadedByEmail: user.email || "",
          uploadedAt: new Date().toISOString(),
          meta: JSON.stringify(meta || {}).slice(0, 2000),
        },
      });
      return jsonResp({ stored: true, duplicate: false, sha256: sha, objectKey: key }, 201);
    } catch (e) {
      if (i === MAX_TRIES - 1) return jsonResp({ error: "R2 storage failed: " + String(e?.message || e) }, 502);
      await WAIT(250);
    }
  }
};

export const onRequestGet = async ({ request, env, url }) => {
  if (!env.FILES) return jsonResp({ error: "no storage configured" }, 503);
  if (url.pathname.endsWith("/check")) {
    const sha = (url.searchParams.get("sha") || "").toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(sha)) return jsonResp({ error: "invalid sha" }, 400);
    const user = await readSession(request, env.SESSION_SECRET);
    if (!user) return jsonResp({ error: "Sign in to check uploads." }, 401);
    /* list all objects under mods/<sha>/ prefix to answer "did I already send this?" */
    const listing = await env.FILES.list({ prefix: `mods/${sha}/` });
    return jsonResp({ exists: listing.objects.length > 0, count: listing.objects.length });
  }
  return jsonResp({ error: "unsupported" }, 404);
};
