/* /api/auth/session
   POST { credential } — official Google ID token. Verified server-side with
   Google's tokeninfo endpoint (audience + expiry + issuer all checked), then a
   signed HttpOnly session cookie is issued. The Google secret stays on
   Google's side; only GOOGLE_CLIENT_ID (public) and SESSION_SECRET exist here.
   DELETE — sign out. */
import { makeSessionCookie, readSession, sessionCookieHeader, clearCookieHeader, COOKIE_NAME, json } from "./_lib.js";

export const onRequestPost = async ({ request, env }) => {
  if (!env.GOOGLE_CLIENT_ID) return json({ error: "Google sign-in is not configured on this deployment (GOOGLE_CLIENT_ID missing)." }, 503);
  if (!env.SESSION_SECRET) return json({ error: "Server session secret missing (SESSION_SECRET)." }, 503);

  let credential = "";
  try { credential = (await request.json()).credential || ""; } catch {}
  if (!credential) return json({ error: "Missing Google credential" }, 400);

  let info = {};
  try {
    const r = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
    info = await r.json();
    if (!r.ok) throw new Error(info?.error_description || "token rejected by Google");
  } catch (e) {
    return json({ error: "Could not verify the Google token with Google: " + String(e?.message || e) }, 401);
  }

  const now = Math.floor(Date.now() / 1000);
  if (info.aud !== env.GOOGLE_CLIENT_ID) return json({ error: "Token audience mismatch" }, 401);
  if (Number(info.exp) <= now) return json({ error: "Token expired" }, 401);
  const iss = String(info.iss || "");
  if (!iss.startsWith("https://accounts.google.com") && !iss.startsWith("accounts.google.com"))
    return json({ error: "Token issuer is not Google accounts" }, 401);

  const user = {
    sub: info.sub,
    name: info.name || info.email || "Google user",
    email: info.email || null,
    email_verified: info.email_verified === "true" || info.email_verified === true,
    picture: info.picture || null,
  };
  const cookie = await makeSessionCookie(user, env.SESSION_SECRET);
  return json({ user }, 200, { "Set-Cookie": sessionCookieHeader(cookie) });
};

export const onDelete = undefined;
export const onRequestDelete = async () => json({ ok: true }, 200, {
  "Set-Cookie": clearCookieHeader(),
});
