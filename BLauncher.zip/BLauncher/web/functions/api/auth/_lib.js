/* shared session helpers — HMAC-signed, HttpOnly cookie */
const enc = new TextEncoder();
const b64u = (buf) => {
  const b = String.fromCharCode(...new Uint8Array(buf));
  return btoa(b).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const b64uDec = (s) => {
  const b = atob(s.replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(b, (c) => c.charCodeAt(0));
};

async function hmac(msg, secret) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return crypto.subtle.sign("HMAC", k, enc.encode(msg));
}

export const COOKIE_NAME = "bl_session";

export async function makeSessionCookie(user, secret, maxAge = 7 * 86400) {
  const payload = { ...user, iat: Math.floor(Date.now() / 1000) };
  const body = b64u(enc.encode(JSON.stringify(payload)));
  const sig = b64u(await hmac(body, secret));
  return `${body}.${sig}`;
}

export async function readSession(request, secret) {
  const cookie = request.headers.get("cookie") || "";
  const m = cookie.match(new RegExp(`${COOKIE_NAME}=([^;\\s]+)`));
  if (!m) return null;
  const [body, sig] = m[1].split(".");
  if (!body || !sig) return null;
  const expected = b64u(await hmac(body, secret));
  if (expected.length !== sig.length || expected !== sig) return null;
  try {
    const payload = JSON.parse(new TextDecoder().decode(b64uDec(body)));
    if (!payload.sub || Date.now() / 1000 - payload.iat > 7 * 86400) return null;
    return payload;
  } catch { return null; }
}

export const sessionCookieHeader = (value) =>
  `${COOKIE_NAME}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${Math.floor(7 * 86400)}`;
export const clearCookieHeader = () =>
  `${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`;

export const json = (body, status = 200, headers = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers } });
