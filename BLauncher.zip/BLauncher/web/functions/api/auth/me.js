/* /api/auth/me — current Google session (or 204 when signed out) */
import { readSession, json } from "./_lib.js";

export const onRequestGet = async ({ request, env }) => {
  if (!env.SESSION_SECRET) return json({ error: "no session backend" }, 503);
  const session = await readSession(request, env.SESSION_SECRET);
  if (!session) return new Response(null, { status: 204 });
  const { iat, ...user } = session;
  return json({ user });
};
