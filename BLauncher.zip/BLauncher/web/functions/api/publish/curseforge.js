/* /api/publish/curseforge — honest authorization status.
   CurseForge only accepts uploads for approved partners; this endpoint
   reports whether a valid authorization exists on the deployment. Without
   one it answers "not authorized" — nothing is ever faked as published. */
import { readSession, json } from "../auth/_lib.js";

export const onRequestPost = async ({ request, env }) => {
  const user = await readSession(request, env.SESSION_SECRET);
  if (!user) return json({ authorized: false, error: "Sign in first." }, 401);
  if (!env.CURSEFORGE_PUBLISH_AUTH)
    return json({
      authorized: false,
      error: "This deployment has no CurseForge publishing authorization configured (CURSEFORGE_PUBLISH_AUTH). CurseForge requires an approved partner programme membership — apply via console.curseforge.com.",
    }, 200);
  return json({ authorized: true, note: "Authorization present on the deployment." }, 200);
};
