/* /api/config — public, secrets never leave as values.
   Tells the client which backend capabilities are actually wired up. */
export const onRequestGet = async ({ env }) => {
  const json = (data, status = 200) =>
    new Response(JSON.stringify(data), {
      status,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    });
  return json({
    backend: true,
    googleClientId: env.GOOGLE_CLIENT_ID || null, /* public by design */
    cfProxy: !!env.CURSEFORGE_API_KEY,
    uploadEnabled: !!env.FILES,
    curseforgePublish: !!env.CURSEFORGE_PUBLISH_AUTH,
    maxFileMB: Number(env.MAX_FILE_MB || 100),
  });
};
